# -*- coding: utf-8 -*-
"""ابزار تاریخ شمسی — تبدیل هوشمند"""
import jdatetime
import re
from datetime import datetime


# الگوهای شناسایی تاریخ میلادی
GREGORIAN_PATTERNS = [
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
    "%Y/%m/%d",
    "%d/%m/%Y %H:%M:%S",
    "%d/%m/%Y",
]

PERSIAN_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]

DAYS_FA = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]


def _is_jalali_string(s):
    """تشخیص اینکه رشته شمسی است یا نه"""
    if not s:
        return False
    match = re.match(r"^(\d{4})[/-](\d{1,2})[/-](\d{1,2})", str(s))
    if not match:
        return False
    year = int(match.group(1))
    return 1300 <= year <= 1500


def _parse_gregorian(s):
    """تلاش برای پارس رشته میلادی"""
    if not s:
        return None
    text = str(s).strip()
    for fmt in GREGORIAN_PATTERNS:
        try:
            return datetime.strptime(text[:19] if len(text) >= 19 else text, fmt)
        except ValueError:
            continue
    return None


def to_jalali(value, with_time=False):
    """
    تبدیل هوشمند به شمسی:
    - اگر شمسی است، همان را برگردان (شاید فقط فرمت کن)
    - اگر میلادی است، به شمسی تبدیل کن
    - اگر None/خالی است، '-' برگردان
    """
    if value is None or value == "":
        return "-"

    # اگر datetime یا jdatetime آبجکت است
    if isinstance(value, jdatetime.date):
        return f"{value.year}/{value.month:02d}/{value.day:02d}"

    if isinstance(value, datetime):
        if 1300 <= value.year <= 1500:
            return f"{value.year}/{value.month:02d}/{value.day:02d}"
        try:
            jd = jdatetime.date.fromgregorian(date=value.date())
            result = f"{jd.year}/{jd.month:02d}/{jd.day:02d}"
            if with_time and (value.hour or value.minute):
                result += f" {value.hour:02d}:{value.minute:02d}"
            return result
        except Exception:
            return str(value)

    # اگر string است
    text = str(value).strip()

    # اگر خودش شمسی است
    if _is_jalali_string(text):
        return text

    # تلاش برای پارس میلادی
    dt = _parse_gregorian(text)
    if dt is None:
        return text  # قابل پارس نبود، همان را برگردان

    try:
        jd = jdatetime.date.fromgregorian(date=dt.date())
        result = f"{jd.year}/{jd.month:02d}/{jd.day:02d}"
        if with_time and (dt.hour or dt.minute):
            result += f" {dt.hour:02d}:{dt.minute:02d}"
        return result
    except Exception:
        return text


def to_jalali_datetime(value):
    """تبدیل با ساعت"""
    return to_jalali(value, with_time=True)


def to_jalali_full(value):
    """تبدیل با روز هفته + ماه به فارسی"""
    if value is None or value == "":
        return "-"

    if isinstance(value, (datetime, jdatetime.date)):
        if isinstance(value, jdatetime.date):
            jd = value
        elif 1300 <= value.year <= 1500:
            try:
                jd = jdatetime.date(value.year, value.month, value.day)
            except:
                return str(value)
        else:
            try:
                jd = jdatetime.date.fromgregorian(date=value.date())
            except Exception:
                return str(value)
    else:
        text = str(value).strip()
        if _is_jalali_string(text):
            try:
                m = re.match(r"^(\d{4})[/-](\d{1,2})[/-](\d{1,2})", text)
                jd = jdatetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            except:
                return text
        else:
            dt = _parse_gregorian(text)
            if not dt:
                return text
            try:
                jd = jdatetime.date.fromgregorian(date=dt.date())
            except:
                return text

    try:
        return f"{DAYS_FA[jd.weekday()]} {jd.day} {PERSIAN_MONTHS[jd.month-1]} {jd.year}"
    except Exception:
        return str(value)


def to_jalali_short(value):
    """فقط تاریخ بدون ساعت — همان to_jalali"""
    return to_jalali(value, with_time=False)


def to_jalali_time_only(value):
    """فقط ساعت"""
    if not value:
        return "-"
    if isinstance(value, datetime):
        return f"{value.hour:02d}:{value.minute:02d}"
    text = str(value).strip()
    # اگر شمسی است و ساعت دارد
    match = re.search(r"(\d{1,2}):(\d{2})(?::\d{2})?", text)
    if match:
        return f"{int(match.group(1)):02d}:{match.group(2)}"
    return text


def register_filters(app):
    """ثبت همه فیلترها در Flask"""
    app.jinja_env.filters['jalali'] = to_jalali
    app.jinja_env.filters['jalali_short'] = to_jalali_short
    app.jinja_env.filters['jalali_date'] = to_jalali
    app.jinja_env.filters['jalali_datetime'] = to_jalali_datetime
    app.jinja_env.filters['jalali_full'] = to_jalali_full
    app.jinja_env.filters['jalali_time'] = to_jalali_time_only
    app.jinja_env.filters['shamsi'] = to_jalali
    app.jinja_env.filters['persian_date'] = to_jalali
# -*- coding: utf-8 -*-
"""اصلاح فرمت ساعت‌های الگوها در دیتابیس: تبدیل / به :"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def normalize(t):
    """تبدیل ساعت به فرمت استاندارد HH:MM"""
    if not t:
        return t
    text = str(t).strip()
    # ارقام فارسی → لاتین
    persian_digits = "۰۱۲۳۴۵۶۷۸۹"
    for i, d in enumerate(persian_digits):
        text = text.replace(d, str(i))
    # جداکننده‌ها
    text = text.replace("/", ":").replace(".", ":").replace("،", ":").replace(" ", "")
    if ":" not in text:
        return text
    try:
        parts = text.split(":")
        h = int(parts[0])
        m = int(parts[1])
        if 0 <= h <= 23 and 0 <= m <= 59:
            return f"{h:02d}:{m:02d}"
    except:
        pass
    return t


conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

cur.execute("SELECT * FROM work_patterns")
patterns = cur.fetchall()

print("=" * 60)
print("اصلاح فرمت ساعت‌های الگوها")
print("=" * 60)

fields = [
    "work_start", "work_end",
    "lunch_start", "lunch_end",
    "breakfast_start", "breakfast_end",
    "dinner_start", "dinner_end",
    "attendance_range_start", "attendance_range_end",
]

for p in patterns:
    print(f"\nالگو: {p['pattern_name']} (id={p['id']})")
    changes = {}
    for f in fields:
        try:
            old = p[f]
            new = normalize(old)
            if old != new and old is not None:
                changes[f] = (old, new)
                print(f"   {f}: '{old}' → '{new}'")
        except (KeyError, IndexError):
            continue

    if changes:
        sets = ", ".join([f"{f} = ?" for f in changes.keys()])
        values = [v[1] for v in changes.values()] + [p["id"]]
        cur.execute(f"UPDATE work_patterns SET {sets} WHERE id = ?", values)
        print(f"   ✅ اصلاح شد ({len(changes)} فیلد)")
    else:
        print(f"   ✓ نیازی به اصلاح نیست")

conn.commit()
conn.close()

print("\n" + "=" * 60)
print("پایان — همه ساعت‌ها به فرمت HH:MM اصلاح شدند")
print("=" * 60)
# -*- coding: utf-8 -*-
import sqlite3
import main

DB="roadmonitor.db"

def check_db():
    con=sqlite3.connect(DB)
    required=["users","projects","personnel","machines","gps_points","zk_logs","personnel_attendance","anpr_events","truck_services","work_front_candidates","data_corrections","gate_events","pilot_quality_daily"]
    tables={r[0] for r in con.execute("select name from sqlite_master where type=\'table\'")}
    missing=[x for x in required if x not in tables]
    assert not missing, f"missing tables: {missing}"
    counts={t:con.execute(f"select count(*) from {t}").fetchone()[0] for t in ["users","personnel","machines","gps_points","zk_logs","personnel_attendance"]}
    con.close(); return counts

def check_routes():
    c=main.app.test_client(); r=c.get('/login'); assert r.status_code==200
    with c.session_transaction() as s:
        s['user_id']=1; s['username']='admin'; s['role']='مدیر'; s['project_id']=1
    for path in ['/','/users','/settings','/attendance_device','/personnel','/machines','/tracker_dashboard','/anpr_events','/truck_services','/work_fronts','/analysis/settings','/backup','/backups']:
        r=c.get(path, follow_redirects=False); assert r.status_code < 500, f"{path}: {r.status_code}"

if __name__=='__main__':
    print('DB:', check_db())
    check_routes()
    print('SMOKE: PASS')

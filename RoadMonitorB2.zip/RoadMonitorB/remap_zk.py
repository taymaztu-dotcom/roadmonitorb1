import sqlite3
from datetime import datetime

connection = sqlite3.connect("roadmonitor.db")
connection.row_factory = sqlite3.Row
cursor = connection.cursor()

cursor.execute("SELECT id FROM projects ORDER BY id LIMIT 1")
project_row = cursor.fetchone()
project_id = project_row["id"] if project_row else 1

cursor.execute("""
    SELECT personnel_code, device_user_id, full_name
    FROM personnel
    WHERE device_user_id IS NOT NULL AND TRIM(device_user_id) != ''
""")
mapping = {}
print("Personnel mapping:")
for row in cursor.fetchall():
    device_id = str(row["device_user_id"]).strip()
    mapping[device_id] = row["personnel_code"]
    print(f"  Device {device_id} -> {row['personnel_code']} | {row['full_name']}")

if not mapping:
    print("No personnel device IDs found.")
    print("First enter Device User ID in personnel page, then run this file again.")
    connection.close()
    raise SystemExit

updated_logs = 0
cursor.execute("SELECT id, device_user_id FROM zk_logs")
for row in cursor.fetchall():
    personnel_code = mapping.get(str(row["device_user_id"]).strip(), "")
    if personnel_code:
        cursor.execute(
            "UPDATE zk_logs SET personnel_code = ? WHERE id = ?",
            (personnel_code, row["id"])
        )
        updated_logs += 1

cursor.execute("""
    SELECT personnel_code, substr(punch_time, 1, 10) AS work_date,
           MIN(substr(punch_time, 12, 5)) AS start_time,
           MAX(substr(punch_time, 12, 5)) AS end_time
    FROM zk_logs
    WHERE personnel_code IS NOT NULL AND TRIM(personnel_code) != ''
    GROUP BY personnel_code, substr(punch_time, 1, 10)
""")
grouped = cursor.fetchall()

created = 0
updated_days = 0
for row in grouped:
    cursor.execute("""
        SELECT id FROM personnel_attendance
        WHERE project_id = ? AND personnel_code = ? AND work_date = ?
    """, (project_id, row["personnel_code"], row["work_date"]))
    existing = cursor.fetchone()
    if existing:
        cursor.execute("""
            UPDATE personnel_attendance
            SET start_time = ?, end_time = ?
            WHERE id = ?
        """, (row["start_time"], row["end_time"], existing["id"]))
        updated_days += 1
    else:
        cursor.execute("""
            INSERT INTO personnel_attendance (personnel_code, work_date, start_time, end_time, project_id)
            VALUES (?, ?, ?, ?, ?)
        """, (row["personnel_code"], row["work_date"], row["start_time"], row["end_time"], project_id))
        created += 1

connection.commit()
connection.close()

print("-------------------")
print("Updated ZK logs:", updated_logs)
print("Attendance days updated:", updated_days)
print("Attendance days created:", created)
print("Done at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
# -*- coding: utf-8 -*-
"""Migration v9 — فاز F: هشدارهای خودکار"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col} به {table}")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v9 — فاز F")
    print("=" * 60)

    # ── جدول قوانین هشدار ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            rule_key TEXT NOT NULL,
            rule_name TEXT NOT NULL,
            description TEXT,
            is_enabled INTEGER DEFAULT 1,
            threshold_minutes INTEGER DEFAULT 30,
            threshold_percent INTEGER DEFAULT 70,
            threshold_value REAL DEFAULT 0,
            severity TEXT DEFAULT 'warning',
            send_telegram INTEGER DEFAULT 1,
            send_sms INTEGER DEFAULT 0,
            send_panel INTEGER DEFAULT 1,
            check_interval_minutes INTEGER DEFAULT 5,
            last_check_at TEXT,
            updated_at TEXT,
            UNIQUE(project_id, rule_key)
        )
    """)
    print("\n📌 alert_rules")

    # ── جدول تاریخچه اجرای Scheduler ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS scheduler_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_key TEXT NOT NULL,
            job_name TEXT,
            started_at TEXT,
            finished_at TEXT,
            status TEXT,
            result_summary TEXT,
            alerts_created INTEGER DEFAULT 0,
            error_message TEXT
        )
    """)
    print("📌 scheduler_history")

    # ── جدول تاریخچه گزارش‌های ارسالی ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS report_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            report_type TEXT NOT NULL,
            report_date TEXT,
            file_path TEXT,
            sent_via TEXT,
            recipients_count INTEGER DEFAULT 0,
            sent_at TEXT,
            status TEXT DEFAULT 'success',
            error_message TEXT
        )
    """)
    print("📌 report_history")

    # ── توسعه جدول notifications ──
    add_col(cur, "notifications", "rule_key", "TEXT")
    add_col(cur, "notifications", "sent_to_users", "TEXT")

    # ── قوانین پیش‌فرض ──
    cur.execute("SELECT COUNT(*) FROM alert_rules WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        print("\n📌 درج قوانین پیش‌فرض...")
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        rules = [
            ("suspicious_stop", "توقف مشکوک ماشین", "توقف بیش از حد مجاز خارج از محدوده کارگاه", 30, 0, 0, "warning", 1, 0, 1, 5),
            ("gps_offline", "قطع ارتباط GPS", "ردیاب بیش از X دقیقه داده نفرستاده", 15, 0, 0, "critical", 1, 0, 1, 5),
            ("late_start", "تأخیر جدی در شروع کار", "شروع کار بیش از X دقیقه بعد از ساعت رسمی", 30, 0, 0, "warning", 1, 0, 1, 30),
            ("early_end", "بازگشت زودهنگام", "پایان کار X دقیقه قبل از موعد", 30, 0, 0, "warning", 1, 0, 1, 30),
            ("out_of_range_attendance", "ورود خارج از ساعت مجاز", "تردد خارج از محدوده تعیین‌شده الگو", 0, 0, 0, "info", 0, 0, 1, 60),
            ("low_voltage", "ولتاژ کم ردیاب", "ولتاژ برق ماشین از حد مجاز کمتر است", 0, 0, 22.0, "critical", 1, 0, 1, 15),
            ("low_service_rate", "کاهش سرویس کامیون", "درصد تحقق سرویس هدف کمتر از حد قابل قبول", 0, 70, 0, "warning", 1, 0, 1, 1440),
            ("data_mismatch", "مغایرت منابع داده", "تفاوت بین گیت، GPS و حضور و غیاب", 15, 0, 0, "info", 0, 0, 1, 60),
        ]
        for r in rules:
            cur.execute("""
                INSERT INTO alert_rules (project_id, rule_key, rule_name, description,
                    threshold_minutes, threshold_percent, threshold_value, severity,
                    send_telegram, send_sms, send_panel, check_interval_minutes, updated_at)
                VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, r + (now,))
        print(f"  [+] {len(rules)} قانون پیش‌فرض")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v9 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
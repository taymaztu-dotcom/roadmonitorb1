# -*- coding: utf-8 -*-
"""موتور پلاک‌خوان — نرمال‌سازی، جهت‌یابی، اتصال به ماشین"""
import sqlite3
import os
import re
import datetime
import base64
import uuid

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")
IMAGES_DIR = os.path.join(os.path.dirname(DB_PATH), "static", "anpr_images")
os.makedirs(IMAGES_DIR, exist_ok=True)


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


# ═══════════ نرمال‌سازی پلاک ═══════════

PERSIAN_TO_LATIN = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def normalize_plate(plate):
    """
    نرمال‌سازی پلاک ایرانی برای مقایسه یکسان
    مثال: '۱۲ ب ۳۴۵ - ایران ۶۷' → '12B345-67'
    """
    if not plate:
        return ""
    text = str(plate).strip()
    # ارقام فارسی/عربی به لاتین
    text = text.translate(PERSIAN_TO_LATIN)
    # حذف کلمات "ایران" و مشابه
    for w in ["ایران", "IRAN", "iran"]:
        text = text.replace(w, "")
    # حذف کاراکترهای اضافه
    text = re.sub(r"[\s\-_/\.\,]", "", text)
    # فقط اعداد، حروف فارسی و لاتین را نگه‌دار
    text = re.sub(r"[^\w\u0600-\u06FF]", "", text)
    return text.upper()


def format_plate_display(plate):
    """پلاک را برای نمایش زیبا فرمت کن (اگر ممکن است)"""
    if not plate:
        return "-"
    normalized = normalize_plate(plate)
    # اگر ۸ کاراکتر است (فرمت ایرانی معمولی): 12X34567
    if len(normalized) == 8:
        # 12X345-67
        return f"{normalized[:2]}{normalized[2]}{normalized[3:6]}-{normalized[6:8]}"
    return plate


# ═══════════ ذخیره تصویر ═══════════

def save_image_from_base64(base64_str, plate=""):
    """ذخیره تصویر Base64 و برگرداندن مسیر"""
    if not base64_str:
        return None
    try:
        # حذف prefix اگر باشد
        if "," in base64_str[:50]:
            base64_str = base64_str.split(",", 1)[1]
        data = base64.b64decode(base64_str)
        filename = f"{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.jpg"
        filepath = os.path.join(IMAGES_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(data)
        return f"/static/anpr_images/{filename}"
    except Exception as e:
        print(f"[anpr image error] {e}")
        return None


# ═══════════ تشخیص جهت ═══════════

def determine_direction(project_id, camera_id, plate_normalized, event_time):
    """
    تشخیص جهت بر اساس منطق نرم‌افزاری
    """
    conn = get_db()
    cur = conn.cursor()

    # آیا این دوربین جهت ثابت دارد؟
    if camera_id:
        cur.execute("SELECT direction FROM anpr_cameras WHERE id = ?", (camera_id,))
        cam = cur.fetchone()
        if cam and cam["direction"] in ("ورود", "خروج"):
            conn.close()
            return cam["direction"], "دوربین"

    # جهت‌یابی خودکار بر اساس توالی
    cur.execute("""
        SELECT direction FROM anpr_events
        WHERE project_id = ? AND plate_normalized = ? AND direction IN ('ورود', 'خروج')
        ORDER BY event_time DESC LIMIT 1
    """, (project_id, plate_normalized))
    last = cur.fetchone()
    conn.close()

    if last:
        # توالی قبلی فقط در صورتی به عنوان قرینه استفاده می‌شود که دوربین
        # یا منبع جهت قابل اعتماد در پروژه فعال باشد؛ در غیر این صورت جهت ناشناخته است.
        return "نامشخص", "نامعتبر"
    return "نامشخص", "نامشخص"


# ═══════════ اتصال به ماشین ═══════════

def find_machine_by_plate(project_id, plate_normalized):
    """پیدا کردن ماشین بر اساس پلاک نرمال‌شده"""
    conn = get_db()
    cur = conn.cursor()

    # اول در whitelist
    cur.execute("""
        SELECT w.*, m.id as machine_id, m.code, m.name
        FROM plate_whitelist w
        LEFT JOIN machines m ON w.machine_id = m.id
        WHERE w.project_id = ? AND w.plate_normalized = ? AND w.is_active = 1
        LIMIT 1
    """, (project_id, plate_normalized))
    w = cur.fetchone()
    if w and w["machine_id"]:
        conn.close()
        return {"machine_id": w["machine_id"], "code": w["code"], "name": w["name"]}

    # بعد در machines بر اساس plate_normalized
    cur.execute("""
        SELECT id, code, name FROM machines
        WHERE project_id = ? AND plate_normalized = ? LIMIT 1
    """, (project_id, plate_normalized))
    m = cur.fetchone()
    conn.close()
    if m:
        return {"machine_id": m["id"], "code": m["code"], "name": m["name"]}

    return None


# ═══════════ ثبت رویداد اصلی ═══════════

def process_anpr_event(data, project_id=1):
    """
    پردازش کامل یک رویداد ANPR
    data: dict شامل plate, camera_id (یا camera_code), event_time,
          confidence, direction (اختیاری), image_url / image_base64 (اختیاری)
    """
    plate_raw = str(data.get("plate", "")).strip()
    if not plate_raw:
        return {"ok": False, "error": "پلاک خالی است"}

    plate_normalized = normalize_plate(plate_raw)

    # زمان
    event_time = data.get("event_time") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # پیدا کردن دوربین
    camera_id = None
    camera_name = ""
    conn = get_db()
    cur = conn.cursor()

    if data.get("camera_id"):
        cur.execute("SELECT id, camera_name FROM anpr_cameras WHERE id = ?", (data["camera_id"],))
        c = cur.fetchone()
        if c:
            camera_id = c["id"]
            camera_name = c["camera_name"]
    elif data.get("camera_code"):
        cur.execute("SELECT id, camera_name FROM anpr_cameras WHERE camera_code = ? LIMIT 1", (data["camera_code"],))
        c = cur.fetchone()
        if c:
            camera_id = c["id"]
            camera_name = c["camera_name"]

    # تصویر
    image_url = data.get("image_url", "")
    image_path = None
    if data.get("image_base64"):
        image_path = save_image_from_base64(data["image_base64"], plate_normalized)

        # جهت
    direction = data.get("direction", "")
    direction_source = "دوربین"
    if not direction:
        direction, direction_source = determine_direction(project_id, camera_id, plate_normalized, event_time)

    # اتصال به ماشین
    machine = find_machine_by_plate(project_id, plate_normalized)
    machine_id = machine["machine_id"] if machine else None
    machine_code = machine["code"] if machine else None
    is_known = 1 if machine else 0

    # سطح اطمینان
    confidence = float(data.get("confidence", 0) or 0)
    conn2 = get_db()
    cur2 = conn2.cursor()
    cur2.execute("SELECT min_confidence FROM anpr_settings WHERE project_id = ? LIMIT 1", (project_id,))
    s = cur2.fetchone()
    min_conf = s["min_confidence"] if s else 70
    conn2.close()

    if confidence == 0:
        trust = "بالا"
    elif confidence >= min_conf:
        trust = "بالا"
    elif confidence >= min_conf - 20:
        trust = "متوسط"
    else:
        trust = "نیازمند بررسی"

    # درج رویداد
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("""
        INSERT INTO anpr_events (project_id, camera_id, camera_name,
            plate_raw, plate_normalized, event_time, direction, direction_source,
            confidence, image_url, image_path, image_base64,
            machine_id, machine_code, is_known, trust_level,
            raw_data, received_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (project_id, camera_id, camera_name,
          plate_raw, plate_normalized, event_time, direction, direction_source,
          confidence, image_url, image_path, "",
          machine_id, machine_code, is_known, trust,
          str(data)[:1000], now))
    event_id = cur.lastrowid

    # به‌روزرسانی دوربین
    if camera_id:
        cur.execute("""
            UPDATE anpr_cameras SET last_event_at = ?, events_count = events_count + 1
            WHERE id = ?
        """, (now, camera_id))

    conn.commit()
    conn.close()

    # اگر پلاک ناشناس بود، اعلان
    if not is_known:
        try:
            from main import add_notification
            add_notification(
                notification_type="پلاک ناشناس",
                title=f"پلاک ناشناس: {plate_raw}",
                message=f"دوربین: {camera_name or '-'}\nزمان: {event_time}\nجهت: {direction}",
                severity="warning",
                related_type="anpr_event",
                related_id=event_id,
                project_id=project_id
            )
        except Exception:
            pass

    return {
        "ok": True,
        "event_id": event_id,
        "plate_normalized": plate_normalized,
        "direction": direction,
        "is_known": is_known,
        "machine": machine,
    }


# ═══════════ گزارش‌ها ═══════════

def get_events(project_id, limit=200, only_unknown=False, camera_id=None):
    conn = get_db()
    cur = conn.cursor()
    q = """
        SELECT e.*, m.name as machine_name
        FROM anpr_events e
        LEFT JOIN machines m ON e.machine_id = m.id
        WHERE e.project_id = ?
    """
    params = [project_id]
    if only_unknown:
        q += " AND e.is_known = 0"
    if camera_id:
        q += " AND e.camera_id = ?"
        params.append(camera_id)
    q += " ORDER BY e.id DESC LIMIT ?"
    params.append(limit)
    cur.execute(q, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_cameras(project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM anpr_cameras WHERE project_id = ? ORDER BY id", (project_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_whitelist(project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT w.*, m.name as machine_name FROM plate_whitelist w
        LEFT JOIN machines m ON w.machine_id = m.id
        WHERE w.project_id = ? ORDER BY w.id DESC
    """, (project_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows
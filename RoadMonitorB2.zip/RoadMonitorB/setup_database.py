import sqlite3
from werkzeug.security import generate_password_hash

connection = sqlite3.connect("roadmonitor.db")
cursor = connection.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS machines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT,
    name TEXT,
    type TEXT,
    plate TEXT,
    driver TEXT,
    gps_code TEXT,
    gps_type TEXT,
    manufacture_date TEXT,
    serial_number TEXT,
    operation_status TEXT,
    active_status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS work_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    machine_code TEXT,
    work_date TEXT,
    start_time TEXT,
    end_time TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS personnel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    personnel_code TEXT,
    full_name TEXT,
    job_title TEXT,
    national_code TEXT,
    phone_number TEXT,
    has_machine TEXT,
    machine_code TEXT,
    device_user_id TEXT,
    start_date TEXT,
    status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS personnel_attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    personnel_code TEXT,
    work_date TEXT,
    start_time TEXT,
    end_time TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    full_name TEXT,
    role TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    location TEXT,
    start_date TEXT,
    description TEXT,
    status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS gps_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    machine_code TEXT,
    lat REAL,
    lng REAL,
    speed REAL,
    recorded_at TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    phone TEXT,
    code TEXT,
    created_at TEXT,
    used INTEGER
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS zk_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    device_user_id TEXT,
    punch_time TEXT,
    punch_type TEXT,
    status TEXT,
    personnel_code TEXT,
    imported_at TEXT,
    UNIQUE(device_user_id, punch_time)
)
""")

for table in ["machines", "personnel", "work_logs", "personnel_attendance"]:
    try:
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN project_id INTEGER")
    except Exception:
        pass

try:
    cursor.execute("ALTER TABLE machines ADD COLUMN lat REAL")
except Exception:
    pass

try:
    cursor.execute("ALTER TABLE machines ADD COLUMN lng REAL")
except Exception:
    pass

try:
    cursor.execute("ALTER TABLE users ADD COLUMN phone TEXT")
except Exception:
    pass

cursor.execute("SELECT COUNT(*) FROM users")
if cursor.fetchone()[0] == 0:
    cursor.execute(
        "INSERT INTO users (username, password, full_name, role, phone) VALUES (?, ?, ?, ?, ?)",
        ("admin", generate_password_hash("admin123"), "مدیر سامانه", "مدیر", "")
    )

cursor.execute("SELECT COUNT(*) FROM projects")
if cursor.fetchone()[0] == 0:
    cursor.execute(
        "INSERT INTO projects (name, location, start_date, description, status) VALUES (?, ?, ?, ?, ?)",
        ("پروژه اصلی", "", "", "", "فعال")
    )

cursor.execute("SELECT id FROM projects ORDER BY id LIMIT 1")
default_project = cursor.fetchone()
default_project_id = default_project[0] if default_project else 1

for table in ["machines", "personnel", "work_logs", "personnel_attendance"]:
    cursor.execute(f"UPDATE {table} SET project_id = ? WHERE project_id IS NULL", (default_project_id,))

cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("company_name", "شرکت راهسازی و عمرانی"))
cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("sms_enabled", "0"))
cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("zk_ip", "192.168.1.201"))
cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("zk_port", "4370"))
cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", ("zk_password", "0"))

connection.commit()
connection.close()
print("دیتابیس با موفقیت به‌روزرسانی شد")
# -*- coding: utf-8 -*-
"""Migration v8 — فاز E: نقش‌ها، مجوزها، گیرندگان گزارش"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col} به {table}")
    else:
        print(f"  [=] {col} از قبل هست")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v8 — فاز E")
    print("=" * 60)

    # ── جدول نقش‌ها ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            role_name TEXT NOT NULL,
            description TEXT,
            is_system INTEGER DEFAULT 0,
            display_order INTEGER DEFAULT 0,
            created_at TEXT,
            UNIQUE(project_id, role_name)
        )
    """)
    print("\n📌 roles")

    # ── جدول تخصیص مجوز به نقش ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS role_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_id INTEGER NOT NULL,
            permission_key TEXT NOT NULL,
            UNIQUE(role_id, permission_key)
        )
    """)
    print("📌 role_permissions")

    # ── توسعه جدول users ──
    print("\n📌 users:")
    add_col(cur, "users", "role_id", "INTEGER")
    add_col(cur, "users", "can_login", "INTEGER DEFAULT 1")
    add_col(cur, "users", "is_recipient", "INTEGER DEFAULT 0")
    add_col(cur, "users", "telegram_chat_id", "TEXT")
    add_col(cur, "users", "receive_urgent_alert", "INTEGER DEFAULT 0")
    add_col(cur, "users", "receive_daily_summary", "INTEGER DEFAULT 0")
    add_col(cur, "users", "receive_weekly_summary", "INTEGER DEFAULT 0")
    add_col(cur, "users", "receive_monthly_summary", "INTEGER DEFAULT 0")
    add_col(cur, "users", "alert_channels", "TEXT DEFAULT 'panel'")
    add_col(cur, "users", "is_active", "INTEGER DEFAULT 1")

    # ── نقش‌های پیش‌فرض ──
    cur.execute("SELECT COUNT(*) FROM roles WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        print("\n📌 درج نقش‌های پیش‌فرض...")
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        default_roles = [
            ("مدیرعامل", "دسترسی کامل به همه بخش‌ها", 1, 1),
            ("رئیس هیئت مدیره", "دسترسی مشاهده و گزارش", 0, 2),
            ("مدیر پروژه", "مدیریت کامل پروژه", 0, 3),
            ("سرپرست کارگاه", "مدیریت روزمره کارگاه", 0, 4),
            ("معاون کارگاه", "پشتیبانی سرپرست", 0, 5),
        ]
        for name, desc, is_system, order in default_roles:
            cur.execute("""
                INSERT INTO roles (project_id, role_name, description, is_system, display_order, created_at)
                VALUES (1, ?, ?, ?, ?, ?)
            """, (name, desc, is_system, order, now))
        print(f"  [+] {len(default_roles)} نقش درج شد")

        # مجوزهای پیش‌فرض
        cur.execute("SELECT id, role_name FROM roles WHERE project_id = 1")
        role_map = {r[1]: r[0] for r in cur.fetchall()}

        # همه مجوزها
        ALL_PERMS = [
            "view_dashboard", "view_map", "view_calendar",
            "view_machines", "add_machine", "edit_machine", "delete_machine",
            "view_personnel", "add_personnel", "edit_personnel", "delete_personnel",
            "view_worklogs", "add_worklog",
            "view_attendance", "add_attendance", "adjust_attendance",
            "monthly_report", "export_excel",
            "view_zk", "sync_zk",
            "view_patterns", "manage_patterns",
            "view_holidays", "manage_holidays",
            "view_leaves", "manage_leaves",
            "view_exceptions", "manage_exceptions",
            "view_zones", "manage_zones",
            "view_trackers", "view_analysis", "run_analysis",
            "view_services", "manage_service_targets",
            "view_work_fronts", "confirm_work_fronts",
            "view_notifications", "manage_projects",
            "manage_settings", "manage_users", "manage_roles",
            "manage_telegram", "view_audit", "gps_test",
            "manage_analysis_settings", "view_tracker_logs",
        ]

        MANAGER_PERMS = ALL_PERMS
        VIEWER_PERMS = [p for p in ALL_PERMS if p.startswith("view_") or p in ["monthly_report", "export_excel"]]
        PROJECT_MANAGER_PERMS = [p for p in ALL_PERMS if p not in ["manage_users", "manage_roles", "manage_telegram", "manage_projects", "view_audit"]]
        SUPERVISOR_PERMS = [p for p in PROJECT_MANAGER_PERMS if not p.startswith("delete_") and p not in ["manage_analysis_settings"]]
        ASSISTANT_PERMS = [p for p in SUPERVISOR_PERMS if not p.startswith("manage_")] + ["adjust_attendance", "run_analysis"]

        role_perms_map = {
            "مدیرعامل": MANAGER_PERMS,
            "رئیس هیئت مدیره": VIEWER_PERMS,
            "مدیر پروژه": PROJECT_MANAGER_PERMS,
            "سرپرست کارگاه": SUPERVISOR_PERMS,
            "معاون کارگاه": ASSISTANT_PERMS,
        }

        for role_name, perms in role_perms_map.items():
            rid = role_map.get(role_name)
            if not rid:
                continue
            for p in perms:
                cur.execute("INSERT OR IGNORE INTO role_permissions (role_id, permission_key) VALUES (?, ?)", (rid, p))
        print(f"  [+] مجوزهای پیش‌فرض برای همه نقش‌ها تنظیم شد")

        # کاربر admin → نقش مدیرعامل
        cur.execute("SELECT id FROM roles WHERE project_id = 1 AND role_name = 'مدیرعامل' LIMIT 1")
        admin_role = cur.fetchone()
        if admin_role:
            cur.execute("UPDATE users SET role_id = ?, can_login = 1, is_active = 1 WHERE username = 'admin'",
                        (admin_role[0],))
            print("  [+] کاربر admin نقش «مدیرعامل» گرفت")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v8 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
# -*- coding: utf-8 -*-
"""Migration v10 — فاز G: محور پروژه و کیلومتراژ"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col}")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v10 — فاز G: محور پروژه")
    print("=" * 60)

    # ── جدول محورهای پروژه ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS project_corridors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            corridor_name TEXT NOT NULL,
            description TEXT,
            corridor_type TEXT DEFAULT 'راه‌سازی',
            path_json TEXT,
            total_length_km REAL DEFAULT 0,
            width_meters REAL DEFAULT 200,
            start_km REAL DEFAULT 0,
            end_km REAL DEFAULT 0,
            color TEXT DEFAULT '#e74c3c',
            is_active INTEGER DEFAULT 1,
            created_by TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    print("\n📌 project_corridors")

    # ── جدول نقاط محور (Waypoints) ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS corridor_waypoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            corridor_id INTEGER NOT NULL,
            sequence INTEGER NOT NULL,
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            km_marker REAL,
            note TEXT
        )
    """)
    print("📌 corridor_waypoints")

    # ── اضافه کردن km_position به gps_points ──
    print("\n📌 gps_points:")
    add_col(cur, "gps_points", "corridor_km", "REAL")
    add_col(cur, "gps_points", "distance_from_corridor", "REAL")
    add_col(cur, "gps_points", "in_corridor", "INTEGER DEFAULT 0")

    # ── اضافه کردن به daily_machine_summary ──
    print("\n📌 daily_machine_summary:")
    add_col(cur, "daily_machine_summary", "min_km", "REAL")
    add_col(cur, "daily_machine_summary", "max_km", "REAL")
    add_col(cur, "daily_machine_summary", "avg_km", "REAL")
    add_col(cur, "daily_machine_summary", "corridor_time_minutes", "INTEGER DEFAULT 0")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v10 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
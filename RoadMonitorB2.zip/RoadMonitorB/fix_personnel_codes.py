# -*- coding: utf-8 -*-
"""
اسکریپت اصلاح کد پرسنلی
تبدیل کدهای تکراری و نامنظم به فرمت استاندارد PGSH_PER_XX
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")
PREFIX = "PGSH_PER_"


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def main():
    print("=" * 60)
    print("اصلاح کد پرسنلی به فرمت استاندارد")
    print("Personnel Code Standardization Tool")
    print("=" * 60)
    print("")

    conn = get_connection()
    cur = conn.cursor()

    # خواندن همه پرسنل بر اساس id
    cur.execute("SELECT id, personnel_code, full_name, device_user_id FROM personnel ORDER BY id")
    personnel = cur.fetchall()

    total = len(personnel)

    if total == 0:
        print("هیچ پرسنلی در دیتابیس یافت نشد.")
        conn.close()
        return

    print("تعداد کل پرسنل:", total)
    print("")

    # تعیین تعداد رقم بر اساس تعداد پرسنل
    if total < 100:
        digits = 2
    elif total < 1000:
        digits = 3
    else:
        digits = 4

    print("پیش‌نمایش تغییرات:")
    print("-" * 60)

    changes = []
    for index, person in enumerate(personnel, start=1):
        old_code = person["personnel_code"]
        new_code = PREFIX + str(index).zfill(digits)
        device_id = person["device_user_id"] if person["device_user_id"] else "-"
        name = person["full_name"] if person["full_name"] else "بدون نام"

        print("  {:>3}. {:<15} -> {:<15} | Device {:<4} | {}".format(
            index, old_code if old_code else "-", new_code, device_id, name
        ))

        changes.append({
            "id": person["id"],
            "old_code": old_code,
            "new_code": new_code
        })

    print("-" * 60)
    print("")

    # تأیید کاربر
    answer = input("آیا این تغییرات اعمال شود؟ (y/n): ").strip().lower()

    if answer != "y":
        print("عملیات لغو شد. هیچ تغییری در دیتابیس اعمال نشد.")
        conn.close()
        return

    print("")
    print("در حال اعمال تغییرات...")

    # مرحله ۱: تغییر کدها به کد موقت برای جلوگیری از تداخل UNIQUE
    for change in changes:
        cur.execute(
            "UPDATE personnel SET personnel_code = ? WHERE id = ?",
            ("TEMP_" + str(change["id"]), change["id"])
        )

    conn.commit()

    # مرحله ۲: تغییر کدها به کد نهایی
    updated = 0
    for change in changes:
        cur.execute(
            "UPDATE personnel SET personnel_code = ? WHERE id = ?",
            (change["new_code"], change["id"])
        )
        updated += 1

    conn.commit()

    # همچنین به‌روزرسانی جدول machines اگر personnel_code در آن استفاده شده
    # (بر اساس ساختار سند، machine_code در personnel هست ولی برعکس نه)
    # پس فقط personnel اصلاح می‌شود

    print("")
    print("=" * 60)
    print("عملیات با موفقیت انجام شد!")
    print("تعداد پرسنل به‌روز شده:", updated)
    print("=" * 60)
    print("")
    print("مراحل بعدی:")
    print("  1. اجرای مجدد remap_zk.py برای اتصال لاگ‌ها به کدهای جدید")
    print("     python remap_zk.py")
    print("")
    print("  2. بررسی صفحه پرسنل در مرورگر:")
    print("     http://127.0.0.1:5050/personnel")
    print("")

    conn.close()


if __name__ == "__main__":
    main()
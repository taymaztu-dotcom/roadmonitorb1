# -*- coding: utf-8 -*-
"""موتور Backup خودکار دیتابیس"""
import os
import shutil
import sqlite3
import datetime
import gzip

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "roadmonitor.db")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")
os.makedirs(BACKUP_DIR, exist_ok=True)


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def create_backup(compress=True, keep_days=30):
    """
    ساخت یک backup از دیتابیس
    - compress: فشرده‌سازی با gzip
    - keep_days: نگه‌داری backup های قدیمی‌تر از X روز حذف می‌شود
    """
    if not os.path.exists(DB_PATH):
        return {"ok": False, "error": "دیتابیس یافت نشد"}

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"roadmonitor_{timestamp}.db"
    backup_path = os.path.join(BACKUP_DIR, filename)

    try:
        # backup ایمن با sqlite3.backup
        src = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(backup_path)
        with dst:
            src.backup(dst)
        src.close()
        dst.close()

        size_mb = os.path.getsize(backup_path) / (1024 * 1024)

        if compress:
            gz_path = backup_path + ".gz"
            with open(backup_path, "rb") as f_in:
                with gzip.open(gz_path, "wb", compresslevel=9) as f_out:
                    shutil.copyfileobj(f_in, f_out)
            os.remove(backup_path)
            backup_path = gz_path
            filename = filename + ".gz"
            size_mb = os.path.getsize(backup_path) / (1024 * 1024)

        # ثبت در دیتابیس
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS backup_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT,
                    file_path TEXT,
                    size_mb REAL,
                    compressed INTEGER DEFAULT 0,
                    created_at TEXT,
                    trigger_type TEXT DEFAULT 'manual'
                )
            """)
            cur.execute("""
                INSERT INTO backup_history (filename, file_path, size_mb, compressed, created_at, trigger_type)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (filename, backup_path, round(size_mb, 2), 1 if compress else 0,
                  datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "auto"))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[backup log error] {e}")

        # پاک کردن قدیمی‌ها
        deleted = cleanup_old_backups(keep_days)

        return {
            "ok": True,
            "filename": filename,
            "path": backup_path,
            "size_mb": round(size_mb, 2),
            "compressed": compress,
            "deleted_old": deleted
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def cleanup_old_backups(keep_days=30):
    """حذف backup های قدیمی‌تر از X روز"""
    if not os.path.exists(BACKUP_DIR):
        return 0
    cutoff = datetime.datetime.now() - datetime.timedelta(days=keep_days)
    deleted = 0
    for f in os.listdir(BACKUP_DIR):
        if not (f.startswith("roadmonitor_") and (f.endswith(".db") or f.endswith(".db.gz"))):
            continue
        filepath = os.path.join(BACKUP_DIR, f)
        try:
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
            if mtime < cutoff:
                os.remove(filepath)
                deleted += 1
        except Exception:
            pass
    return deleted


def get_backup_list():
    """لیست backup های موجود"""
    if not os.path.exists(BACKUP_DIR):
        return []
    backups = []
    for f in os.listdir(BACKUP_DIR):
        if not f.startswith("roadmonitor_"):
            continue
        filepath = os.path.join(BACKUP_DIR, f)
        try:
            size_mb = os.path.getsize(filepath) / (1024 * 1024)
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
            backups.append({
                "filename": f,
                "path": filepath,
                "size_mb": round(size_mb, 2),
                "created_at": mtime.strftime("%Y-%m-%d %H:%M:%S"),
                "compressed": f.endswith(".gz")
            })
        except Exception:
            pass
    backups.sort(key=lambda x: x["created_at"], reverse=True)
    return backups


def restore_backup(backup_filename):
    """
    بازیابی backup — با احتیاط استفاده شود!
    این تابع دیتابیس فعلی را با backup جایگزین می‌کند.
    """
    backup_path = os.path.join(BACKUP_DIR, backup_filename)
    if not os.path.exists(backup_path):
        return {"ok": False, "error": "فایل backup یافت نشد"}

    # backup از دیتابیس فعلی قبل از restore
    safety_backup = os.path.join(BACKUP_DIR, f"before_restore_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
    try:
        shutil.copy2(DB_PATH, safety_backup)
    except:
        pass

    try:
        if backup_filename.endswith(".gz"):
            # اکسترکت gzip
            temp_path = DB_PATH + ".restore_temp"
            with gzip.open(backup_path, "rb") as f_in:
                with open(temp_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
            shutil.move(temp_path, DB_PATH)
        else:
            shutil.copy2(backup_path, DB_PATH)

        return {"ok": True, "message": "بازیابی موفق. سرور را restart کنید."}
    except Exception as e:
        return {"ok": False, "error": str(e)}
# Compatibility API used by the management UI.
def list_backups():
    return get_backup_list()

def delete_backup(filename):
    if not filename or "/" in filename or "\\" in filename or not filename.startswith("roadmonitor_"):
        return {"ok": False, "error": "نام فایل نامعتبر"}
    path=os.path.join(BACKUP_DIR, filename)
    if not os.path.isfile(path):
        return {"ok": False, "error": "فایل یافت نشد"}
    try:
        os.remove(path); return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def get_backup_stats():
    items=get_backup_list()
    return {"count":len(items), "size_mb":round(sum(x.get("size_mb",0) for x in items),2), "latest":items[0] if items else None}

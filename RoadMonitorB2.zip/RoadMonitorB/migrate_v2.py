# -*- coding: utf-8 -*-
"""
مهاجرت نسخه ۲:
- اضافه کردن ساعت صبحانه/شام و شیفت شب به work_patterns
- اضافه کردن work_pattern_id به personnel
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def column_exists(cursor, table, column):
    cursor.execute(f"PRAGMA table_info({table})")
    return any(row["name"] == column for row in cursor.fetchall())


def add_column_if_missing(cursor, table, column, definition):
    if not column_exists(cursor, table, column):
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
        print(f"  [+] ستون {column} به جدول {table} اضافه شد")
    else:
        print(f"  [=] ستون {column} از قبل وجود دارد")


def migrate():
    conn = get_connection()
    cur = conn.cursor()

    print("=" * 60)
    print("مهاجرت نسخه ۲: صبحانه، شام، شیفت شب، الگوی اختصاصی پرسنل")
    print("=" * 60)
    print("")

    print("جدول work_patterns:")
    add_column_if_missing(cur, "work_patterns", "breakfast_start", "TEXT")
    add_column_if_missing(cur, "work_patterns", "breakfast_end", "TEXT")
    add_column_if_missing(cur, "work_patterns", "breakfast_duration", "INTEGER DEFAULT 0")
    add_column_if_missing(cur, "work_patterns", "dinner_start", "TEXT")
    add_column_if_missing(cur, "work_patterns", "dinner_end", "TEXT")
    add_column_if_missing(cur, "work_patterns", "dinner_duration", "INTEGER DEFAULT 0")
    add_column_if_missing(cur, "work_patterns", "is_night_shift", "INTEGER DEFAULT 0")
    add_column_if_missing(cur, "work_patterns", "crosses_midnight", "INTEGER DEFAULT 0")
    add_column_if_missing(cur, "work_patterns", "description", "TEXT")

    print("")
    print("جدول personnel:")
    add_column_if_missing(cur, "personnel", "work_pattern_id", "INTEGER")

    conn.commit()
    conn.close()

    print("")
    print("=" * 60)
    print("✅ مهاجرت با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
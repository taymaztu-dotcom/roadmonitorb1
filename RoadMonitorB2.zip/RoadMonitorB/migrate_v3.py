# -*- coding: utf-8 -*-
"""
مهاجرت v3: جدول اصلاح دستی گزارش کارکرد
"""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    print("=" * 60)
    print("Migration v3: جدول attendance_adjustments")
    print("=" * 60)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance_adjustments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            personnel_id INTEGER NOT NULL,
            work_date TEXT NOT NULL,
            adjusted_start TEXT,
            adjusted_end TEXT,
            adjustment_type TEXT DEFAULT 'ویرایش دستی',
            note TEXT,
            adjusted_by TEXT,
            adjusted_at TEXT,
            UNIQUE(project_id, personnel_id, work_date)
        )
    """)
    print("  [+] جدول attendance_adjustments ساخته شد")

    conn.commit()
    conn.close()
    print("=" * 60)
    print("✅ Migration v3 با موفقیت انجام شد!")
    print("=" * 60)

if __name__ == "__main__":
    migrate()
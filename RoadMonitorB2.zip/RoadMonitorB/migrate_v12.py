# -*- coding: utf-8 -*-
"""Migration v12 — تنظیمات تحلیل به تفکیک نوع ماشین"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v12 — تنظیمات تحلیل ماشین‌ها")
    print("=" * 60)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS machine_type_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            machine_category TEXT NOT NULL,
            display_name TEXT NOT NULL,
            icon TEXT DEFAULT '🚜',

            stop_speed_threshold INTEGER DEFAULT 3,
            stop_min_duration INTEGER DEFAULT 3,
            long_stop_threshold INTEGER DEFAULT 15,
            suspicious_stop_threshold INTEGER DEFAULT 30,

            work_area_radius_meters INTEGER DEFAULT 100,
            work_area_min_duration INTEGER DEFAULT 15,

            expected_daily_hours REAL DEFAULT 8,
            idle_running_alert INTEGER DEFAULT 60,

            loader_pairing_radius INTEGER DEFAULT 100,
            loader_min_loading_seconds INTEGER DEFAULT 60,

            dozer_min_pass_length INTEGER DEFAULT 30,
            dozer_max_pass_speed INTEGER DEFAULT 15,

            excavator_min_cycle_seconds INTEGER DEFAULT 30,

            truck_min_loading_seconds INTEGER DEFAULT 60,
            truck_min_dumping_seconds INTEGER DEFAULT 60,

            enabled INTEGER DEFAULT 1,
            note TEXT,
            updated_at TEXT,
            UNIQUE(project_id, machine_category)
        )
    """)
    print("\n📌 machine_type_settings")

    # درج پیش‌فرض
    cur.execute("SELECT COUNT(*) FROM machine_type_settings WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        print("\n📌 درج تنظیمات پیش‌فرض ۶ نوع ماشین...")
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        defaults = [
            {
                "category": "کامیون",
                "display": "کامیون / تانکر",
                "icon": "🚛",
                "expected_hours": 10,
                "note": "کامیون‌های حمل مصالح، تانکر آب، تانکر سوخت",
            },
            {
                "category": "لودر",
                "display": "لودر",
                "icon": "🚜",
                "expected_hours": 9,
                "note": "لودرهای بارگیری در جبهه کار",
            },
            {
                "category": "بلدوزر",
                "display": "بلدوزر",
                "icon": "🚧",
                "expected_hours": 9,
                "note": "بلدوزرهای خاک‌ریزی و تسطیح",
            },
            {
                "category": "گریدر",
                "display": "گریدر",
                "icon": "🚧",
                "expected_hours": 9,
                "note": "گریدر برای رگلاژ سطح راه",
            },
            {
                "category": "غلطک",
                "display": "غلطک",
                "icon": "🛞",
                "expected_hours": 8,
                "note": "غلطک برای فشرده‌سازی",
            },
            {
                "category": "بیل مکانیکی",
                "display": "بیل مکانیکی",
                "icon": "🏗️",
                "expected_hours": 9,
                "note": "بیل هیدرولیک برای خاکبرداری",
            },
            {
                "category": "سایر",
                "display": "سایر ماشین‌آلات",
                "icon": "🚙",
                "expected_hours": 8,
                "note": "ماشین‌های سبک و متفرقه",
            },
        ]

        for d in defaults:
            cur.execute("""
                INSERT INTO machine_type_settings (
                    project_id, machine_category, display_name, icon,
                    expected_daily_hours, note, updated_at
                ) VALUES (1, ?, ?, ?, ?, ?, ?)
            """, (d["category"], d["display"], d["icon"],
                  d["expected_hours"], d["note"], now))
        print(f"  [+] {len(defaults)} نوع ماشین")

    # اضافه‌کردن machine_category به machines (اگر نیست)
    cur.execute("PRAGMA table_info(machines)")
    cols = [r[1] for r in cur.fetchall()]
    if "machine_category" not in cols:
        cur.execute("ALTER TABLE machines ADD COLUMN machine_category TEXT")
        print("  [+] machine_category به machines")

    # پیشنهاد اولیه بر اساس فیلد type موجود
    print("\n📌 تخصیص خودکار دسته‌بندی به ماشین‌های موجود...")
    cur.execute("SELECT id, name, type FROM machines WHERE machine_category IS NULL OR machine_category = ''")
    machines = cur.fetchall()

    keyword_map = {
        "کامیون": ["کامیون", "بنز", "تانکر", "تریلی", "خاور", "ولوو"],
        "لودر": ["لودر", "loader"],
        "بلدوزر": ["بلدوزر", "دوزر", "dozer", "بولدوزر"],
        "گریدر": ["گریدر", "grader"],
        "غلطک": ["غلطک", "roller"],
        "بیل مکانیکی": ["بیل", "excavator", "کاترپیلار", "هیوندای", "کوبلکو"],
    }

    assigned = 0
    for m in machines:
        machine_text = (m[1] + " " + (m[2] or "")).lower()
        category = "سایر"
        for cat, keywords in keyword_map.items():
            for kw in keywords:
                if kw.lower() in machine_text:
                    category = cat
                    break
            if category != "سایر":
                break
        cur.execute("UPDATE machines SET machine_category = ? WHERE id = ?", (category, m[0]))
        assigned += 1
    print(f"  [+] {assigned} ماشین دسته‌بندی شد")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v12 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()

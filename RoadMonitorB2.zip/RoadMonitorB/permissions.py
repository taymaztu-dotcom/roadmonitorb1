# -*- coding: utf-8 -*-
"""لیست کامل مجوزها + توابع کمکی"""

# ═══ کاتالوگ کامل مجوزها ═══
PERMISSIONS = {
    "🏠 عمومی": [
        ("view_dashboard", "مشاهده داشبورد"),
        ("view_map", "مشاهده نقشه"),
        ("view_calendar", "مشاهده تقویم پروژه"),
        ("view_notifications", "مشاهده اعلانات"),
    ],
    "🚜 ماشین‌آلات": [
        ("view_machines", "مشاهده لیست ماشین‌آلات"),
        ("add_machine", "افزودن ماشین"),
        ("edit_machine", "ویرایش ماشین"),
        ("delete_machine", "حذف ماشین"),
        ("view_worklogs", "مشاهده کارکردها"),
        ("add_worklog", "ثبت کارکرد"),
    ],
    "👷 پرسنل": [
        ("view_personnel", "مشاهده لیست پرسنل"),
        ("add_personnel", "افزودن پرسنل"),
        ("edit_personnel", "ویرایش پرسنل"),
        ("delete_personnel", "حذف پرسنل"),
        ("view_attendance", "مشاهده تردد پرسنل"),
        ("add_attendance", "ثبت تردد پرسنل"),
        ("adjust_attendance", "ثبت اصلاح دستی تردد"),
        ("monthly_report", "گزارش کارکرد ماهانه"),
        ("export_excel", "خروجی اکسل"),
    ],
    "📆 الگو و تقویم": [
        ("view_patterns", "مشاهده الگوهای کاری"),
        ("manage_patterns", "مدیریت الگوهای کاری"),
        ("view_holidays", "مشاهده تعطیلات"),
        ("manage_holidays", "مدیریت تعطیلات"),
        ("view_leaves", "مشاهده مرخصی"),
        ("manage_leaves", "مدیریت مرخصی"),
        ("view_exceptions", "مشاهده استثناها"),
        ("manage_exceptions", "مدیریت استثناها"),
        ("view_zones", "مشاهده محدوده‌ها"),
        ("manage_zones", "مدیریت محدوده‌ها"),
    ],
    "📡 GPS و تحلیل": [
        ("view_trackers", "مشاهده داشبورد ردیاب‌ها"),
        ("view_analysis", "مشاهده تحلیل هوشمند"),
        ("run_analysis", "اجرای تحلیل"),
        ("view_services", "مشاهده گزارش سرویس‌ها"),
        ("manage_service_targets", "مدیریت سرویس‌های هدف"),
        ("view_work_fronts", "مشاهده جبهه‌های کار"),
        ("confirm_work_fronts", "تأیید جبهه کار"),
        ("manage_analysis_settings", "تنظیمات تحلیل"),
        ("view_tracker_logs", "لاگ اتصالات ردیاب"),
    ],
    "🔌 دستگاه‌ها": [
        ("view_zk", "مشاهده دستگاه حضور و غیاب"),
        ("sync_zk", "همگام‌سازی دستگاه ZK"),
        ("gps_test", "تست GPS"),
    ],
    "⚙️ مدیریت سیستم": [
        ("manage_projects", "مدیریت پروژه‌ها"),
        ("manage_settings", "مدیریت تنظیمات"),
        ("manage_users", "مدیریت کاربران"),
        ("manage_roles", "مدیریت نقش‌ها و مجوزها"),
        ("manage_telegram", "مدیریت تلگرام"),
        ("view_audit", "مشاهده لاگ تغییرات"),
    ],
}


def get_all_permission_keys():
    result = []
    for cat, perms in PERMISSIONS.items():
        for key, label in perms:
            result.append(key)
    return result


def get_permission_label(key):
    for cat, perms in PERMISSIONS.items():
        for k, label in perms:
            if k == key:
                return label
    return key


def user_has_permission(user_id, permission_key, db_get):
    """چک کن آیا کاربر این مجوز را دارد"""
    if not user_id:
        return False
    conn = db_get()
    cur = conn.cursor()
    # نقش کاربر
    cur.execute("SELECT role_id, username FROM users WHERE id = ?", (user_id,))
    u = cur.fetchone()
    if not u:
        conn.close()
        return False
    # admin همیشه همه چیز
    if u["username"] == "admin":
        conn.close()
        return True
    role_id = u["role_id"]
    if not role_id:
        conn.close()
        return False
    cur.execute("SELECT 1 FROM role_permissions WHERE role_id = ? AND permission_key = ? LIMIT 1",
                (role_id, permission_key))
    r = cur.fetchone()
    conn.close()
    return bool(r)


def get_user_permissions(user_id, db_get):
    """همه مجوزهای یک کاربر"""
    if not user_id:
        return set()
    conn = db_get()
    cur = conn.cursor()
    cur.execute("SELECT role_id, username FROM users WHERE id = ?", (user_id,))
    u = cur.fetchone()
    if not u:
        conn.close()
        return set()
    if u["username"] == "admin":
        conn.close()
        return set(get_all_permission_keys())
    if not u["role_id"]:
        conn.close()
        return set()
    cur.execute("SELECT permission_key FROM role_permissions WHERE role_id = ?", (u["role_id"],))
    perms = {r["permission_key"] for r in cur.fetchall()}
    conn.close()
    return perms
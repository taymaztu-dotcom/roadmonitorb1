# -*- coding: utf-8 -*-
"""Migration v5 — توسعه جدول gps_points برای Teltonika"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col}")
    else:
        print(f"  [=] {col} (از قبل)")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    print("=" * 60)
    print("Migration v5 — توسعه GPS برای Teltonika")
    print("=" * 60)

    # اطمینان از وجود جدول gps_points
    cur.execute("""
        CREATE TABLE IF NOT EXISTS gps_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT,
            lat REAL,
            lng REAL,
            speed REAL DEFAULT 0,
            recorded_at TEXT
        )
    """)
    print("\n📌 gps_points:")
    add_col(cur, "gps_points", "imei", "TEXT")
    add_col(cur, "gps_points", "altitude", "REAL DEFAULT 0")
    add_col(cur, "gps_points", "angle", "REAL DEFAULT 0")
    add_col(cur, "gps_points", "satellites", "INTEGER DEFAULT 0")
    add_col(cur, "gps_points", "ignition", "INTEGER DEFAULT 0")
    add_col(cur, "gps_points", "movement", "INTEGER DEFAULT 0")
    add_col(cur, "gps_points", "gsm_signal", "INTEGER DEFAULT 0")
    add_col(cur, "gps_points", "external_voltage", "REAL DEFAULT 0")
    add_col(cur, "gps_points", "battery_voltage", "REAL DEFAULT 0")
    add_col(cur, "gps_points", "odometer", "REAL DEFAULT 0")
    add_col(cur, "gps_points", "priority", "INTEGER DEFAULT 0")
    add_col(cur, "gps_points", "raw_data", "TEXT")
    add_col(cur, "gps_points", "server_received_at", "TEXT")

    # ایندکس برای جستجوی سریع
    cur.execute("CREATE INDEX IF NOT EXISTS idx_gps_imei ON gps_points(imei)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_gps_recorded ON gps_points(recorded_at)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_gps_machine ON gps_points(machine_code, recorded_at)")
    print("  [+] ایندکس‌ها ساخته شد")

    # جدول لاگ اتصال ردیاب‌ها
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tracker_connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imei TEXT,
            ip_address TEXT,
            connected_at TEXT,
            disconnected_at TEXT,
            packets_received INTEGER DEFAULT 0,
            last_packet_at TEXT,
            status TEXT DEFAULT 'connected'
        )
    """)
    print("\n📌 tracker_connections: آماده")

    conn.commit()
    conn.close()

    print("\n" + "=" * 60)
    print("✅ Migration v5 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
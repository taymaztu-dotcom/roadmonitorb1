# -*- coding: utf-8 -*-
"""
موتور محاسبه کارکرد ماهانه — v2 با رعایت الگوی کاری
"""
import sqlite3
import os
import datetime
import jdatetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

DAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]
PERSIAN_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def time_to_minutes(t):
    if not t or ":" not in str(t):
        return None
    try:
        parts = str(t).strip().split(":")
        return int(parts[0]) * 60 + int(parts[1])
    except:
        return None


def minutes_to_hm(m):
    if m is None or m < 0:
        return "-"
    return f"{m // 60:02d}:{m % 60:02d}"


def get_days_in_jmonth(year, month):
    if month <= 6:
        return 31
    if month <= 11:
        return 30
    return 30 if jdatetime.date(year, 1, 1).isleap() else 29


def get_active_pattern(project_id, personnel_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT work_pattern_id FROM personnel WHERE id = ?", (personnel_id,))
    person = cur.fetchone()
    pattern_id = person["work_pattern_id"] if person and person["work_pattern_id"] else None
    if pattern_id:
        cur.execute("SELECT * FROM work_patterns WHERE id = ?", (pattern_id,))
    else:
        cur.execute("SELECT * FROM work_patterns WHERE project_id = ? AND is_default = 1 LIMIT 1", (project_id,))
    pattern = cur.fetchone()
    conn.close()
    return pattern


def get_day_type(date_str, pattern, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT new_type FROM calendar_overrides WHERE project_id = ? AND override_date = ?",
                (project_id, date_str))
    row = cur.fetchone()
    if row:
        conn.close()
        return row["new_type"]
    cur.execute("SELECT id FROM holidays WHERE holiday_date = ?", (date_str,))
    if cur.fetchone():
        conn.close()
        return "تعطیل"
    if not pattern:
        conn.close()
        return "کاری"
    try:
        y, m, d = map(int, date_str.split("/"))
        weekday = jdatetime.date(y, m, d).weekday()
    except:
        conn.close()
        return "کاری"
    rot_weeks = pattern["rotation_weeks"] or 1
    if rot_weeks <= 1:
        week_num = 1
    else:
        try:
            rs = pattern["rotation_start_date"].split("/")
            rot_date = jdatetime.date(int(rs[0]), int(rs[1]), int(rs[2]))
            cur_date = jdatetime.date(y, m, d)
            diff = (cur_date - rot_date).days
            week_num = ((diff // 7) % rot_weeks) + 1
        except:
            week_num = 1
    cur.execute("SELECT day_type FROM work_pattern_days WHERE pattern_id = ? AND week_number = ? AND day_of_week = ?",
                (pattern["id"], week_num, weekday))
    row = cur.fetchone()
    conn.close()
    return row["day_type"] if row else "کاری"


def get_leaves_for_day(personnel_id, date_str, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT leave_type, reason FROM leaves
        WHERE project_id = ? AND personnel_id = ?
          AND start_date <= ? AND end_date >= ?
        LIMIT 1
    """, (project_id, personnel_id, date_str, date_str))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_attendance_for_day(personnel_code, date_str, project_id):
    conn = get_db()
    cur = conn.cursor()
    try:
        y, m, d = map(int, date_str.split("/"))
        greg = jdatetime.date(y, m, d).togregorian()
        greg_str = greg.strftime("%Y-%m-%d")
    except:
        conn.close()
        return None
    cur.execute("""
        SELECT start_time, end_time FROM personnel_attendance
        WHERE project_id = ? AND personnel_code = ? AND work_date = ?
        LIMIT 1
    """, (project_id, personnel_code, greg_str))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_adjustment_for_day(personnel_id, date_str, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT adjusted_start, adjusted_end, note, adjusted_by, adjusted_at FROM attendance_adjustments
        WHERE project_id = ? AND personnel_id = ? AND work_date = ?
    """, (project_id, personnel_id, date_str))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def calculate_day_worked(start_min, end_min, pattern):
    """
    محاسبه کارکرد با منطق:
    ۱. کارکرد رسمی فقط بین [شروع رسمی الگو, پایان رسمی الگو] محاسبه می‌شود
    ۲. زمان قبل از شروع رسمی نادیده گرفته می‌شود (فرد زودتر آمده، پاداش نمی‌گیرد)
    ۳. زمان بعد از پایان رسمی به‌عنوان اضافه‌کاری محاسبه می‌شود
    ۴. وعده‌های غذایی (ناهار/صبحانه/شام) اگر در بازه کاری فرد باشد، کل مدت مقرر کسر می‌شود
    """
    if start_min is None or end_min is None:
        return {"raw": 0, "net": 0, "breaks": 0, "breaks_detail": [], "overtime_extra": 0}

    if pattern and pattern["crosses_midnight"] and end_min < start_min:
        end_min += 24 * 60

    # زمان‌های رسمی الگو
    official_start = None
    official_end = None
    if pattern:
        official_start = time_to_minutes(pattern["work_start"])
        official_end = time_to_minutes(pattern["work_end"])
        # اگر الگو از نصف شب عبور می‌کند
        if pattern["crosses_midnight"] and official_end and official_start and official_end < official_start:
            official_end += 24 * 60

    # کارکرد ناخالص کل (از ورود تا خروج)
    total_raw = end_min - start_min
    if total_raw < 0:
        total_raw = 0

    # === بخش ۱: کارکرد رسمی (بین شروع و پایان رسمی) ===
    if official_start is not None and official_end is not None:
        effective_start = max(start_min, official_start)
        effective_end = min(end_min, official_end)
        regular_raw = max(0, effective_end - effective_start)
    else:
        effective_start = start_min
        effective_end = end_min
        regular_raw = total_raw

    # === بخش ۲: اضافه‌کاری خارج از ساعت رسمی ===
    overtime_extra = 0
    if official_start is not None and official_end is not None:
        # اضافه‌کاری بعد از پایان رسمی
        if end_min > official_end:
            overtime_extra += (end_min - official_end)
        # زمان قبل از شروع رسمی = 0 (فرد زودتر آمده، پاداش نمی‌گیرد)

    # === بخش ۳: کسر وعده‌های غذایی ===
    breaks = 0
    breaks_detail = []
    if pattern:
        meals = [
            ("lunch_start", "lunch_end", "lunch_duration_minutes", "ناهار"),
            ("breakfast_start", "breakfast_end", "breakfast_duration", "صبحانه"),
            ("dinner_start", "dinner_end", "dinner_duration", "شام"),
        ]
        for start_key, end_key, dur_key, name in meals:
            try:
                bs = time_to_minutes(pattern[start_key]) if pattern[start_key] else None
                be = time_to_minutes(pattern[end_key]) if pattern[end_key] else None
                dur = pattern[dur_key] or 0
            except (KeyError, IndexError, TypeError):
                continue

            if dur <= 0:
                continue

            # اگر ساعت وعده مشخص است و کارگر در آن بازه حضور داشت
            if bs is not None and be is not None:
                # عبور از نصف شب برای وعده
                if pattern["crosses_midnight"] and be < bs:
                    be += 24 * 60
                # اگر کارگر در بازه وعده حضور داشت (حتی نصفه) → کل مدت مقرر کسر می‌شود
                if effective_end > bs and effective_start < be:
                    breaks += dur
                    breaks_detail.append(f"{name}: {dur}د")
            else:
                # اگر ساعت وعده مشخص نیست، مستقیم از کارکرد رسمی کسر می‌شود
                breaks += dur
                breaks_detail.append(f"{name}: {dur}د")

    # کارکرد خالص رسمی = کارکرد رسمی - کسر وعده‌ها
    regular_net = regular_raw - breaks
    if regular_net < 0:
        regular_net = 0

    return {
        "raw": total_raw,
        "regular_raw": regular_raw,
        "net": regular_net,
        "breaks": breaks,
        "breaks_detail": breaks_detail,
        "overtime_extra": overtime_extra,
    }


def calculate_monthly_report(personnel_id, year, month, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM personnel WHERE id = ?", (personnel_id,))
    person = cur.fetchone()
    conn.close()
    if not person:
        return None

    pattern = get_active_pattern(project_id, personnel_id)
    days_count = get_days_in_jmonth(year, month)

    rows = []
    total = {
        "work_days": 0, "holiday_days": 0, "present_days": 0,
        "absent_days": 0, "leave_days": 0, "incomplete_days": 0,
        "adjusted_days": 0,
        "net_minutes": 0, "overtime_minutes": 0, "shortage_minutes": 0,
        "late_minutes": 0, "early_minutes": 0, "breaks_minutes": 0,
    }

    for day in range(1, days_count + 1):
        date_str = f"{year}/{month:02d}/{day:02d}"
        try:
            weekday = jdatetime.date(year, month, day).weekday()
            day_name = DAY_NAMES[weekday]
        except:
            day_name = "-"

        day_type = get_day_type(date_str, pattern, project_id)
        leave = get_leaves_for_day(personnel_id, date_str, project_id)
        adjustment = get_adjustment_for_day(personnel_id, date_str, project_id)
        attendance = get_attendance_for_day(person["personnel_code"], date_str, project_id)

        row = {
            "date": date_str, "day": day, "day_name": day_name, "day_type": day_type,
            "leave": leave, "adjustment": adjustment,
            "is_adjusted": bool(adjustment and (adjustment.get("adjusted_start") or adjustment.get("adjusted_end"))),
            "adjustment_note": adjustment.get("note", "") if adjustment else "",
            "adjusted_by": adjustment.get("adjusted_by", "") if adjustment else "",
            "start_time": "-", "end_time": "-",
            "raw": "-", "net": "-", "breaks": "-", "breaks_detail": "",
            "overtime": "-", "late": "-", "early": "-",
            "status": "", "status_color": "#94a3b8",
        }

                # اول از تردد اصلی بگیر
        start_time = attendance["start_time"] if attendance else None
        end_time = attendance["end_time"] if attendance else None
        
        # اگر اصلاح دستی وجود دارد، مقادیر پرشده را اولویت بده
        if adjustment:
            adj_start = adjustment.get("adjusted_start")
            adj_end = adjustment.get("adjusted_end")
            if adj_start and adj_start.strip() and adj_start != "-":
                start_time = adj_start
            if adj_end and adj_end.strip() and adj_end != "-":
                end_time = adj_end

        if leave:
            row["status"] = leave["leave_type"]
            row["status_color"] = "#0891b2"
            total["leave_days"] += 1
            if row["is_adjusted"]:
                total["adjusted_days"] += 1
            rows.append(row)
            continue

        if day_type == "تعطیل":
            row["status"] = "تعطیل"
            row["status_color"] = "#dc2626"
            total["holiday_days"] += 1
            rows.append(row)
            continue

        total["work_days"] += 1

        if not start_time and not end_time:
            row["status"] = "غیبت"
            row["status_color"] = "#b91c1c"
            total["absent_days"] += 1
            rows.append(row)
            continue

        if not end_time or end_time == start_time:
            row["start_time"] = start_time or "-"
            row["end_time"] = "-"
            row["status"] = "ناقص"
            row["status_color"] = "#d97706"
            total["incomplete_days"] += 1
            if row["is_adjusted"]:
                total["adjusted_days"] += 1
            rows.append(row)
            continue

        s_min = time_to_minutes(start_time)
        e_min = time_to_minutes(end_time)
        worked = calculate_day_worked(s_min, e_min, pattern)

        row["start_time"] = start_time
        row["end_time"] = end_time
        row["raw"] = minutes_to_hm(worked["raw"])
        row["net"] = minutes_to_hm(worked["net"])
        row["breaks"] = minutes_to_hm(worked["breaks"]) if worked["breaks"] > 0 else "-"
        row["breaks_detail"] = ", ".join(worked["breaks_detail"]) if worked["breaks_detail"] else ""

        # اضافه‌کاری = زمان بعد از پایان رسمی + کارکرد اضافه بر استاندارد
        overtime = worked["overtime_extra"]  # زمان بعد از پایان رسمی
        late = early = 0

        if pattern:
            std = pattern["daily_work_minutes"] or 480
            # اگر کارکرد خالص از استاندارد کمتر بود → کسر کار
            if worked["net"] < std:
                total["shortage_minutes"] += (std - worked["net"])
            # کارکرد بیش از استاندارد داخل ساعت رسمی هم اضافه‌کاری است
            elif worked["net"] > std:
                overtime += (worked["net"] - std)

            total["overtime_minutes"] += overtime

            expected_start = time_to_minutes(pattern["work_start"])
            expected_end = time_to_minutes(pattern["work_end"])
            late_tol = pattern["late_tolerance_minutes"] or 0
            early_tol = pattern["early_tolerance_minutes"] or 0

            if expected_start and s_min and s_min > expected_start + late_tol:
                late = s_min - expected_start
                total["late_minutes"] += late

            if expected_end and e_min and e_min < expected_end - early_tol:
                early = expected_end - e_min
                total["early_minutes"] += early

        row["overtime"] = minutes_to_hm(overtime) if overtime else "-"
        row["late"] = minutes_to_hm(late) if late else "-"
        row["early"] = minutes_to_hm(early) if early else "-"
        row["net_minutes"] = worked["net"]

        total["net_minutes"] += worked["net"]
        total["breaks_minutes"] += worked["breaks"]
        total["present_days"] += 1

        if row["is_adjusted"]:
            row["status"] = "حاضر (اصلاح شده)"
            row["status_color"] = "#2563eb"
            total["adjusted_days"] += 1
        else:
            row["status"] = "حاضر"
            row["status_color"] = "#15803d"

        rows.append(row)

    summary = {
        "work_days": total["work_days"],
        "holiday_days": total["holiday_days"],
        "present_days": total["present_days"],
        "absent_days": total["absent_days"],
        "leave_days": total["leave_days"],
        "incomplete_days": total["incomplete_days"],
        "adjusted_days": total["adjusted_days"],
        "net_hm": minutes_to_hm(total["net_minutes"]),
        "breaks_hm": minutes_to_hm(total["breaks_minutes"]),
        "overtime_hm": minutes_to_hm(total["overtime_minutes"]),
        "shortage_hm": minutes_to_hm(total["shortage_minutes"]),
        "late_hm": minutes_to_hm(total["late_minutes"]),
        "early_hm": minutes_to_hm(total["early_minutes"]),
        "net_minutes": total["net_minutes"],
        "overtime_minutes": total["overtime_minutes"],
    }

    return {
        "person": dict(person),
        "pattern": dict(pattern) if pattern else None,
        "year": year,
        "month": month,
        "month_name": PERSIAN_MONTHS[month - 1],
        "rows": rows,
        "summary": summary,
    }


def calculate_all_personnel_monthly(project_id, year, month):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, personnel_code, full_name, job_title FROM personnel WHERE project_id = ? AND status = 'فعال'", (project_id,))
    people = cur.fetchall()
    conn.close()
    results = []
    for p in people:
        rep = calculate_monthly_report(p["id"], year, month, project_id)
        if rep:
            results.append({
                "id": p["id"],
                "personnel_code": p["personnel_code"],
                "full_name": p["full_name"],
                "job_title": p["job_title"],
                "summary": rep["summary"],
            })
    return results
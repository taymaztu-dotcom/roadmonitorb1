# -*- coding: utf-8 -*-
"""راه‌انداز یکپارچه RoadMonitor: مهاجرت DB، scheduler و Teltonika TCP + Flask."""
import os, threading
from migrate_production import migrate

def main():
    migrate()
    from teltonika_server import start_server
    t = threading.Thread(target=start_server, name="teltonika-server", daemon=True)
    if os.environ.get("ROADMONITOR_DISABLE_TELTONIKA") != "1":
        t.start()
    from main import app
    app.run(host=os.environ.get("ROADMONITOR_HOST", "0.0.0.0"),
            port=int(os.environ.get("PORT", os.environ.get("ROADMONITOR_PORT", "5050"))),
            debug=False, use_reloader=False)

if __name__ == "__main__":
    main()

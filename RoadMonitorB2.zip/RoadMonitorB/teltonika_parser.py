# -*- coding: utf-8 -*-
"""
پارس بسته‌های Teltonika پروتکل Codec 8 و 8 Extended
مرجع: https://wiki.teltonika-gps.com/view/Codec
"""
import struct
from datetime import datetime, timezone


def parse_imei(data):
    """پارس بسته IMEI (اولین بسته وقتی ردیاب وصل می‌شود)"""
    if len(data) < 2:
        return None
    length = struct.unpack("!H", data[:2])[0]
    if length + 2 > len(data):
        return None
    imei = data[2:2 + length].decode("ascii", errors="ignore")
    return imei


def parse_avl_data(data):
    """
    پارس بسته AVL Data (شامل نقاط GPS)
    خروجی: dict شامل تعداد رکورد و لیست نقاط
    """
    result = {"records": [], "count": 0, "codec_id": 0}
    if len(data) < 20:
        return result

    try:
        # ۴ بایت اول: 0x00000000 (Preamble)
        # ۴ بایت بعد: طول Data
        # ۱ بایت Codec ID
        offset = 8  # skip preamble + data length
        codec_id = data[offset]
        result["codec_id"] = codec_id
        offset += 1

        num_records = data[offset]
        result["count"] = num_records
        offset += 1

        for i in range(num_records):
            if offset + 24 > len(data):
                break
            record = {}

            # Timestamp (8 bytes, ms since 1970)
            ts_ms = struct.unpack("!Q", data[offset:offset + 8])[0]
            offset += 8
            record["timestamp_utc"] = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            record["timestamp_str"] = record["timestamp_utc"].strftime("%Y-%m-%d %H:%M:%S")

            # Priority (1 byte)
            record["priority"] = data[offset]
            offset += 1

            # Longitude (4 bytes, signed int, /10000000)
            record["lng"] = struct.unpack("!i", data[offset:offset + 4])[0] / 10000000.0
            offset += 4

            # Latitude (4 bytes)
            record["lat"] = struct.unpack("!i", data[offset:offset + 4])[0] / 10000000.0
            offset += 4

            # Altitude (2 bytes)
            record["altitude"] = struct.unpack("!h", data[offset:offset + 2])[0]
            offset += 2

            # Angle (2 bytes)
            record["angle"] = struct.unpack("!H", data[offset:offset + 2])[0]
            offset += 2

            # Satellites (1 byte)
            record["satellites"] = data[offset]
            offset += 1

            # Speed (2 bytes, km/h)
            record["speed"] = struct.unpack("!H", data[offset:offset + 2])[0]
            offset += 2

            # IO Data
            # Event IO ID (1 byte for codec 8, 2 bytes for 8E)
            if codec_id == 0x8E:
                record["event_io_id"] = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
                n_total = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
            else:  # Codec 8
                record["event_io_id"] = data[offset]
                offset += 1
                n_total = data[offset]
                offset += 1

            io_data = {}

            # N1: 1-byte values
            if codec_id == 0x8E:
                n1 = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
            else:
                n1 = data[offset]
                offset += 1
            for _ in range(n1):
                if codec_id == 0x8E:
                    io_id = struct.unpack("!H", data[offset:offset + 2])[0]
                    offset += 2
                else:
                    io_id = data[offset]
                    offset += 1
                io_data[io_id] = data[offset]
                offset += 1

            # N2: 2-byte values
            if codec_id == 0x8E:
                n2 = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
            else:
                n2 = data[offset]
                offset += 1
            for _ in range(n2):
                if codec_id == 0x8E:
                    io_id = struct.unpack("!H", data[offset:offset + 2])[0]
                    offset += 2
                else:
                    io_id = data[offset]
                    offset += 1
                io_data[io_id] = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2

            # N4: 4-byte values
            if codec_id == 0x8E:
                n4 = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
            else:
                n4 = data[offset]
                offset += 1
            for _ in range(n4):
                if codec_id == 0x8E:
                    io_id = struct.unpack("!H", data[offset:offset + 2])[0]
                    offset += 2
                else:
                    io_id = data[offset]
                    offset += 1
                io_data[io_id] = struct.unpack("!I", data[offset:offset + 4])[0]
                offset += 4

            # N8: 8-byte values
            if codec_id == 0x8E:
                n8 = struct.unpack("!H", data[offset:offset + 2])[0]
                offset += 2
            else:
                n8 = data[offset]
                offset += 1
            for _ in range(n8):
                if codec_id == 0x8E:
                    io_id = struct.unpack("!H", data[offset:offset + 2])[0]
                    offset += 2
                else:
                    io_id = data[offset]
                    offset += 1
                io_data[io_id] = struct.unpack("!Q", data[offset:offset + 8])[0]
                offset += 8

            # مقادیر معنادار Teltonika:
            record["ignition"] = io_data.get(239, 0)          # IO 239: Ignition
            record["movement"] = io_data.get(240, 0)          # IO 240: Movement
            record["gsm_signal"] = io_data.get(21, 0)         # IO 21: GSM Signal
            record["external_voltage"] = io_data.get(66, 0) / 1000.0  # mV → V
            record["battery_voltage"] = io_data.get(67, 0) / 1000.0
            record["odometer"] = io_data.get(199, 0)          # IO 199: Total odometer
            record["io_data"] = io_data

            result["records"].append(record)

        return result
    except Exception as e:
        result["error"] = str(e)
        return result


def build_response(count):
    """پاسخ سرور به Teltonika پس از دریافت رکوردها (4 بایت: تعداد پذیرفته‌شده)"""
    return struct.pack("!I", count)


def build_imei_ack(accept=True):
    """پاسخ به بسته IMEI: 01 = پذیرش، 00 = رد"""
    return b"\x01" if accept else b"\x00"
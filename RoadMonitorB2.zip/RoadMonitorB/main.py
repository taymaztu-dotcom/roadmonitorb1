import os
import io
import json
import random
import functools
import datetime
import jdatetime
import sqlite3
from flask import Flask, render_template, request, redirect, jsonify, session, url_for, send_file
from date_utils import register_filters
from report_engine import calculate_monthly_report, calculate_all_personnel_monthly, PERSIAN_MONTHS
from analysis_engine import run_full_analysis, run_analysis_for_all_machines
from analysis_engine_v2 import run_typed_analysis, get_type_settings
from telegram_provider import send_message as tg_send, send_document as tg_send_doc, test_connection as tg_test
from pdf_report import generate_daily_pdf
from roles_blueprint import register_phase_e
from permissions import user_has_permission, get_user_permissions
from scheduler import start_scheduler, update_daily_report_time, run_job_now, get_scheduler_status
from alert_engine import run_all_checks
from anpr_engine import (
    process_anpr_event, get_events as anpr_get_events,
    get_cameras as anpr_get_cameras, get_whitelist as anpr_get_whitelist,
    normalize_plate, format_plate_display
)
from corridor_engine import (
    get_active_corridor, get_corridor_waypoints, calculate_corridor_length,
    locate_point_on_corridor, save_corridor, update_gps_corridor_data,
    get_machines_km_status, get_daily_km_range, format_km
)

app = Flask(__name__)
register_filters(app)
app.secret_key = os.environ.get("ROADMONITOR_SECRET_KEY", "roadmonitor-secret-key-2025-b")
app.config["SESSION_COOKIE_NAME"] = "roadmonitor_b_session"
app.config["PERMANENT_SESSION_LIFETIME"] = datetime.timedelta(days=30)
app.config["SESSION_REFRESH_EACH_REQUEST"] = True
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("ROADMONITOR_COOKIE_SECURE", "0") == "1"

from werkzeug.security import check_password_hash, generate_password_hash

def verify_password(stored, candidate):
    if not stored:
        return False
    if str(stored).startswith(("pbkdf2:", "scrypt:", "argon2:")):
        try:
            return check_password_hash(stored, candidate)
        except Exception:
            return False
    return stored == candidate

def hash_password(password):
    return generate_password_hash(password)

DEVELOPER_NAME = "تیم تحقیق و توسعه (R&D) شرکت پی گستران شمال غرب - دکتر سعید داداشی"

DAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]
DAY_TYPES = ["کاری", "تعطیل", "نیمه‌تعطیل"]
LEAVE_TYPES = ["مرخصی استحقاقی", "مرخصی استعلاجی", "مرخصی بدون حقوق", "مأموریت"]
SINGLE_PUNCH_OPTIONS = ["ناقص", "پیش‌فرض خروج", "نصف روز غیبت"]
OPERATIONAL_TYPES = ["برگشتی", "مستقر در جبهه کار", "ترکیبی", "فاقد GPS"]
EXCEPTION_TYPES = ["خرابی دستگاه", "تعمیرات", "سوخت‌گیری", "خرابی مسیر", "بارندگی",
                   "شرایط ایمنی", "دستور سرپرست", "کمبود مصالح", "نبود کامیون",
                   "صف بارگیری", "انتظار لودر", "انسداد مسیر", "حادثه", "مأموریت",
                   "مرخصی", "تعطیلی کارگاه", "اضافه‌کار مصوب", "ناهار یا استراحت مجاز"]
EXCEPTION_SUBJECT_TYPES = ["ماشین", "پرسنل", "کارگاه"]
ZONE_TYPES = ["کارگاه", "بارگیری", "تخلیه", "پارک شبانه", "جبهه کار", "سوخت‌گیری", "تعمیرگاه", "سایر"]


def get_db():
    connection = sqlite3.connect("roadmonitor.db", timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def get_setting(key, default=""):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
    connection.close()
    return row["value"] if row else default


def set_setting(key, value):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    connection.commit()
    connection.close()


def current_project_id():
    return session.get("project_id")


def get_current_project():
    pid = current_project_id()
    if not pid:
        return None
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM projects WHERE id = ?", (pid,))
    row = cursor.fetchone()
    connection.close()
    return dict(row) if row else None


def get_projects():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM projects ORDER BY id DESC")
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_users():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT id, username, full_name, role, phone FROM users ORDER BY id DESC")
    rows = cursor.fetchall()
    connection.close()
    return rows


def log_audit(entity_type, entity_id, action, field_name="", old_value="", new_value="", reason=""):
    try:
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO audit_log (project_id, entity_type, entity_id, action,
                field_name, old_value, new_value, reason, user_username, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            current_project_id(), entity_type, entity_id, action,
            field_name, str(old_value)[:500], str(new_value)[:500], reason,
            session.get("username", ""), request.remote_addr if request else "",
            datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ))
        connection.commit()
        connection.close()
    except Exception as e:
        print(f"[audit_log error] {e}")


@app.before_request
def keep_session_alive():
    session.permanent = True
    if session.get("user_id") and not session.get("role"):
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("SELECT role, username FROM users WHERE id = ?", (session.get("user_id"),))
        user = cursor.fetchone()
        connection.close()
        if user:
            session["role"] = user["role"] or ("مدیر" if user["username"] == "admin" else "کاربر")
            session["username"] = session.get("username") or user["username"]


def login_required(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        if not session.get("project_id") and request.endpoint not in [
            "select_project", "add_project", "logout", "settings", "projects",
            "users", "add_user", "change_password", "attendance_device"
        ]:
            return redirect(url_for("select_project"))
        return view_func(*args, **kwargs)
    return wrapper


def admin_required(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        keep_session_alive()
        if session.get("role") != "مدیر" and session.get("username") != "admin":
            return redirect("/")
        return view_func(*args, **kwargs)
    return wrapper


def normalize_time_input(t):
    if not t:
        return ""
    text = str(t).strip()
    persian = "۰۱۲۳۴۵۶۷۸۹"
    for i, d in enumerate(persian):
        text = text.replace(d, str(i))
    text = text.replace("/", ":").replace(".", ":").replace("،", ":").replace(" ", "")
    if ":" not in text:
        return text
    try:
        parts = text.split(":")
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23 and 0 <= m <= 59:
            return f"{h:02d}:{m:02d}"
    except:
        pass
    return text


def calculate_minutes(start_time, end_time):
    s = normalize_time_input(start_time)
    e = normalize_time_input(end_time)
    if not s or ":" not in s or not e or ":" not in e:
        return None
    try:
        sh, sm = map(int, s.split(":"))
        eh, em = map(int, e.split(":"))
        return (eh * 60 + em) - (sh * 60 + sm)
    except:
        return None


def format_minutes(minutes):
    if minutes is None:
        return "نامشخص"
    sign = ""
    if minutes < 0:
        sign = "منفی "
        minutes = abs(minutes)
    return f"{sign}{minutes // 60} ساعت و {minutes % 60} دقیقه"


def calculate_duration(start_time, end_time):
    return format_minutes(calculate_minutes(start_time, end_time))


def get_machines():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE project_id = ?", (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_machine(machine_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE id = ? AND project_id = ?", (machine_id, current_project_id()))
    row = cursor.fetchone()
    connection.close()
    return row


def get_person(person_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM personnel WHERE id = ? AND project_id = ?", (person_id, current_project_id()))
    row = cursor.fetchone()
    connection.close()
    return row


def get_latest_gps_points(project_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT g.machine_code, g.lat, g.lng, g.speed, g.recorded_at
        FROM gps_points g
        INNER JOIN (SELECT machine_code, MAX(id) AS max_id FROM gps_points WHERE project_id = ? GROUP BY machine_code) latest ON g.id = latest.max_id
        WHERE g.project_id = ?
    """, (project_id, project_id))
    rows = cursor.fetchall()
    connection.close()
    return {row["machine_code"]: dict(row) for row in rows}


def get_machines_with_location():
    rows = get_machines()
    latest_points = get_latest_gps_points(current_project_id())
    result = []
    for index, row in enumerate(rows):
        item = dict(row)
        point = latest_points.get(item.get("code"), {})
        lat = point.get("lat") or item.get("lat")
        lng = point.get("lng") or item.get("lng")
        if not lat or not lng:
            lat = 35.70 + index * 0.01
            lng = 51.40 + index * 0.01
        result.append({
            "code": item.get("code"), "name": item.get("name"), "type": item.get("type"),
            "operational_type": item.get("operational_type"),
            "lat": lat, "lng": lng, "speed": point.get("speed", 0),
            "recorded_at": point.get("recorded_at", ""), "has_real_point": bool(point),
        })
    return result


def save_gps_point(project_id, machine_code, lat, lng, speed=0, recorded_at=None):
    if not recorded_at:
        recorded_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("INSERT INTO gps_points (project_id, machine_code, lat, lng, speed, recorded_at) VALUES (?, ?, ?, ?, ?, ?)",
                   (project_id, machine_code, lat, lng, speed, recorded_at))
    cursor.execute("UPDATE machines SET lat = ?, lng = ? WHERE code = ? AND project_id = ?",
                   (lat, lng, machine_code, project_id))
    connection.commit()
    connection.close()


def get_worklogs():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT work_logs.*, machines.name AS machine_name, machines.driver AS driver_name
        FROM work_logs LEFT JOIN machines ON work_logs.machine_code = machines.code
        WHERE work_logs.project_id = ? ORDER BY work_logs.id DESC
    """, (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    result = []
    for row in rows:
        item = dict(row)
        item["duration"] = calculate_duration(item["start_time"], item["end_time"])
        result.append(item)
    return result


def get_report():
    return get_worklogs()


def get_personnel():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT personnel.*, work_patterns.pattern_name AS pattern_name
        FROM personnel LEFT JOIN work_patterns ON personnel.work_pattern_id = work_patterns.id
        WHERE personnel.project_id = ?
    """, (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_personnel_attendance():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT personnel_attendance.*, personnel.full_name, personnel.job_title
        FROM personnel_attendance LEFT JOIN personnel ON personnel_attendance.personnel_code = personnel.personnel_code
        WHERE personnel_attendance.project_id = ? ORDER BY personnel_attendance.id DESC
    """, (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    return [dict(r) for r in rows]


def get_zk_logs(limit=200):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT zk_logs.*, personnel.full_name
        FROM zk_logs LEFT JOIN personnel ON zk_logs.personnel_code = personnel.personnel_code
        WHERE zk_logs.project_id = ? ORDER BY zk_logs.punch_time DESC LIMIT ?
    """, (current_project_id(), limit))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_persian_today():
    today = jdatetime.date.today()
    persian_days = ["شنبه", "یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]
    return f"{persian_days[today.weekday()]}   {today.year}/{today.month:02d}/{today.day:02d}"


def get_persian_month_name(year, month):
    persian_months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                      "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
    return f"{persian_months[month-1]} {year}"


def connect_zk_device():
    try:
        from zk import ZK
    except ImportError:
        raise Exception("کتابخانه pyzk نصب نیست")
    ip = get_setting("zk_ip", "192.168.1.201")
    port = int(get_setting("zk_port", "4370") or 4370)
    password = int(get_setting("zk_password", "0") or 0)
    zk = ZK(ip, port=port, timeout=8, password=password, force_udp=False, ommit_ping=False)
    conn = zk.connect()
    if not conn:
        raise Exception("اتصال به دستگاه برقرار نشد")
    return conn


def pull_zk_attendance():
    conn = None
    saved = 0
    mapped = 0
    try:
        conn = connect_zk_device()
        conn.disable_device()
        records = conn.get_attendance() or []
        conn.enable_device()
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("SELECT personnel_code, device_user_id FROM personnel WHERE project_id = ?", (current_project_id(),))
        mapping = {str(row["device_user_id"]): row["personnel_code"] for row in cursor.fetchall() if row["device_user_id"]}
        for rec in records:
            user_id = str(getattr(rec, "user_id", "") or getattr(rec, "uid", ""))
            punch_time = getattr(rec, "timestamp", None)
            punch_type = str(getattr(rec, "punch", ""))
            status = str(getattr(rec, "status", ""))
            if not user_id or not punch_time:
                continue
            punch_time_text = punch_time.strftime("%Y-%m-%d %H:%M:%S") if hasattr(punch_time, "strftime") else str(punch_time)
            personnel_code = mapping.get(user_id, "")
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO zk_logs (project_id, device_user_id, punch_time, punch_type, status, personnel_code, imported_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (current_project_id(), user_id, punch_time_text, punch_type, status, personnel_code, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                if cursor.rowcount:
                    saved += 1
            except Exception:
                continue
        cursor.execute("""
            SELECT personnel_code, substr(punch_time, 1, 10) AS work_date,
                   MIN(substr(punch_time, 12, 5)) AS start_time,
                   MAX(substr(punch_time, 12, 5)) AS end_time
            FROM zk_logs WHERE project_id = ? AND personnel_code IS NOT NULL AND personnel_code != ''
            GROUP BY personnel_code, substr(punch_time, 1, 10)
        """, (current_project_id(),))
        grouped = cursor.fetchall()
        for row in grouped:
            cursor.execute("SELECT id FROM personnel_attendance WHERE project_id = ? AND personnel_code = ? AND work_date = ?",
                           (current_project_id(), row["personnel_code"], row["work_date"]))
            existing = cursor.fetchone()
            if existing:
                cursor.execute("UPDATE personnel_attendance SET start_time = ?, end_time = ? WHERE id = ?",
                               (row["start_time"], row["end_time"], existing["id"]))
            else:
                cursor.execute("INSERT INTO personnel_attendance (personnel_code, work_date, start_time, end_time, project_id) VALUES (?, ?, ?, ?, ?)",
                               (row["personnel_code"], row["work_date"], row["start_time"], row["end_time"], current_project_id()))
                mapped += 1
        connection.commit()
        connection.close()
        return {"saved": saved, "mapped": mapped, "total": len(records)}
    finally:
        if conn:
            try:
                conn.disconnect()
            except Exception:
                pass


def get_work_patterns():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM work_patterns WHERE project_id = ? ORDER BY id DESC", (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_work_pattern(pattern_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM work_patterns WHERE id = ? AND project_id = ?", (pattern_id, current_project_id()))
    row = cursor.fetchone()
    connection.close()
    return row


def get_pattern_days(pattern_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM work_pattern_days WHERE pattern_id = ? ORDER BY week_number, day_of_week", (pattern_id,))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_holidays(year=None):
    connection = get_db()
    cursor = connection.cursor()
    if year:
        cursor.execute("SELECT * FROM holidays WHERE year = ? ORDER BY holiday_date", (year,))
    else:
        cursor.execute("SELECT * FROM holidays ORDER BY holiday_date")
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_leaves(project_id=None):
    pid = project_id or current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT leaves.*, personnel.full_name FROM leaves
        LEFT JOIN personnel ON leaves.personnel_id = personnel.id
        WHERE leaves.project_id = ? ORDER BY leaves.id DESC
    """, (pid,))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_zones():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM zones WHERE project_id = ? ORDER BY zone_type, zone_name", (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_zone(zone_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM zones WHERE id = ? AND project_id = ?", (zone_id, current_project_id()))
    row = cursor.fetchone()
    connection.close()
    return row


def get_exceptions(project_id=None, limit=200):
    pid = project_id or current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT e.*,
            CASE WHEN e.subject_type = 'ماشین' THEN m.name
                 WHEN e.subject_type = 'پرسنل' THEN p.full_name
                 ELSE '-' END AS subject_name
        FROM exceptions e
        LEFT JOIN machines m ON e.subject_type = 'ماشین' AND e.subject_id = m.id
        LEFT JOIN personnel p ON e.subject_type = 'پرسنل' AND e.subject_id = p.id
        WHERE e.project_id = ? ORDER BY e.id DESC LIMIT ?
    """, (pid, limit))
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_audit_logs(entity_type=None, entity_id=None, limit=100):
    connection = get_db()
    cursor = connection.cursor()
    if entity_type and entity_id:
        cursor.execute("SELECT * FROM audit_log WHERE project_id = ? AND entity_type = ? AND entity_id = ? ORDER BY id DESC LIMIT ?",
                       (current_project_id(), entity_type, entity_id, limit))
    else:
        cursor.execute("SELECT * FROM audit_log WHERE project_id = ? ORDER BY id DESC LIMIT ?",
                       (current_project_id(), limit))
    rows = cursor.fetchall()
    connection.close()
    return rows


def jalali_to_weekday(date_str):
    try:
        parts = date_str.split("/")
        jd = jdatetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
        return jd.weekday()
    except Exception:
        return None


def jalali_to_greg(date_jalali):
    try:
        parts = date_jalali.split("/")
        greg = jdatetime.date(int(parts[0]), int(parts[1]), int(parts[2])).togregorian()
        return greg.strftime("%Y-%m-%d")
    except:
        return datetime.date.today().strftime("%Y-%m-%d")


def get_day_status(date_str, pattern_id, project_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM calendar_overrides WHERE project_id = ? AND override_date = ?", (project_id, date_str))
    override = cursor.fetchone()
    if override:
        connection.close()
        return override["new_type"]
    cursor.execute("SELECT * FROM holidays WHERE holiday_date = ?", (date_str,))
    holiday = cursor.fetchone()
    if holiday:
        connection.close()
        return "تعطیل"
    if not pattern_id:
        connection.close()
        return "کاری"
    cursor.execute("SELECT * FROM work_patterns WHERE id = ?", (pattern_id,))
    pattern = cursor.fetchone()
    if not pattern:
        connection.close()
        return "کاری"
    weekday = jalali_to_weekday(date_str)
    if weekday is None:
        connection.close()
        return "کاری"
    rotation_weeks = pattern["rotation_weeks"] or 1
    if rotation_weeks <= 1:
        week_num = 1
    else:
        rot_start = pattern["rotation_start_date"]
        try:
            rot_parts = rot_start.split("/")
            rot_date = jdatetime.date(int(rot_parts[0]), int(rot_parts[1]), int(rot_parts[2]))
            date_parts = date_str.split("/")
            cur_date = jdatetime.date(int(date_parts[0]), int(date_parts[1]), int(date_parts[2]))
            diff_days = (cur_date - rot_date).days
            week_index = (diff_days // 7) % rotation_weeks
            week_num = week_index + 1
        except Exception:
            week_num = 1
    cursor.execute("SELECT * FROM work_pattern_days WHERE pattern_id = ? AND week_number = ? AND day_of_week = ?",
                   (pattern_id, week_num, weekday))
    day_row = cursor.fetchone()
    connection.close()
    if day_row:
        return day_row["day_type"]
    return "کاری"


@app.context_processor
def inject_globals():
    return {
        "company_name": get_setting("company_name", "شرکت راهسازی و عمرانی"),
        "developer_name": DEVELOPER_NAME,
        "current_project": get_current_project(),
        "is_admin": session.get("role") == "مدیر" or session.get("username") == "admin",
    }


@app.context_processor
def inject_permissions():
    uid = session.get("user_id")
    if not uid:
        return {"my_perms": set(), "can": lambda p: False}
    perms = get_user_permissions(uid, get_db)
    return {
        "my_perms": perms,
        "can": lambda p: p in perms or session.get("username") == "admin"
    }


def get_dashboard_data():
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM machines WHERE project_id = ?", (pid,))
    total_machines = cursor.fetchone()["c"]
    cursor.execute("SELECT COUNT(*) AS c FROM machines WHERE project_id = ? AND active_status = 'فعال'", (pid,))
    active_machines = cursor.fetchone()["c"]
    cursor.execute("SELECT COUNT(*) AS c FROM personnel WHERE project_id = ?", (pid,))
    total_personnel = cursor.fetchone()["c"]
    cursor.execute("SELECT COUNT(*) AS c FROM personnel WHERE project_id = ? AND status = 'فعال'", (pid,))
    active_personnel = cursor.fetchone()["c"]
    cursor.execute("SELECT COUNT(*) AS c FROM work_logs WHERE project_id = ?", (pid,))
    total_worklogs = cursor.fetchone()["c"]
    cursor.execute("SELECT COUNT(*) AS c FROM personnel_attendance WHERE project_id = ?", (pid,))
    total_attendance = cursor.fetchone()["c"]
    cursor.execute("""
        SELECT work_logs.*, machines.name AS machine_name
        FROM work_logs LEFT JOIN machines ON work_logs.machine_code = machines.code
        WHERE work_logs.project_id = ? ORDER BY work_logs.id DESC LIMIT 5
    """, (pid,))
    recent_worklogs = cursor.fetchall()
    cursor.execute("""
        SELECT personnel_attendance.*, personnel.full_name
        FROM personnel_attendance LEFT JOIN personnel ON personnel_attendance.personnel_code = personnel.personnel_code
        WHERE personnel_attendance.project_id = ? ORDER BY personnel_attendance.id DESC LIMIT 5
    """, (pid,))
    recent_attendance = cursor.fetchall()
    connection.close()
    return {
        "total_machines": total_machines, "active_machines": active_machines,
        "total_personnel": total_personnel, "active_personnel": active_personnel,
        "total_worklogs": total_worklogs, "total_attendance": total_attendance,
        "recent_worklogs": recent_worklogs, "recent_attendance": recent_attendance,
        "today_date": get_persian_today(),
    }


# ═══════════ AUTH ═══════════

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        connection.close()
        if user and verify_password(user["password"], password):
            # مهاجرت تدریجی رمزهای قدیمی plaintext به hash
            if not str(user["password"]).startswith(("pbkdf2:", "scrypt:", "argon2:")):
                c=get_db(); c.execute("UPDATE users SET password=? WHERE id=?", (hash_password(password), user["id"])); c.commit(); c.close()
            session.clear()
            session.permanent = True
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"] or ("مدیر" if user["username"] == "admin" else "کاربر")
            projects = get_projects()
            if len(projects) == 1:
                session["project_id"] = projects[0]["id"]
                return redirect("/")
            return redirect(url_for("select_project"))
        error = "نام کاربری یا رمز عبور اشتباه است"
    bg_number = datetime.datetime.now().microsecond % 1000
    return render_template("login.html", error=error, bg_number=bg_number, company_name=get_setting("company_name", "شرکت راهسازی و عمرانی"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/forgot_password", methods=["GET", "POST"])
def forgot_password():
    message = None
    error = None
    generated_code = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        phone = request.form.get("phone", "").strip()
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND IFNULL(phone, '') = ?", (username, phone))
        user = cursor.fetchone()
        if not user:
            error = "نام کاربری یا شماره تلفن پیدا نشد"
        elif not phone:
            error = "برای این کاربر شماره تلفن ثبت نشده است"
        else:
            code = str(random.randint(100000, 999999))
            cursor.execute("INSERT INTO password_resets (username, phone, code, created_at, used) VALUES (?, ?, ?, ?, ?)",
                           (username, phone, code, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 0))
            connection.commit()
            session["reset_username"] = username
            generated_code = code
            message = "پیامک هنوز فعال نیست. کد بازیابی برای تست ساخته شد."
        connection.close()
    bg_number = datetime.datetime.now().microsecond % 1000
    return render_template("forgot_password.html", error=error, message=message, generated_code=generated_code, bg_number=bg_number, company_name=get_setting("company_name", "شرکت راهسازی و عمرانی"))


@app.route("/reset_password", methods=["GET", "POST"])
def reset_password():
    error = None
    message = None
    if request.method == "POST":
        username = session.get("reset_username") or request.form.get("username", "").strip()
        code = request.form.get("code", "").strip()
        new_password = request.form.get("new_password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()
        if new_password != confirm_password:
            error = "رمز جدید و تکرار آن یکی نیست"
        elif len(new_password) < 4:
            error = "رمز عبور باید حداقل ۴ کاراکتر باشد"
        else:
            connection = get_db()
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM password_resets WHERE username = ? AND code = ? AND used = 0 ORDER BY id DESC LIMIT 1", (username, code))
            reset_row = cursor.fetchone()
            if not reset_row:
                error = "کد بازیابی اشتباه است"
            else:
                cursor.execute("UPDATE users SET password = ? WHERE username = ?", (hash_password(new_password), username))
                cursor.execute("UPDATE password_resets SET used = 1 WHERE id = ?", (reset_row["id"],))
                connection.commit()
                message = "رمز عبور با موفقیت تغییر کرد. حالا وارد شوید."
            connection.close()
    bg_number = datetime.datetime.now().microsecond % 1000
    return render_template("reset_password.html", error=error, message=message, bg_number=bg_number, company_name=get_setting("company_name", "شرکت راهسازی و عمرانی"))


@app.route("/change_password", methods=["GET", "POST"])
@login_required
def change_password():
    error = None
    message = None
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (session.get("user_id"),))
    user = cursor.fetchone()
    if request.method == "POST":
        old_password = request.form.get("old_password", "").strip()
        new_password = request.form.get("new_password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()
        phone = request.form.get("phone", "").strip()
        if not user or not verify_password(user["password"], old_password):
            error = "رمز فعلی اشتباه است"
        elif new_password and new_password != confirm_password:
            error = "رمز جدید و تکرار آن یکی نیست"
        elif new_password and len(new_password) < 4:
            error = "رمز عبور باید حداقل ۴ کاراکتر باشد"
        else:
            if new_password:
                cursor.execute("UPDATE users SET password = ?, phone = ? WHERE id = ?", (hash_password(new_password), phone, session.get("user_id")))
            else:
                cursor.execute("UPDATE users SET phone = ? WHERE id = ?", (phone, session.get("user_id")))
            connection.commit()
            message = "اطلاعات حساب ذخیره شد"
            cursor.execute("SELECT * FROM users WHERE id = ?", (session.get("user_id"),))
            user = cursor.fetchone()
    connection.close()
    return render_template("change_password.html", error=error, message=message, user=user)


@app.route("/users")
@admin_required
def users():
    return render_template("users.html", users=get_users())


@app.route("/add_user", methods=["GET", "POST"])
@admin_required
def add_user():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "کاربر")
        phone = request.form.get("phone", "").strip()
        if not username or not password or not full_name:
            error = "نام کاربری، رمز و نام کامل لازم است"
        else:
            connection = get_db()
            cursor = connection.cursor()
            try:
                cursor.execute("INSERT INTO users (username, password, full_name, role, phone) VALUES (?, ?, ?, ?, ?)",
                               (username, hash_password(password), full_name, role, phone))
                connection.commit()
                connection.close()
                return redirect("/users")
            except sqlite3.IntegrityError:
                error = "این نام کاربری قبلاً ثبت شده است"
                connection.close()
    return render_template("add_user.html", error=error)


@app.route("/select_project", methods=["GET", "POST"])
def select_project():
    if not session.get("user_id"):
        return redirect(url_for("login"))
    if request.method == "POST":
        session.permanent = True
        session["project_id"] = int(request.form["project_id"])
        return redirect("/")
    return render_template("select_project.html", projects=get_projects())


@app.route("/projects")
@login_required
def projects():
    return render_template("projects.html", projects=get_projects())


@app.route("/add_project", methods=["GET", "POST"])
@login_required
def add_project():
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO projects (name, location, start_date, description, status) VALUES (?, ?, ?, ?, ?)",
                       (request.form.get("name", "").strip(), request.form.get("location", "").strip(), request.form.get("start_date", "").strip(), request.form.get("description", "").strip(), request.form.get("status", "فعال")))
        connection.commit()
        connection.close()
        return redirect("/projects")
    return render_template("add_project.html")


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if request.method == "POST":
        set_setting("company_name", request.form.get("company_name", "").strip())
        pid = current_project_id()
        if pid:
            connection = get_db()
            cursor = connection.cursor()
            cursor.execute("UPDATE projects SET name = ?, location = ?, start_date = ?, description = ?, status = ? WHERE id = ?",
                           (request.form.get("project_name", "").strip(), request.form.get("location", "").strip(), request.form.get("start_date", "").strip(), request.form.get("description", "").strip(), request.form.get("project_status", "فعال"), pid))
            connection.commit()
            connection.close()
        return redirect("/settings")
    return render_template("settings.html", company_name=get_setting("company_name", "شرکت راهسازی و عمرانی"), project=get_current_project())


@app.route("/attendance_device", methods=["GET", "POST"])
@login_required
def attendance_device():
    message = None
    error = None
    if request.method == "POST":
        action = request.form.get("action")
        if action == "save":
            set_setting("zk_ip", request.form.get("zk_ip", "").strip())
            set_setting("zk_port", request.form.get("zk_port", "4370").strip())
            set_setting("zk_password", request.form.get("zk_password", "0").strip())
            message = "تنظیمات دستگاه ذخیره شد"
        elif action == "test":
            conn = None
            try:
                conn = connect_zk_device()
                info = ""
                try:
                    info = f" | تعداد کاربر دستگاه: {len(conn.get_users() or [])}"
                except Exception:
                    pass
                message = "اتصال موفق بود" + info
            except Exception as exc:
                error = str(exc)
            finally:
                if conn:
                    try:
                        conn.disconnect()
                    except Exception:
                        pass
        elif action == "sync":
            try:
                result = pull_zk_attendance()
                message = f"همگام‌سازی انجام شد. کل رکورد دستگاه: {result['total']} | جدید: {result['saved']} | روزهای ساخته‌شده: {result['mapped']}"
            except Exception as exc:
                error = str(exc)
    return render_template("attendance_device.html",
                           zk_ip=get_setting("zk_ip", "192.168.1.201"),
                           zk_port=get_setting("zk_port", "4370"),
                           zk_password=get_setting("zk_password", "0"),
                           logs=get_zk_logs(), message=message, error=error)


@app.route("/")
@login_required
def home():
    return render_template("dashboard.html", data=get_dashboard_data())


@app.route("/api/dashboard")
@login_required
def api_dashboard():
    data = get_dashboard_data()
    data["recent_worklogs"] = [dict(r) for r in data["recent_worklogs"]]
    data["recent_attendance"] = [dict(r) for r in data["recent_attendance"]]
    return jsonify(data)


@app.route("/api/machines_locations")
@login_required
def api_machines_locations():
    return jsonify(get_machines_with_location())


@app.route("/api/gps", methods=["POST"])
@login_required
def api_gps():
    machine_code = request.form.get("machine_code") or (request.json.get("machine_code") if request.is_json else None)
    lat = request.form.get("lat") or (request.json.get("lat") if request.is_json else None)
    lng = request.form.get("lng") or (request.json.get("lng") if request.is_json else None)
    speed = request.form.get("speed") or (request.json.get("speed") if request.is_json else 0)
    if not machine_code or not lat or not lng:
        return jsonify({"ok": False, "message": "اطلاعات ناقص است"}), 400
    save_gps_point(current_project_id(), machine_code, float(lat), float(lng), float(speed or 0))
    return jsonify({"ok": True})


@app.route("/gps_test")
@login_required
def gps_test():
    return render_template("gps_test.html", machines=get_machines())


@app.route("/machines")
@login_required
def machines():
    return render_template("machines.html", machines=get_machines())


@app.route("/map")
@login_required
def machines_map():
    return render_template("map.html", machines_json=json.dumps(get_machines_with_location(), ensure_ascii=False))


@app.route("/add_machine_form")
@login_required
def add_machine_form():
    return render_template("add_machine.html", operational_types=OPERATIONAL_TYPES, zones=get_zones())


@app.route("/add_machine", methods=["POST"])
@login_required
def add_machine():
    connection = get_db()
    cursor = connection.cursor()
    npz = request.form.get("night_park_zone_id") or None
    if npz:
        npz = int(npz)
    cursor.execute("""
        INSERT INTO machines (code, name, type, plate, driver, gps_code, gps_type,
            manufacture_date, serial_number, operation_status, active_status, project_id,
            operational_type, imei, has_gps, night_park_zone_id, sim_card_number,
            sim_operator, installation_notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (request.form["code"], request.form["name"], request.form["type"], request.form["plate"],
          request.form["driver"], request.form["gps_code"], request.form["gps_type"],
          request.form["manufacture_date"], request.form["serial_number"], request.form["operation_status"],
          request.form["active_status"], current_project_id(),
          request.form.get("operational_type", "برگشتی"),
          request.form.get("imei", ""),
          1 if request.form.get("has_gps") == "1" else 0,
          npz, request.form.get("sim_card_number", ""),
          request.form.get("sim_operator", ""), request.form.get("installation_notes", "")))
    machine_id = cursor.lastrowid
    connection.commit()
    connection.close()
    log_audit("machine", machine_id, "افزودن", new_value=request.form["name"])
    return redirect("/machines")


@app.route("/edit_machine/<int:machine_id>", methods=["GET", "POST"])
@login_required
def edit_machine(machine_id):
    machine = get_machine(machine_id)
    if not machine:
        return redirect("/machines")
    if request.method == "POST":
        old_name = machine["name"]
        connection = get_db()
        cursor = connection.cursor()
        npz = request.form.get("night_park_zone_id") or None
        if npz:
            npz = int(npz)
        cursor.execute("""
            UPDATE machines
            SET code = ?, name = ?, type = ?, plate = ?, driver = ?, gps_code = ?, gps_type = ?,
                manufacture_date = ?, serial_number = ?, operation_status = ?, active_status = ?,
                operational_type = ?, imei = ?, has_gps = ?, night_park_zone_id = ?,
                sim_card_number = ?, sim_operator = ?, installation_notes = ?
            WHERE id = ? AND project_id = ?
        """, (request.form["code"], request.form["name"], request.form["type"], request.form["plate"],
              request.form["driver"], request.form["gps_code"], request.form["gps_type"],
              request.form["manufacture_date"], request.form["serial_number"], request.form["operation_status"],
              request.form["active_status"], request.form.get("operational_type", "برگشتی"),
              request.form.get("imei", ""), 1 if request.form.get("has_gps") == "1" else 0,
              npz, request.form.get("sim_card_number", ""),
              request.form.get("sim_operator", ""), request.form.get("installation_notes", ""),
              machine_id, current_project_id()))
        connection.commit()
        connection.close()
        log_audit("machine", machine_id, "ویرایش", old_value=old_name, new_value=request.form["name"])
        return redirect("/machines")
    return render_template("edit_machine.html", machine=machine, operational_types=OPERATIONAL_TYPES, zones=get_zones())


@app.route("/delete_machine/<int:machine_id>")
@login_required
def delete_machine(machine_id):
    m = get_machine(machine_id)
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM machines WHERE id = ? AND project_id = ?", (machine_id, current_project_id()))
    connection.commit()
    connection.close()
    if m:
        log_audit("machine", machine_id, "حذف", old_value=m["name"])
    return redirect("/machines")


@app.route("/add_worklog_form")
@login_required
def add_worklog_form():
    return render_template("add_worklog.html", machines=get_machines())


@app.route("/add_worklog", methods=["POST"])
@login_required
def add_worklog():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("INSERT INTO work_logs (machine_code, work_date, start_time, end_time, project_id) VALUES (?, ?, ?, ?, ?)",
                   (request.form["machine_code"], request.form["work_date"], request.form["start_time"], request.form["end_time"], current_project_id()))
    connection.commit()
    connection.close()
    return redirect("/worklogs")


@app.route("/worklogs")
@login_required
def worklogs():
    return render_template("worklogs.html", worklogs=get_worklogs())


@app.route("/report")
@login_required
def report():
    return render_template("report.html", report=get_report())


@app.route("/add_personnel_form")
@login_required
def add_personnel_form():
    return render_template("add_personnel.html", patterns=get_work_patterns())


@app.route("/add_personnel", methods=["POST"])
@login_required
def add_personnel():
    connection = get_db()
    cursor = connection.cursor()
    wp_id = request.form.get("work_pattern_id") or None
    if wp_id:
        wp_id = int(wp_id)
    cursor.execute("""
        INSERT INTO personnel (personnel_code, full_name, job_title, national_code, phone_number,
            has_machine, machine_code, device_user_id, start_date, status, project_id, work_pattern_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (request.form["personnel_code"], request.form["full_name"], request.form["job_title"],
          request.form["national_code"], request.form["phone_number"], request.form["has_machine"],
          request.form["machine_code"], request.form["device_user_id"], request.form["start_date"],
          request.form["status"], current_project_id(), wp_id))
    pid = cursor.lastrowid
    connection.commit()
    connection.close()
    log_audit("personnel", pid, "افزودن", new_value=request.form["full_name"])
    return redirect("/personnel")


@app.route("/personnel")
@login_required
def personnel():
    return render_template("personnel.html", personnel_list=get_personnel())


@app.route("/edit_personnel/<int:person_id>", methods=["GET", "POST"])
@login_required
def edit_personnel(person_id):
    person = get_person(person_id)
    if not person:
        return redirect("/personnel")
    if request.method == "POST":
        old_name = person["full_name"]
        connection = get_db()
        cursor = connection.cursor()
        wp_id = request.form.get("work_pattern_id") or None
        if wp_id:
            wp_id = int(wp_id)
        cursor.execute("""
            UPDATE personnel
            SET personnel_code = ?, full_name = ?, job_title = ?, national_code = ?, phone_number = ?,
                has_machine = ?, machine_code = ?, device_user_id = ?, start_date = ?, status = ?, work_pattern_id = ?
            WHERE id = ? AND project_id = ?
        """, (request.form["personnel_code"], request.form["full_name"], request.form["job_title"],
              request.form["national_code"], request.form["phone_number"], request.form["has_machine"],
              request.form["machine_code"], request.form["device_user_id"], request.form["start_date"],
              request.form["status"], wp_id, person_id, current_project_id()))
        connection.commit()
        connection.close()
        log_audit("personnel", person_id, "ویرایش", old_value=old_name, new_value=request.form["full_name"])
        return redirect("/personnel")
    return render_template("edit_personnel.html", person=person, patterns=get_work_patterns())


@app.route("/delete_personnel/<int:person_id>")
@login_required
def delete_personnel(person_id):
    p = get_person(person_id)
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM personnel WHERE id = ? AND project_id = ?", (person_id, current_project_id()))
    connection.commit()
    connection.close()
    if p:
        log_audit("personnel", person_id, "حذف", old_value=p["full_name"])
    return redirect("/personnel")


@app.route("/add_personnel_attendance_form")
@login_required
def add_personnel_attendance_form():
    return render_template("add_personnel_attendance.html", personnel_list=get_personnel())


@app.route("/add_personnel_attendance", methods=["POST"])
@login_required
def add_personnel_attendance():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("INSERT INTO personnel_attendance (personnel_code, work_date, start_time, end_time, project_id) VALUES (?, ?, ?, ?, ?)",
                   (request.form["personnel_code"], request.form["work_date"], request.form["start_time"], request.form["end_time"], current_project_id()))
    connection.commit()
    connection.close()
    return redirect("/personnel_attendance")


@app.route("/personnel_attendance")
@login_required
def personnel_attendance():
    return render_template("personnel_attendance.html", attendance=get_personnel_attendance())


# ═══════════ الگوی کاری ═══════════

@app.route("/work_patterns")
@login_required
def work_patterns_list():
    return render_template("work_patterns.html", patterns=get_work_patterns(), day_names=DAY_NAMES)


@app.route("/work_patterns/add", methods=["GET", "POST"])
@login_required
def add_work_pattern():
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        rotation_weeks = int(request.form.get("rotation_weeks", "1"))
        cursor.execute("""
            INSERT INTO work_patterns (project_id, pattern_name, pattern_type, description,
                work_start, work_end, lunch_start, lunch_end, lunch_duration_minutes,
                breakfast_start, breakfast_end, breakfast_duration,
                dinner_start, dinner_end, dinner_duration,
                daily_work_minutes, overtime_after_minutes,
                late_tolerance_minutes, early_tolerance_minutes,
                attendance_range_start, attendance_range_end,
                single_punch_behavior, rotation_weeks, rotation_start_date,
                is_default, is_active, crosses_midnight)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        """, (current_project_id(), request.form.get("pattern_name", "").strip(),
              request.form.get("pattern_type", "عادی"), request.form.get("description", ""),
              normalize_time_input(request.form.get("work_start", "07:30")),
              normalize_time_input(request.form.get("work_end", "17:30")),
              normalize_time_input(request.form.get("lunch_start", "13:00")),
              normalize_time_input(request.form.get("lunch_end", "14:00")),
              int(request.form.get("lunch_duration_minutes", "60")),
              normalize_time_input(request.form.get("breakfast_start", "")),
              normalize_time_input(request.form.get("breakfast_end", "")),
              int(request.form.get("breakfast_duration", "0") or 0),
              normalize_time_input(request.form.get("dinner_start", "")),
              normalize_time_input(request.form.get("dinner_end", "")),
              int(request.form.get("dinner_duration", "0") or 0),
              int(request.form.get("daily_work_minutes", "480")),
              int(request.form.get("overtime_after_minutes", "480")),
              int(request.form.get("late_tolerance_minutes", "10")),
              int(request.form.get("early_tolerance_minutes", "10")),
              normalize_time_input(request.form.get("attendance_range_start", "06:00")),
              normalize_time_input(request.form.get("attendance_range_end", "22:00")),
              request.form.get("single_punch_behavior", "ناقص"),
              rotation_weeks, request.form.get("rotation_start_date", ""),
              int(request.form.get("is_default", "0")),
              1 if request.form.get("crosses_midnight") == "1" else 0))
        pattern_id = cursor.lastrowid
        for week in range(1, rotation_weeks + 1):
            for day in range(7):
                day_type = request.form.get(f"w{week}_d{day}", "کاری")
                cursor.execute("INSERT INTO work_pattern_days (pattern_id, week_number, day_of_week, day_type) VALUES (?, ?, ?, ?)",
                               (pattern_id, week, day, day_type))
        connection.commit()
        connection.close()
        return redirect("/work_patterns")
    return render_template("add_work_pattern.html", day_names=DAY_NAMES, day_types=DAY_TYPES, single_punch_options=SINGLE_PUNCH_OPTIONS)


@app.route("/work_patterns/edit/<int:pattern_id>", methods=["GET", "POST"])
@login_required
def edit_work_pattern(pattern_id):
    pattern = get_work_pattern(pattern_id)
    if not pattern:
        return redirect("/work_patterns")
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        rotation_weeks = int(request.form.get("rotation_weeks", "1"))
        cursor.execute("""
            UPDATE work_patterns SET
                pattern_name = ?, pattern_type = ?, description = ?,
                work_start = ?, work_end = ?, lunch_start = ?, lunch_end = ?, lunch_duration_minutes = ?,
                breakfast_start = ?, breakfast_end = ?, breakfast_duration = ?,
                dinner_start = ?, dinner_end = ?, dinner_duration = ?,
                daily_work_minutes = ?, overtime_after_minutes = ?,
                late_tolerance_minutes = ?, early_tolerance_minutes = ?,
                attendance_range_start = ?, attendance_range_end = ?,
                single_punch_behavior = ?, rotation_weeks = ?, rotation_start_date = ?,
                is_default = ?, crosses_midnight = ?
            WHERE id = ? AND project_id = ?
        """, (request.form.get("pattern_name", "").strip(), request.form.get("pattern_type", "عادی"),
              request.form.get("description", ""),
              normalize_time_input(request.form.get("work_start", "07:30")),
              normalize_time_input(request.form.get("work_end", "17:30")),
              normalize_time_input(request.form.get("lunch_start", "13:00")),
              normalize_time_input(request.form.get("lunch_end", "14:00")),
              int(request.form.get("lunch_duration_minutes", "60")),
              normalize_time_input(request.form.get("breakfast_start", "")),
              normalize_time_input(request.form.get("breakfast_end", "")),
              int(request.form.get("breakfast_duration", "0") or 0),
              normalize_time_input(request.form.get("dinner_start", "")),
              normalize_time_input(request.form.get("dinner_end", "")),
              int(request.form.get("dinner_duration", "0") or 0),
              int(request.form.get("daily_work_minutes", "480")),
              int(request.form.get("overtime_after_minutes", "480")),
              int(request.form.get("late_tolerance_minutes", "10")),
              int(request.form.get("early_tolerance_minutes", "10")),
              normalize_time_input(request.form.get("attendance_range_start", "06:00")),
              normalize_time_input(request.form.get("attendance_range_end", "22:00")),
              request.form.get("single_punch_behavior", "ناقص"),
              rotation_weeks, request.form.get("rotation_start_date", ""),
              int(request.form.get("is_default", "0")),
              1 if request.form.get("crosses_midnight") == "1" else 0,
              pattern_id, current_project_id()))
        cursor.execute("DELETE FROM work_pattern_days WHERE pattern_id = ?", (pattern_id,))
        for week in range(1, rotation_weeks + 1):
            for day in range(7):
                day_type = request.form.get(f"w{week}_d{day}", "کاری")
                cursor.execute("INSERT INTO work_pattern_days (pattern_id, week_number, day_of_week, day_type) VALUES (?, ?, ?, ?)",
                               (pattern_id, week, day, day_type))
        connection.commit()
        connection.close()
        return redirect("/work_patterns")
    days = get_pattern_days(pattern_id)
    days_map = {}
    for d in days:
        days_map[f"w{d['week_number']}_d{d['day_of_week']}"] = d["day_type"]
    return render_template("edit_work_pattern.html", pattern=pattern, days_map=days_map, day_names=DAY_NAMES, day_types=DAY_TYPES, single_punch_options=SINGLE_PUNCH_OPTIONS)


@app.route("/work_patterns/delete/<int:pattern_id>")
@login_required
def delete_work_pattern(pattern_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM work_pattern_days WHERE pattern_id = ?", (pattern_id,))
    cursor.execute("DELETE FROM work_patterns WHERE id = ? AND project_id = ?", (pattern_id, current_project_id()))
    connection.commit()
    connection.close()
    return redirect("/work_patterns")


@app.route("/holidays", methods=["GET", "POST"])
@login_required
def holidays_page():
    message = None
    current_year = jdatetime.date.today().year
    selected_year = int(request.args.get("year", current_year))
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        h_date = request.form.get("holiday_date", "").strip()
        h_name = request.form.get("holiday_name", "").strip()
        h_year = int(h_date.split("/")[0]) if "/" in h_date else selected_year
        cursor.execute("INSERT INTO holidays (holiday_date, holiday_name, source, year) VALUES (?, ?, 'دستی', ?)",
                       (h_date, h_name, h_year))
        connection.commit()
        connection.close()
        message = "تعطیلی اضافه شد"
    return render_template("holidays.html", holidays=get_holidays(selected_year), selected_year=selected_year, message=message)


@app.route("/holidays/delete/<int:holiday_id>")
@login_required
def delete_holiday(holiday_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM holidays WHERE id = ?", (holiday_id,))
    connection.commit()
    connection.close()
    return redirect("/holidays")


@app.route("/leaves")
@login_required
def leaves_page():
    return render_template("leaves.html", leaves=get_leaves(), leave_types=LEAVE_TYPES)


@app.route("/leaves/add", methods=["GET", "POST"])
@login_required
def add_leave():
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO leaves (project_id, personnel_id, leave_type, start_date, end_date,
                start_time, end_time, is_hourly, duration_days, duration_minutes, reason, status, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'تایید شده', ?, ?)
        """, (current_project_id(), int(request.form.get("personnel_id")),
              request.form.get("leave_type", ""), request.form.get("start_date", ""),
              request.form.get("end_date", ""), request.form.get("start_time", ""),
              request.form.get("end_time", ""), 1 if request.form.get("is_hourly") == "1" else 0,
              float(request.form.get("duration_days", "1") or "1"),
              int(request.form.get("duration_minutes", "0") or "0"),
              request.form.get("reason", ""), session.get("username", ""),
              datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        connection.commit()
        connection.close()
        return redirect("/leaves")
    return render_template("add_leave.html", personnel_list=get_personnel(), leave_types=LEAVE_TYPES)


@app.route("/leaves/delete/<int:leave_id>")
@login_required
def delete_leave(leave_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM leaves WHERE id = ? AND project_id = ?", (leave_id, current_project_id()))
    connection.commit()
    connection.close()
    return redirect("/leaves")


@app.route("/calendar")
@login_required
def calendar_page():
    month = request.args.get("month", jdatetime.date.today().strftime("%Y/%m"))
    try:
        year, m = map(int, month.split("/"))
        current = jdatetime.date(year, m, 1)
    except:
        current = jdatetime.date.today().replace(day=1)
    next_month = (current + jdatetime.timedelta(days=32)).strftime("%Y/%m")
    prev_month = (current - jdatetime.timedelta(days=5)).strftime("%Y/%m")
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM work_patterns WHERE project_id = ? AND is_default = 1 LIMIT 1", (current_project_id(),))
    active_pattern = cursor.fetchone()
    connection.close()
    calendar_weeks = []
    first_weekday = current.weekday()
    if current.month == 12:
        days_in_month = 30 if current.year % 4 == 3 else 29
    else:
        days_in_month = (current.replace(month=current.month + 1, day=1) - jdatetime.timedelta(days=1)).day
    week = [None] * first_weekday
    for day in range(1, days_in_month + 1):
        date_str = f"{current.year}/{current.month:02d}/{day:02d}"
        status = get_day_status(date_str, active_pattern["id"] if active_pattern else None, current_project_id())
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("SELECT reason FROM calendar_overrides WHERE project_id = ? AND override_date = ?",
                       (current_project_id(), date_str))
        override = cursor.fetchone()
        connection.close()
        week.append({"day": day, "date": date_str, "status": status, "reason": override["reason"] if override else ""})
        if len(week) == 7:
            calendar_weeks.append(week)
            week = []
    if week:
        week += [None] * (7 - len(week))
        calendar_weeks.append(week)
    return render_template("calendar.html", calendar_weeks=calendar_weeks, current_month=month,
                           current_month_name=get_persian_month_name(current.year, current.month),
                           prev_month=prev_month, next_month=next_month,
                           day_names=DAY_NAMES, active_pattern=active_pattern)


@app.route("/calendar/override", methods=["GET", "POST"])
@login_required
def calendar_override():
    date_str = request.args.get("date")
    if not date_str:
        return redirect("/calendar")
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO calendar_overrides
            (project_id, override_date, original_type, new_type, reason, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (current_project_id(), date_str, "نامشخص", request.form.get("new_type"),
              request.form.get("reason", ""), session.get("username", ""),
              datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        connection.commit()
        connection.close()
        return redirect("/calendar")
    return render_template("calendar_override.html", date=date_str, day_types=DAY_TYPES)


# ═══════════ گزارش کارکرد ماهانه ═══════════

@app.route("/monthly_report")
@login_required
def monthly_report_index():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT id, personnel_code, full_name, job_title FROM personnel WHERE project_id = ? AND status = 'فعال' ORDER BY full_name",
                   (current_project_id(),))
    personnel_list = cursor.fetchall()
    connection.close()
    today = jdatetime.date.today()
    return render_template("monthly_report_index.html", personnel_list=personnel_list,
                           current_year=today.year, current_month=today.month,
                           persian_months=PERSIAN_MONTHS,
                           years=list(range(today.year - 2, today.year + 2)))


@app.route("/monthly_report/<int:person_id>")
@login_required
def monthly_report_view(person_id):
    year = int(request.args.get("year", jdatetime.date.today().year))
    month = int(request.args.get("month", jdatetime.date.today().month))
    report = calculate_monthly_report(person_id, year, month, current_project_id())
    if not report:
        return redirect("/monthly_report")
    return render_template("monthly_report.html", report=report,
                           persian_months=PERSIAN_MONTHS,
                           years=list(range(year - 2, year + 2)))


@app.route("/monthly_report/adjust/<int:person_id>", methods=["POST"])
@login_required
def monthly_report_adjust(person_id):
    date_str = request.form.get("date")
    adjusted_start = normalize_time_input(request.form.get("adjusted_start", "").strip())
    adjusted_end = normalize_time_input(request.form.get("adjusted_end", "").strip())
    note = request.form.get("note", "").strip()
    year = int(request.form.get("year"))
    month = int(request.form.get("month"))
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO attendance_adjustments
        (project_id, personnel_id, work_date, adjusted_start, adjusted_end, note, adjusted_by, adjusted_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (current_project_id(), person_id, date_str, adjusted_start, adjusted_end, note,
          session.get("username", ""), datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    connection.commit()
    connection.close()
    log_audit("attendance", person_id, "اصلاح دستی",
              field_name=date_str, new_value=f"{adjusted_start} - {adjusted_end}", reason=note)
    return redirect(f"/monthly_report/{person_id}?year={year}&month={month}")


@app.route("/monthly_summary")
@login_required
def monthly_summary():
    year = int(request.args.get("year", jdatetime.date.today().year))
    month = int(request.args.get("month", jdatetime.date.today().month))
    results = calculate_all_personnel_monthly(current_project_id(), year, month)
    return render_template("monthly_summary.html", results=results,
                           year=year, month=month, month_name=PERSIAN_MONTHS[month - 1],
                           persian_months=PERSIAN_MONTHS,
                           years=list(range(year - 2, year + 2)))


@app.route("/monthly_report/<int:person_id>/excel")
@login_required
def monthly_report_excel(person_id):
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    year = int(request.args.get("year", jdatetime.date.today().year))
    month = int(request.args.get("month", jdatetime.date.today().month))
    report = calculate_monthly_report(person_id, year, month, current_project_id())
    if not report:
        return redirect("/monthly_report")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "گزارش کارکرد"
    ws.sheet_view.rightToLeft = True
    header_fill = PatternFill(start_color="2c3e50", end_color="2c3e50", fill_type="solid")
    header_font = Font(name="Tahoma", size=11, bold=True, color="FFFFFF")
    center = Alignment(horizontal="center", vertical="center")
    border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    ws.merge_cells("A1:J1")
    ws["A1"] = f"گزارش کارکرد {report['person']['full_name']} - {report['month_name']} {report['year']}"
    ws["A1"].font = Font(name="Tahoma", size=14, bold=True)
    ws["A1"].alignment = center
    headers = ["روز", "تاریخ", "روز هفته", "وضعیت", "ورود", "خروج", "کارکرد خالص", "اضافه‌کاری", "تأخیر", "تعجیل"]
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=3, column=i, value=h)
        c.fill = header_fill
        c.font = header_font
        c.alignment = center
        c.border = border
    row = 4
    for r in report["rows"]:
        ws.cell(row=row, column=1, value=r["day"])
        ws.cell(row=row, column=2, value=r["date"])
        ws.cell(row=row, column=3, value=r["day_name"])
        ws.cell(row=row, column=4, value=r["status"])
        ws.cell(row=row, column=5, value=r["start_time"])
        ws.cell(row=row, column=6, value=r["end_time"])
        ws.cell(row=row, column=7, value=r["net"])
        ws.cell(row=row, column=8, value=r["overtime"])
        ws.cell(row=row, column=9, value=r["late"])
        ws.cell(row=row, column=10, value=r["early"])
        for col in range(1, 11):
            ws.cell(row=row, column=col).alignment = center
            ws.cell(row=row, column=col).border = border
        row += 1
    row += 2
    s = report["summary"]
    for label, value in [
        ("کل روزهای کاری ماه", s["work_days"]), ("روز حاضر", s["present_days"]),
        ("روز غایب", s["absent_days"]), ("روز مرخصی", s["leave_days"]),
        ("روز تعطیل", s["holiday_days"]), ("روز ناقص", s["incomplete_days"]),
        ("کل کارکرد خالص", s["net_hm"]), ("کل اضافه‌کاری", s["overtime_hm"]),
        ("کل تأخیر", s["late_hm"]), ("کل تعجیل", s["early_hm"]),
    ]:
        ws.cell(row=row, column=1, value=label).font = Font(name="Tahoma", bold=True)
        ws.cell(row=row, column=2, value=value)
        row += 1
    for col in "ABCDEFGHIJ":
        ws.column_dimensions[col].width = 14
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = f"report_{report['person']['personnel_code']}_{year}_{month:02d}.xlsx"
    return send_file(buf, download_name=filename, as_attachment=True,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ═══════════ فاز A: استثناها ═══════════

@app.route("/exceptions")
@login_required
def exceptions_list():
    return render_template("exceptions.html", exceptions=get_exceptions())


@app.route("/exceptions/add", methods=["GET", "POST"])
@login_required
def add_exception():
    if request.method == "POST":
        subject_type = request.form.get("subject_type", "کارگاه")
        subject_id_raw = request.form.get("subject_id", "").strip()
        subject_id = int(subject_id_raw) if subject_id_raw.isdigit() else None
        subject_code = ""
        if subject_id and subject_type == "ماشین":
            m = get_machine(subject_id)
            subject_code = m["code"] if m else ""
        elif subject_id and subject_type == "پرسنل":
            p = get_person(subject_id)
            subject_code = p["personnel_code"] if p else ""
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO exceptions (project_id, exception_type, subject_type, subject_id, subject_code,
                start_datetime, end_datetime, description, approved_by, created_by, created_at, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (current_project_id(), request.form.get("exception_type", ""),
              subject_type, subject_id, subject_code,
              request.form.get("start_datetime", ""), request.form.get("end_datetime", ""),
              request.form.get("description", ""), request.form.get("approved_by", ""),
              session.get("username", ""),
              datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              request.form.get("status", "تایید شده")))
        eid = cursor.lastrowid
        connection.commit()
        connection.close()
        log_audit("exception", eid, "افزودن", new_value=request.form.get("exception_type", ""))
        return redirect("/exceptions")
    return render_template("add_exception.html", exception_types=EXCEPTION_TYPES,
                           subject_types=EXCEPTION_SUBJECT_TYPES,
                           machines=get_machines(), personnel_list=get_personnel())


@app.route("/exceptions/delete/<int:exception_id>")
@login_required
def delete_exception(exception_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM exceptions WHERE id = ? AND project_id = ?", (exception_id, current_project_id()))
    connection.commit()
    connection.close()
    log_audit("exception", exception_id, "حذف")
    return redirect("/exceptions")


# ═══════════ فاز A: Zones ═══════════

@app.route("/zones")
@login_required
def zones_list():
    return render_template("zones.html", zones=get_zones(), zone_types=ZONE_TYPES)


@app.route("/zones/add", methods=["GET", "POST"])
@login_required
def add_zone():
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO zones (project_id, zone_name, zone_type,
                center_lat, center_lng, radius_meters, color, description, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (current_project_id(), request.form.get("zone_name", "").strip(),
              request.form.get("zone_type", "کارگاه"),
              float(request.form.get("center_lat", "35.7") or "35.7"),
              float(request.form.get("center_lng", "51.4") or "51.4"),
              float(request.form.get("radius_meters", "50") or "50"),
              request.form.get("color", "#3498db"),
              request.form.get("description", ""),
              datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        zid = cursor.lastrowid
        connection.commit()
        connection.close()
        log_audit("zone", zid, "افزودن", new_value=request.form.get("zone_name", ""))
        return redirect("/zones")
    return render_template("add_zone.html", zone_types=ZONE_TYPES)


@app.route("/zones/edit/<int:zone_id>", methods=["GET", "POST"])
@login_required
def edit_zone(zone_id):
    zone = get_zone(zone_id)
    if not zone:
        return redirect("/zones")
    if request.method == "POST":
        connection = get_db()
        cursor = connection.cursor()
        cursor.execute("""
            UPDATE zones SET zone_name = ?, zone_type = ?,
                center_lat = ?, center_lng = ?, radius_meters = ?,
                color = ?, description = ?, is_active = ?
            WHERE id = ? AND project_id = ?
        """, (request.form.get("zone_name", "").strip(),
              request.form.get("zone_type", "کارگاه"),
              float(request.form.get("center_lat", "0") or "0"),
              float(request.form.get("center_lng", "0") or "0"),
              float(request.form.get("radius_meters", "50") or "50"),
              request.form.get("color", "#3498db"),
              request.form.get("description", ""),
              1 if request.form.get("is_active") == "1" else 0,
              zone_id, current_project_id()))
        connection.commit()
        connection.close()
        log_audit("zone", zone_id, "ویرایش")
        return redirect("/zones")
    return render_template("edit_zone.html", zone=zone, zone_types=ZONE_TYPES)


@app.route("/zones/delete/<int:zone_id>")
@login_required
def delete_zone(zone_id):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM zones WHERE id = ? AND project_id = ?", (zone_id, current_project_id()))
    connection.commit()
    connection.close()
    log_audit("zone", zone_id, "حذف")
    return redirect("/zones")


# ═══════════ فاز A: Audit Log ═══════════

@app.route("/audit_log")
@admin_required
def audit_log_view():
    return render_template("audit_log.html", logs=get_audit_logs(limit=500))


# ═══════════ فاز B: داشبورد و مسیر GPS ═══════════

def get_trackers_live_status():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT m.id, m.code, m.name, m.imei, m.operational_type, m.type as machine_type,
               m.lat, m.lng,
               (SELECT recorded_at FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS last_seen,
               (SELECT speed FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS last_speed,
               (SELECT ignition FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS ignition,
               (SELECT movement FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS movement,
               (SELECT gsm_signal FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS gsm_signal,
               (SELECT external_voltage FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS voltage,
               (SELECT COUNT(*) FROM gps_points WHERE machine_code = m.code AND date(recorded_at) = date('now')) AS today_points
        FROM machines m WHERE m.project_id = ? ORDER BY last_seen DESC
    """, (current_project_id(),))
    rows = cursor.fetchall()
    connection.close()
    now = datetime.datetime.now()
    result = []
    for r in rows:
        d = dict(r)
        d["online_status"] = "بدون داده"
        d["online_color"] = "#94a3b8"
        d["minutes_ago"] = None
        if d["last_seen"]:
            try:
                last = datetime.datetime.strptime(d["last_seen"], "%Y-%m-%d %H:%M:%S")
                diff = (now - last).total_seconds() / 60
                d["minutes_ago"] = int(diff)
                if diff < 5:
                    d["online_status"] = "آنلاین"; d["online_color"] = "#16a34a"
                elif diff < 30:
                    d["online_status"] = "اخیراً"; d["online_color"] = "#eab308"
                elif diff < 1440:
                    d["online_status"] = "امروز"; d["online_color"] = "#f97316"
                else:
                    d["online_status"] = "قدیمی"; d["online_color"] = "#dc2626"
            except:
                pass
        result.append(d)
    return result


def get_machine_route(machine_id, date_str=None):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE id = ? AND project_id = ?", (machine_id, current_project_id()))
    machine = cursor.fetchone()
    if not machine:
        connection.close()
        return None
    if date_str:
        try:
            parts = date_str.split("/")
            greg = jdatetime.date(int(parts[0]), int(parts[1]), int(parts[2])).togregorian()
            date_greg = greg.strftime("%Y-%m-%d")
        except:
            date_greg = datetime.date.today().strftime("%Y-%m-%d")
    else:
        date_greg = datetime.date.today().strftime("%Y-%m-%d")
    cursor.execute("SELECT * FROM gps_points WHERE machine_code = ? AND date(recorded_at) = ? ORDER BY recorded_at ASC",
                   (machine["code"], date_greg))
    points = [dict(r) for r in cursor.fetchall()]
    connection.close()
    stats = {"total_points": len(points), "distance_km": 0, "max_speed": 0,
             "avg_speed": 0, "moving_minutes": 0, "stopped_minutes": 0,
             "first_point_time": None, "last_point_time": None}
    if points:
        stats["first_point_time"] = points[0]["recorded_at"]
        stats["last_point_time"] = points[-1]["recorded_at"]
        speeds = [p["speed"] or 0 for p in points]
        stats["max_speed"] = max(speeds) if speeds else 0
        moving = [s for s in speeds if s > 5]
        stats["avg_speed"] = round(sum(moving) / len(moving)) if moving else 0
        import math
        total_dist = 0
        for i in range(1, len(points)):
            lat1, lng1 = points[i-1]["lat"], points[i-1]["lng"]
            lat2, lng2 = points[i]["lat"], points[i]["lng"]
            if lat1 and lng1 and lat2 and lng2:
                R = 6371
                dlat = math.radians(lat2 - lat1)
                dlng = math.radians(lng2 - lng1)
                a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
                c = 2 * math.asin(math.sqrt(a))
                total_dist += R * c
        stats["distance_km"] = round(total_dist, 2)
    return {"machine": dict(machine), "points": points, "stats": stats, "date_greg": date_greg}


@app.route("/tracker_dashboard")
@login_required
def tracker_dashboard():
    return render_template("tracker_dashboard.html", trackers=get_trackers_live_status())


@app.route("/api/trackers_live")
@login_required
def api_trackers_live():
    return jsonify(get_trackers_live_status())


@app.route("/machine_route/<int:machine_id>")
@login_required
def machine_route(machine_id):
    date_str = request.args.get("date", "")
    data = get_machine_route(machine_id, date_str)
    if not data:
        return redirect("/machines")
    today = jdatetime.date.today()
    if not date_str:
        date_str = today.strftime("%Y/%m/%d")
    return render_template("machine_route.html", data=data, selected_date=date_str,
                           points_json=json.dumps([{"lat": p["lat"], "lng": p["lng"],
                                                    "speed": p["speed"], "time": p["recorded_at"],
                                                    "ignition": p["ignition"]}
                                                   for p in data["points"] if p["lat"] and p["lng"]], ensure_ascii=False))


@app.route("/api/machine_route/<int:machine_id>")
@login_required
def api_machine_route(machine_id):
    date_str = request.args.get("date", "")
    data = get_machine_route(machine_id, date_str)
    if not data:
        return jsonify({"error": "ماشین یافت نشد"}), 404
    return jsonify({"machine": data["machine"], "points": data["points"], "stats": data["stats"]})


@app.route("/tracker_connections")
@admin_required
def tracker_connections_view():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT tc.*, m.name as machine_name, m.code as machine_code
        FROM tracker_connections tc
        LEFT JOIN machines m ON m.imei = tc.imei
        ORDER BY tc.id DESC LIMIT 200
    """)
    logs = cursor.fetchall()
    connection.close()
    return render_template("tracker_connections.html", logs=logs)


# ═══════════ فاز C: تحلیل هوشمند ═══════════

@app.route("/analysis")
@login_required
def analysis_index():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, code, name, operational_type, imei, has_gps
        FROM machines WHERE project_id = ? AND has_gps = 1 ORDER BY name
    """, (current_project_id(),))
    machines = cursor.fetchall()
    connection.close()
    today = jdatetime.date.today().strftime("%Y/%m/%d")
    return render_template("analysis_index.html", machines=machines, today=today)


@app.route("/analysis/run", methods=["POST"])
@login_required
def analysis_run():
    machine_id = request.form.get("machine_id", "")
    date_jalali = request.form.get("date_jalali", "").strip()
    run_all = request.form.get("run_all") == "1"
    if not date_jalali:
        return redirect("/analysis")
    date_greg = jalali_to_greg(date_jalali)
    pid = current_project_id()
    if run_all:
        results = run_analysis_for_all_machines(date_greg, pid)
        log_audit("analysis", None, "اجرای تحلیل همه ماشین‌ها",
                  new_value=f"تاریخ: {date_jalali} — {len(results)} ماشین")
        return render_template("analysis_batch_result.html", results=results, date_jalali=date_jalali)
    if not machine_id:
        return redirect("/analysis")
    machine_id = int(machine_id)
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE id = ?", (machine_id,))
    m = cursor.fetchone()
    connection.close()
    if not m:
        return redirect("/analysis")
    result = run_full_analysis(m["code"], date_greg, pid, m["imei"] or "")
    log_audit("analysis", machine_id, "اجرای تحلیل",
              field_name=date_jalali,
              new_value=f"stops={result['steps'].get('stops', 0)} services={result['steps'].get('truck_services', 0)}")
    return redirect(f"/machine_analysis/{machine_id}?date={date_jalali}")


@app.route("/machine_analysis/<int:machine_id>")
@login_required
def machine_analysis(machine_id):
    date_jalali = request.args.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
    date_greg = jalali_to_greg(date_jalali)
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE id = ? AND project_id = ?", (machine_id, pid))
    machine = cursor.fetchone()
    if not machine:
        connection.close()
        return redirect("/analysis")
    cursor.execute("SELECT * FROM daily_machine_summary WHERE machine_code = ? AND work_date = ? AND project_id = ?",
                   (machine["code"], date_greg, pid))
    summary = cursor.fetchone()
    cursor.execute("""
        SELECT s.*, z.zone_name FROM analyzed_stops s
        LEFT JOIN zones z ON s.zone_id = z.id
        WHERE s.machine_code = ? AND s.work_date = ? AND s.project_id = ?
        ORDER BY s.start_time ASC
    """, (machine["code"], date_greg, pid))
    stops = [dict(r) for r in cursor.fetchall()]
    cursor.execute("SELECT * FROM zone_events WHERE machine_code = ? AND date(event_time) = ? AND project_id = ? ORDER BY event_time ASC",
                   (machine["code"], date_greg, pid))
    events = [dict(r) for r in cursor.fetchall()]
    cursor.execute("""
        SELECT ts.*, zl.zone_name AS loading_name, zd.zone_name AS dumping_name
        FROM truck_services ts
        LEFT JOIN zones zl ON ts.loading_zone_id = zl.id
        LEFT JOIN zones zd ON ts.dumping_zone_id = zd.id
        WHERE ts.machine_code = ? AND ts.work_date = ? AND ts.project_id = ?
        ORDER BY ts.service_number ASC
    """, (machine["code"], date_greg, pid))
    services = [dict(r) for r in cursor.fetchall()]
    cursor.execute("SELECT * FROM work_front_candidates WHERE machine_code = ? AND work_date = ? AND project_id = ? ORDER BY duration_minutes DESC",
                   (machine["code"], date_greg, pid))
    fronts = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("machine_analysis.html",
                           machine=dict(machine),
                           summary=dict(summary) if summary else None,
                           stops=stops, events=events, services=services, fronts=fronts,
                           date_jalali=date_jalali, date_greg=date_greg)


@app.route("/truck_services")
@login_required
def truck_services_alias():
    return truck_services_report()

@app.route("/truck_services_report")
@login_required
def truck_services_report():
    date_jalali = request.args.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
    date_greg = jalali_to_greg(date_jalali)
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT ts.*, m.name AS machine_name,
               zl.zone_name AS loading_name, zd.zone_name AS dumping_name
        FROM truck_services ts
        LEFT JOIN machines m ON ts.machine_code = m.code
        LEFT JOIN zones zl ON ts.loading_zone_id = zl.id
        LEFT JOIN zones zd ON ts.dumping_zone_id = zd.id
        WHERE ts.work_date = ? AND ts.project_id = ?
        ORDER BY ts.machine_code, ts.service_number
    """, (date_greg, pid))
    services = [dict(r) for r in cursor.fetchall()]
    cursor.execute("""
        SELECT machine_code, COUNT(*) as total,
               AVG(total_cycle_minutes) as avg_cycle,
               AVG(distance_km) as avg_dist,
               MAX(target_services) as target,
               MIN(total_cycle_minutes) as min_cycle,
               MAX(total_cycle_minutes) as max_cycle
        FROM truck_services WHERE work_date = ? AND project_id = ?
        GROUP BY machine_code
    """, (date_greg, pid))
    stats = [dict(r) for r in cursor.fetchall()]
    for st in stats:
        cursor.execute("SELECT name FROM machines WHERE code = ?", (st["machine_code"],))
        m = cursor.fetchone()
        st["machine_name"] = m["name"] if m else st["machine_code"]
    connection.close()
    return render_template("truck_services.html", services=services, stats=stats,
                           date_jalali=date_jalali, date_greg=date_greg)


@app.route("/work_fronts")
@login_required
def work_fronts_alias():
    return work_fronts_report()

@app.route("/work_fronts_report")
@login_required
def work_fronts_report():
    date_jalali = request.args.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
    date_greg = jalali_to_greg(date_jalali)
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT wfc.*, m.name AS machine_name, m.operational_type
        FROM work_front_candidates wfc
        LEFT JOIN machines m ON wfc.machine_code = m.code
        WHERE wfc.work_date = ? AND wfc.project_id = ?
        ORDER BY wfc.duration_minutes DESC
    """, (date_greg, pid))
    fronts = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("work_fronts.html", fronts=fronts, date_jalali=date_jalali)


@app.route("/work_fronts/confirm/<int:front_id>", methods=["POST"])
@login_required
def work_front_confirm(front_id):
    zone_name = request.form.get("zone_name", "").strip()
    if not zone_name:
        return redirect("/work_fronts_report")
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM work_front_candidates WHERE id = ? AND project_id = ?",
                   (front_id, current_project_id()))
    f = cursor.fetchone()
    if not f:
        connection.close()
        return redirect("/work_fronts_report")
    cursor.execute("""
        INSERT INTO zones (project_id, zone_name, zone_type,
            center_lat, center_lng, radius_meters, color, description, created_at)
        VALUES (?, ?, 'جبهه کار', ?, ?, ?, '#f97316', ?, datetime('now'))
    """, (current_project_id(), zone_name, f["center_lat"], f["center_lng"],
          f["radius_meters"] or 150,
          f"تأیید شده از کاندید — {f['machine_code']} — {f['work_date']}"))
    new_zone_id = cursor.lastrowid
    cursor.execute("UPDATE work_front_candidates SET confirmed = 1, confirmed_zone_id = ? WHERE id = ?",
                   (new_zone_id, front_id))
    connection.commit()
    connection.close()
    log_audit("work_front", front_id, "تأیید و تبدیل به Zone", new_value=zone_name)
    return redirect(request.referrer or "/work_fronts_report")


@app.route("/analysis/settings", methods=["GET", "POST"])
@login_required
def analysis_settings_alias():
    return analysis_settings_page()

@app.route("/analysis_settings", methods=["GET", "POST"])
@admin_required
def analysis_settings_page():
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    if request.method == "POST":
        fields = ["stop_speed_threshold", "stop_min_duration_minutes",
                  "long_stop_threshold_minutes", "suspicious_stop_threshold_minutes",
                  "work_front_min_duration_minutes", "work_front_cluster_radius_meters",
                  "service_min_loading_seconds", "gps_timeout_minutes"]
        values = [int(request.form.get(f, "0") or 0) for f in fields]
        cursor.execute("SELECT id FROM analysis_settings WHERE project_id = ?", (pid,))
        exists = cursor.fetchone()
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if exists:
            set_clause = ", ".join([f"{f} = ?" for f in fields])
            cursor.execute(f"UPDATE analysis_settings SET {set_clause}, updated_at = ? WHERE project_id = ?",
                           values + [now, pid])
        else:
            cols = ", ".join(fields + ["project_id", "updated_at"])
            qs = ", ".join(["?"] * (len(fields) + 2))
            cursor.execute(f"INSERT INTO analysis_settings ({cols}) VALUES ({qs})",
                           values + [pid, now])
        connection.commit()
        log_audit("analysis_settings", pid, "به‌روزرسانی تنظیمات تحلیل")
    cursor.execute("SELECT * FROM analysis_settings WHERE project_id = ?", (pid,))
    s = cursor.fetchone()
    connection.close()
    return render_template("analysis_settings.html", settings=dict(s) if s else None)


# ═══════════ فاز D: سرویس هدف، تلگرام، اعلانات ═══════════

def get_service_targets():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT * FROM service_targets WHERE project_id = ?
        ORDER BY distance_from_km ASC
    """, (current_project_id(),))
    rows = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return rows


@app.route("/service_targets", methods=["GET", "POST"])
@login_required
def service_targets_page():
    pid = current_project_id()
    if request.method == "POST":
        action = request.form.get("action", "add")
        connection = get_db()
        cursor = connection.cursor()
        if action == "delete":
            tid = int(request.form.get("id", "0"))
            cursor.execute("DELETE FROM service_targets WHERE id = ? AND project_id = ?", (tid, pid))
            connection.commit()
            connection.close()
            log_audit("service_target", tid, "حذف")
        elif action == "add":
            cursor.execute("""
                INSERT INTO service_targets (project_id, distance_from_km, distance_to_km,
                    target_services_per_day, standard_cycle_minutes, tolerance_services, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
            """, (pid,
                  float(request.form.get("distance_from_km", "0") or 0),
                  float(request.form.get("distance_to_km", "0") or 0),
                  int(request.form.get("target_services_per_day", "0") or 0),
                  int(request.form.get("standard_cycle_minutes", "15") or 15),
                  int(request.form.get("tolerance_services", "2") or 2),
                  request.form.get("note", "")))
            connection.commit()
            connection.close()
            log_audit("service_target", None, "افزودن بازه فاصله")
        elif action == "update":
            tid = int(request.form.get("id", "0"))
            cursor.execute("""
                UPDATE service_targets SET
                    distance_from_km = ?, distance_to_km = ?, target_services_per_day = ?,
                    standard_cycle_minutes = ?, tolerance_services = ?, note = ?
                WHERE id = ? AND project_id = ?
            """, (float(request.form.get("distance_from_km", "0") or 0),
                  float(request.form.get("distance_to_km", "0") or 0),
                  int(request.form.get("target_services_per_day", "0") or 0),
                  int(request.form.get("standard_cycle_minutes", "15") or 15),
                  int(request.form.get("tolerance_services", "2") or 2),
                  request.form.get("note", ""), tid, pid))
            connection.commit()
            connection.close()
            log_audit("service_target", tid, "ویرایش")
        return redirect("/service_targets")
    return render_template("service_targets.html", targets=get_service_targets())


@app.route("/telegram_settings", methods=["GET", "POST"])
@admin_required
def telegram_settings_page():
    pid = current_project_id()
    message = None
    error = None
    if request.method == "POST":
        action = request.form.get("action", "save")
        connection = get_db()
        cursor = connection.cursor()

        if action == "save":
            cursor.execute("SELECT id FROM telegram_settings WHERE project_id = ?", (pid,))
            existing = cursor.fetchone()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            report_time = request.form.get("daily_report_time", "09:00")
            values = (
                request.form.get("bot_token", "").strip(),
                request.form.get("channel_chat_id", "").strip(),
                request.form.get("proxy_url", "").strip(),
                1 if request.form.get("is_enabled") == "1" else 0,
                1 if request.form.get("send_daily_report") == "1" else 0,
                report_time,
                1 if request.form.get("send_alerts") == "1" else 0,
                now,
            )
            if existing:
                cursor.execute("""
                    UPDATE telegram_settings SET bot_token=?, channel_chat_id=?, proxy_url=?,
                        is_enabled=?, send_daily_report=?, daily_report_time=?, send_alerts=?, updated_at=?
                    WHERE project_id=?
                """, values + (pid,))
            else:
                cursor.execute("""
                    INSERT INTO telegram_settings (bot_token, channel_chat_id, proxy_url,
                        is_enabled, send_daily_report, daily_report_time, send_alerts, updated_at, project_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, values + (pid,))
            connection.commit()
            connection.close()
            try:
                h, mm = map(int, report_time.split(":"))
                update_daily_report_time(h, mm)
            except:
                pass
            message = "تنظیمات ذخیره شد"
            log_audit("telegram_settings", pid, "به‌روزرسانی")

        elif action == "test":
            connection.close()
            result = tg_test(pid)
            if result.get("ok"):
                message = f"اتصال موفق ✅ — Bot: {result.get('bot_username')} ({result.get('bot_name')})"
                connection = get_db()
                cursor = connection.cursor()
                cursor.execute("""UPDATE telegram_settings SET last_test_at=datetime('now'), last_test_result=? WHERE project_id=?""",
                               ("موفق", pid))
                connection.commit()
                connection.close()
            else:
                error = f"خطای اتصال: {result.get('error', 'ناشناخته')}"
                connection = get_db()
                cursor = connection.cursor()
                cursor.execute("""UPDATE telegram_settings SET last_test_at=datetime('now'), last_test_result=? WHERE project_id=?""",
                               (f"خطا: {result.get('error', '')}"[:200], pid))
                connection.commit()
                connection.close()

        elif action == "send_test":
            connection.close()
            result = tg_send("تست اتصال سامانه پایش عملکرد - اگر این پیام را می‌بینید، تنظیمات درست است.", pid)
            if result.get("ok"):
                message = "پیام تست ارسال شد ✅ — کانال را چک کنید"
            else:
                error = f"خطای ارسال: {result.get('error', 'ناشناخته')}"

    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM telegram_settings WHERE project_id = ?", (pid,))
    s = cursor.fetchone()
    connection.close()
    return render_template("telegram_settings.html",
                           settings=dict(s) if s else None,
                           message=message, error=error)


@app.route("/daily_report_pdf")
@login_required
def daily_report_pdf():
    try:
        date_jalali = request.args.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
        path = generate_daily_pdf(date_jalali, current_project_id())
        if not path or not os.path.exists(path):
            return "خطا در تولید گزارش", 500
        filename = os.path.basename(path)
        return send_file(path, download_name=filename, as_attachment=True, mimetype="application/pdf")
    except Exception as e:
        import traceback
        traceback.print_exc()
        return f"خطای سرور: {e}", 500


@app.route("/send_daily_report_now", methods=["POST"])
@admin_required
def send_daily_report_now():
    try:
        date_jalali = request.form.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
        pid = current_project_id()
        path = generate_daily_pdf(date_jalali, pid)
        if not path or not os.path.exists(path):
            return jsonify({"ok": False, "error": "خطا در تولید PDF"})
        caption = f"گزارش روزانه {date_jalali}\n{get_setting('company_name', '')}"
        result = tg_send_doc(path, caption=caption, project_id=pid)
        if result.get("ok"):
            log_audit("daily_report", None, "ارسال به تلگرام", new_value=date_jalali)
            conn = get_db()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO report_history (project_id, report_type, report_date, file_path,
                    sent_via, recipients_count, sent_at, status)
                VALUES (?, 'daily', ?, ?, 'telegram', 1, ?, 'success')
            """, (pid, date_jalali, path, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()
            conn.close()
            return jsonify({"ok": True, "message": "گزارش با موفقیت ارسال شد"})
        return jsonify({"ok": False, "error": result.get("error", "خطای ناشناخته")})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": f"خطای سرور: {type(e).__name__} — {e}"})


def get_notifications(project_id=None, limit=100, only_unread=False):
    pid = project_id or current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    query = "SELECT * FROM notifications WHERE project_id = ?"
    params = [pid]
    if only_unread:
        query += " AND is_read = 0"
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    cursor.execute(query, params)
    rows = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return rows


@app.route("/notifications")
@login_required
def notifications_page():
    return render_template("notifications.html", notifications=get_notifications(limit=200))


@app.route("/notifications/mark_read/<int:nid>", methods=["POST"])
@login_required
def notification_mark_read(nid):
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        UPDATE notifications SET is_read = 1, read_by = ?, read_at = datetime('now')
        WHERE id = ? AND project_id = ?
    """, (session.get("username", ""), nid, current_project_id()))
    connection.commit()
    connection.close()
    return jsonify({"ok": True})


@app.route("/notifications/mark_all_read", methods=["POST"])
@login_required
def notification_mark_all_read():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        UPDATE notifications SET is_read = 1, read_by = ?, read_at = datetime('now')
        WHERE project_id = ? AND is_read = 0
    """, (session.get("username", ""), current_project_id()))
    connection.commit()
    connection.close()
    return redirect("/notifications")


@app.route("/api/notifications/count")
@login_required
def api_notifications_count():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT COUNT(*) as c FROM notifications WHERE project_id = ? AND is_read = 0",
                   (current_project_id(),))
    c = cursor.fetchone()["c"]
    connection.close()
    return jsonify({"unread": c})


# ═══════════ فاز E: نقش‌ها ═══════════
register_phase_e(app)


# ═══════════ فاز F: قوانین هشدار و Scheduler ═══════════

@app.route("/alert_rules", methods=["GET", "POST"])
@admin_required
def alert_rules_page():
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    if request.method == "POST":
        rule_id = int(request.form.get("rule_id", "0"))
        cursor.execute("""
            UPDATE alert_rules SET
                is_enabled = ?, threshold_minutes = ?, threshold_percent = ?,
                threshold_value = ?, severity = ?,
                send_telegram = ?, send_sms = ?, send_panel = ?,
                check_interval_minutes = ?, updated_at = datetime('now')
            WHERE id = ? AND project_id = ?
        """, (
            1 if request.form.get(f"enabled_{rule_id}") == "1" else 0,
            int(request.form.get(f"minutes_{rule_id}", "0") or 0),
            int(request.form.get(f"percent_{rule_id}", "0") or 0),
            float(request.form.get(f"value_{rule_id}", "0") or 0),
            request.form.get(f"severity_{rule_id}", "warning"),
            1 if request.form.get(f"tg_{rule_id}") == "1" else 0,
            1 if request.form.get(f"sms_{rule_id}") == "1" else 0,
            1 if request.form.get(f"panel_{rule_id}") == "1" else 0,
            int(request.form.get(f"interval_{rule_id}", "5") or 5),
            rule_id, pid
        ))
        connection.commit()
        log_audit("alert_rule", rule_id, "به‌روزرسانی قانون")

    cursor.execute("SELECT * FROM alert_rules WHERE project_id = ? ORDER BY id", (pid,))
    rules = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("alert_rules.html", rules=rules)


@app.route("/alerts/run_check_now", methods=["POST"])
@admin_required
def run_check_now():
    try:
        results = run_all_checks(project_id=current_project_id())
        return jsonify({"ok": True, "results": results})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/scheduler_status")
@admin_required
def scheduler_status_page():
    status = get_scheduler_status()
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM scheduler_history ORDER BY id DESC LIMIT 50")
    history = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("scheduler_status.html", status=status, history=history)


@app.route("/scheduler/run_job/<job_id>", methods=["POST"])
@admin_required
def run_scheduler_job(job_id):
    result = run_job_now(job_id)
    return jsonify(result)


@app.route("/report_history")
@login_required
def report_history_page():
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("""
        SELECT * FROM report_history WHERE project_id = ?
        ORDER BY id DESC LIMIT 200
    """, (current_project_id(),))
    reports = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("report_history.html", reports=reports)


# ═══════════ فاز G: محور پروژه ═══════════

@app.route("/project_corridor")
@login_required
def project_corridor_page():
    pid = current_project_id()
    corridor = get_active_corridor(pid)
    waypoints = get_corridor_waypoints(corridor["id"]) if corridor else []
    zones = get_zones()
    return render_template("project_corridor.html",
                           corridor=corridor, waypoints=waypoints,
                           zones=json.dumps([{
                               "id": z["id"], "name": z["zone_name"],
                               "type": z["zone_type"], "lat": z["center_lat"],
                               "lng": z["center_lng"], "radius": z["radius_meters"],
                               "color": z["color"] or "#3498db"
                           } for z in zones], ensure_ascii=False),
                           waypoints_json=json.dumps([{
                               "lat": w["lat"], "lng": w["lng"],
                               "km": w["km_marker"]
                           } for w in waypoints], ensure_ascii=False))


@app.route("/project_corridor/save", methods=["POST"])
@login_required
def project_corridor_save():
    try:
        data = request.get_json()
        pid = current_project_id()
        corridor_name = data.get("corridor_name", "محور اصلی پروژه").strip()
        description = data.get("description", "").strip()
        width_meters = float(data.get("width_meters", 200))
        color = data.get("color", "#e74c3c")
        waypoints = data.get("waypoints", [])
        corridor_id = data.get("corridor_id")

        if len(waypoints) < 2:
            return jsonify({"ok": False, "error": "حداقل ۲ نقطه برای محور لازم است"})

        result = save_corridor(pid, corridor_name, description, waypoints,
                                width_meters=width_meters, color=color,
                                created_by=session.get("username", ""),
                                corridor_id=corridor_id)
        log_audit("corridor", result["corridor_id"], "ذخیره محور",
                  new_value=f"طول: {result['total_km']} km, نقاط: {len(waypoints)}")
        return jsonify({"ok": True, "corridor_id": result["corridor_id"],
                         "total_km": result["total_km"]})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})


@app.route("/project_corridor/delete/<int:corridor_id>", methods=["POST"])
@admin_required
def project_corridor_delete(corridor_id):
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM corridor_waypoints WHERE corridor_id = ?", (corridor_id,))
    cur.execute("DELETE FROM project_corridors WHERE id = ? AND project_id = ?", (corridor_id, pid))
    conn.commit()
    conn.close()
    log_audit("corridor", corridor_id, "حذف محور")
    return redirect("/project_corridor")


@app.route("/project_corridor/update_gps", methods=["POST"])
@login_required
def project_corridor_update_gps():
    try:
        pid = current_project_id()
        result = update_gps_corridor_data(pid, batch_size=2000)
        return jsonify({"ok": True, "result": result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/corridor_status")
@login_required
def corridor_status_page():
    pid = current_project_id()
    corridor = get_active_corridor(pid)
    machines_km = get_machines_km_status(pid)
    return render_template("corridor_status.html",
                           corridor=corridor, machines=machines_km)


@app.route("/api/corridor_status")
@login_required
def api_corridor_status():
    pid = current_project_id()
    machines = get_machines_km_status(pid)
    return jsonify(machines)


@app.route("/live_map")
@login_required
def live_map_page():
    pid = current_project_id()
    corridor = get_active_corridor(pid)
    waypoints = get_corridor_waypoints(corridor["id"]) if corridor else []
    zones = get_zones()

    machines_data = get_machines_km_status(pid)
    machines_data = [m for m in machines_data if m.get("lat") and m.get("lng")]

    return render_template("live_map.html",
                           corridor=corridor,
                           waypoints_json=json.dumps([{
                               "lat": w["lat"], "lng": w["lng"], "km": w["km_marker"]
                           } for w in waypoints], ensure_ascii=False),
                           zones_json=json.dumps([{
                               "id": z["id"], "name": z["zone_name"],
                               "type": z["zone_type"], "lat": z["center_lat"],
                               "lng": z["center_lng"], "radius": z["radius_meters"],
                               "color": z["color"] or "#3498db"
                           } for z in zones], ensure_ascii=False),
                           machines_json=json.dumps([{
                               "id": m["id"], "code": m["code"], "name": m["name"],
                               "type": m["operational_type"],
                               "lat": m["lat"], "lng": m["lng"],
                               "km": m.get("km_formatted", "-"),
                               "in_corridor": m.get("in_corridor", 0)
                           } for m in machines_data], ensure_ascii=False))


# ═══════════ فاز H: پلاک‌خوان ═══════════

@app.route("/api/anpr/webhook", methods=["POST"])
def anpr_webhook():
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        if not data:
            return jsonify({"ok": False, "error": "بدون داده"}), 400
        result = process_anpr_event(data, project_id=1)
        return jsonify(result), (200 if result.get("ok") else 400)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/anpr_events")
@login_required
def anpr_events_page():
    only_unknown = request.args.get("unknown") == "1"
    camera_id = request.args.get("camera_id", type=int)
    events = anpr_get_events(current_project_id(), limit=300,
                              only_unknown=only_unknown, camera_id=camera_id)
    cameras = anpr_get_cameras(current_project_id())
    return render_template("anpr_events.html", events=events, cameras=cameras,
                           only_unknown=only_unknown, camera_id=camera_id)


@app.route("/anpr_cameras", methods=["GET", "POST"])
@login_required
def anpr_cameras_page():
    pid = current_project_id()
    if request.method == "POST":
        action = request.form.get("action", "add")
        connection = get_db()
        cursor = connection.cursor()
        if action == "add":
            cursor.execute("""
                INSERT INTO anpr_cameras (project_id, camera_name, camera_code, location,
                    camera_type, direction, api_url, is_active, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (pid,
                  request.form.get("camera_name", "").strip(),
                  request.form.get("camera_code", "").strip(),
                  request.form.get("location", "").strip(),
                  request.form.get("camera_type", "ANPR"),
                  request.form.get("direction", "دو طرفه"),
                  request.form.get("api_url", "").strip(),
                  1 if request.form.get("is_active") == "1" else 0,
                  request.form.get("note", ""),
                  datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            cid = cursor.lastrowid
            log_audit("anpr_camera", cid, "افزودن دوربین", new_value=request.form.get("camera_name", ""))
        elif action == "delete":
            cid = int(request.form.get("id", "0"))
            cursor.execute("DELETE FROM anpr_cameras WHERE id = ? AND project_id = ?", (cid, pid))
            log_audit("anpr_camera", cid, "حذف")
        connection.commit()
        connection.close()
        return redirect("/anpr_cameras")
    return render_template("anpr_cameras.html", cameras=anpr_get_cameras(pid))


@app.route("/plate_whitelist", methods=["GET", "POST"])
@login_required
def plate_whitelist_page():
    pid = current_project_id()
    if request.method == "POST":
        action = request.form.get("action", "add")
        connection = get_db()
        cursor = connection.cursor()
        if action == "add":
            plate_raw = request.form.get("plate", "").strip()
            plate_norm = normalize_plate(plate_raw)
            machine_id = request.form.get("machine_id") or None
            if machine_id:
                machine_id = int(machine_id)
            try:
                cursor.execute("""
                    INSERT INTO plate_whitelist (project_id, plate_normalized, plate_display,
                        machine_id, owner_name, note, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                """, (pid, plate_norm, plate_raw, machine_id,
                      request.form.get("owner_name", ""),
                      request.form.get("note", ""),
                      datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                if machine_id:
                    cursor.execute("UPDATE machines SET plate_normalized = ? WHERE id = ?",
                                   (plate_norm, machine_id))
                log_audit("plate", None, "افزودن پلاک", new_value=plate_raw)
            except sqlite3.IntegrityError:
                pass
        elif action == "delete":
            wid = int(request.form.get("id", "0"))
            cursor.execute("DELETE FROM plate_whitelist WHERE id = ? AND project_id = ?", (wid, pid))
            log_audit("plate", wid, "حذف")
        connection.commit()
        connection.close()
        return redirect("/plate_whitelist")
    return render_template("plate_whitelist.html",
                           whitelist=anpr_get_whitelist(pid),
                           machines=get_machines())


@app.route("/anpr_settings", methods=["GET", "POST"])
@admin_required
def anpr_settings_page():
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()
    if request.method == "POST":
        cursor.execute("""
            UPDATE anpr_settings SET
                direction_mode = ?, store_images = ?, image_retention_days = ?,
                unknown_plate_alert = ?, min_confidence = ?,
                webhook_secret_global = ?, updated_at = datetime('now')
            WHERE project_id = ?
        """, (
            request.form.get("direction_mode", "auto_sequence"),
            1 if request.form.get("store_images") == "1" else 0,
            int(request.form.get("image_retention_days", "60") or 60),
            1 if request.form.get("unknown_plate_alert") == "1" else 0,
            float(request.form.get("min_confidence", "70") or 70),
            request.form.get("webhook_secret_global", "").strip(),
            pid
        ))
        connection.commit()
        log_audit("anpr_settings", pid, "به‌روزرسانی")

    cursor.execute("SELECT * FROM anpr_settings WHERE project_id = ?", (pid,))
    s = cursor.fetchone()
    connection.close()
    return render_template("anpr_settings.html", settings=dict(s) if s else None)


@app.route("/anpr_events/link/<int:event_id>", methods=["POST"])
@login_required
def anpr_event_link(event_id):
    machine_id = request.form.get("machine_id")
    if not machine_id:
        return redirect(request.referrer or "/anpr_events")
    machine_id = int(machine_id)
    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM anpr_events WHERE id = ? AND project_id = ?",
                   (event_id, current_project_id()))
    ev = cursor.fetchone()
    if not ev:
        connection.close()
        return redirect("/anpr_events")

    cursor.execute("SELECT code, name FROM machines WHERE id = ?", (machine_id,))
    m = cursor.fetchone()

    cursor.execute("""
        UPDATE anpr_events SET machine_id = ?, machine_code = ?, is_known = 1,
            reviewed = 1, reviewed_by = ?, reviewed_at = datetime('now')
        WHERE id = ?
    """, (machine_id, m["code"] if m else "", session.get("username", ""), event_id))

    try:
        cursor.execute("""
            INSERT OR IGNORE INTO plate_whitelist (project_id, plate_normalized, plate_display,
                machine_id, note, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, 1, datetime('now'))
        """, (current_project_id(), ev["plate_normalized"], ev["plate_raw"], machine_id,
              "اضافه‌شده از رویداد دستی"))
        cursor.execute("UPDATE machines SET plate_normalized = ? WHERE id = ?",
                       (ev["plate_normalized"], machine_id))
    except Exception:
        pass

    connection.commit()
    connection.close()
    log_audit("anpr_event", event_id, "اتصال دستی به ماشین", new_value=m["name"] if m else "")
    return redirect(request.referrer or "/anpr_events")


# ═══════════ تنظیمات نوع ماشین ═══════════

@app.route("/machine_type_settings", methods=["GET", "POST"])
@admin_required
def machine_type_settings_page():
    pid = current_project_id()
    connection = get_db()
    cursor = connection.cursor()

    if request.method == "POST":
        setting_id = int(request.form.get("id", "0"))
        fields = [
            "stop_speed_threshold", "stop_min_duration",
            "long_stop_threshold", "suspicious_stop_threshold",
            "work_area_radius_meters", "work_area_min_duration",
            "expected_daily_hours", "idle_running_alert",
            "loader_pairing_radius", "loader_min_loading_seconds",
            "dozer_min_pass_length", "dozer_max_pass_speed",
            "excavator_min_cycle_seconds",
            "truck_min_loading_seconds", "truck_min_dumping_seconds",
        ]
        values = []
        for f in fields:
            v = request.form.get(f, "").strip()
            try:
                values.append(float(v) if "." in v or f == "expected_daily_hours" else int(v or 0))
            except:
                values.append(0)

        enabled = 1 if request.form.get("enabled") == "1" else 0
        note = request.form.get("note", "").strip()
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        set_clause = ", ".join([f"{f} = ?" for f in fields])
        cursor.execute(f"""
            UPDATE machine_type_settings
            SET {set_clause}, enabled = ?, note = ?, updated_at = ?
            WHERE id = ? AND project_id = ?
        """, values + [enabled, note, now, setting_id, pid])
        connection.commit()
        log_audit("machine_type_settings", setting_id, "به‌روزرسانی")

    cursor.execute("""
        SELECT mts.*,
            (SELECT COUNT(*) FROM machines WHERE machine_category = mts.machine_category AND project_id = ?) as machines_count
        FROM machine_type_settings mts
        WHERE mts.project_id = ?
        ORDER BY mts.id
    """, (pid, pid))
    settings = [dict(r) for r in cursor.fetchall()]
    connection.close()
    return render_template("machine_type_settings.html", settings=settings)


@app.route("/machine_typed_analysis/<int:machine_id>")
@login_required
def machine_typed_analysis(machine_id):
    date_jalali = request.args.get("date", jdatetime.date.today().strftime("%Y/%m/%d"))
    date_greg = jalali_to_greg(date_jalali)
    pid = current_project_id()

    connection = get_db()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM machines WHERE id = ? AND project_id = ?", (machine_id, pid))
    machine = cursor.fetchone()
    connection.close()
    if not machine:
        return redirect("/machines")

    result = run_typed_analysis(machine["code"], date_greg, pid)
    return render_template("machine_typed_analysis.html",
                           machine=dict(machine),
                           result=result,
                           date_jalali=date_jalali)


# ═══════════ راه‌اندازی Scheduler ═══════════
try:
    start_scheduler(app)
except Exception as e:
    print(f"[scheduler startup error] {e}")

# ═══════════ Backup ═══════════

from backup_engine import create_backup, get_backup_list, restore_backup, cleanup_old_backups, get_backup_stats, list_backups, delete_backup


@app.route("/backups")
@admin_required
def backups_alias():
    return backup_page()

@app.route("/backup")
@admin_required
def backup_page():
    backups = get_backup_list()
    return render_template("backups.html", backups=backups, stats=get_backup_stats())


@app.route("/backup/create_now", methods=["POST"])
@admin_required
def backup_create_now():
    try:
        result = create_backup(compress=True, keep_days=30)
        if result.get("ok"):
            log_audit("backup", None, "ایجاد Backup دستی",
                      new_value=f"{result['filename']} - {result['size_mb']} MB")
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/backup/download/<filename>")
@admin_required
def backup_download(filename):
    if not filename.endswith(".zip") or "/" in filename or "\\" in filename:
        return "نام فایل نامعتبر", 400
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backups", filename)
    if not os.path.exists(filepath):
        return "فایل یافت نشد", 404
    return send_file(filepath, as_attachment=True, download_name=filename)


@app.route("/backup/delete/<filename>", methods=["POST"])
@admin_required
def backup_delete_route(filename):
    result = delete_backup(filename)
    if result.get("ok"):
        log_audit("backup", None, "حذف Backup", old_value=filename)
    return jsonify(result)


@app.route("/backup/cleanup", methods=["POST"])
@admin_required
def backup_cleanup():
    keep = int(request.form.get("keep", "30"))
    result = cleanup_old_backups(keep_count=keep)
    log_audit("backup", None, "پاک‌سازی قدیمی‌ها", new_value=f"حذف: {result['deleted']}")
    return jsonify({"ok": True, **result})

# ═══════════ داشبورد پیشرفته — API های داده گراف ═══════════

@app.route("/api/dashboard/kpi")
@login_required
def api_dashboard_kpi():
    """شاخص‌های کلیدی داشبورد"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    today = datetime.date.today().strftime("%Y-%m-%d")

    # ماشین‌ها
    cur.execute("SELECT COUNT(*) as c FROM machines WHERE project_id = ?", (pid,))
    total_machines = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM machines WHERE project_id = ? AND active_status = 'فعال'", (pid,))
    active_machines = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM machines WHERE project_id = ? AND active_status = 'در تعمیرگاه'", (pid,))
    repair_machines = cur.fetchone()["c"]

    # پرسنل حاضر امروز
    cur.execute("""
        SELECT COUNT(DISTINCT personnel_code) as c FROM personnel_attendance
        WHERE project_id = ? AND work_date = ?
    """, (pid, today))
    present_today = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) as c FROM personnel WHERE project_id = ? AND status = 'فعال'", (pid,))
    total_personnel = cur.fetchone()["c"]

    # سرویس‌های امروز
    cur.execute("SELECT COUNT(*) as c FROM truck_services WHERE project_id = ? AND work_date = ?", (pid, today))
    services_today = cur.fetchone()["c"]

    # مسافت امروز
    cur.execute("SELECT SUM(distance_km) as d FROM daily_machine_summary WHERE project_id = ? AND work_date = ?", (pid, today))
    row = cur.fetchone()
    distance_today = round(row["d"] or 0, 1)

    # هشدارهای فعال
    cur.execute("SELECT COUNT(*) as c FROM notifications WHERE project_id = ? AND is_read = 0", (pid,))
    active_alerts = cur.fetchone()["c"]

    # ماشین‌های آنلاین (آخرین 5 دقیقه)
    cutoff = (datetime.datetime.now() - datetime.timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("""
        SELECT COUNT(DISTINCT machine_code) as c FROM gps_points
        WHERE project_id = ? AND recorded_at >= ?
    """, (pid, cutoff))
    online_now = cur.fetchone()["c"]

    # هدف کل و تحقق
    cur.execute("SELECT SUM(target_services) as t FROM truck_services WHERE project_id = ? AND work_date = ?", (pid, today))
    row = cur.fetchone()
    target_today = row["t"] or 0
    achievement = round(services_today * 100 / target_today, 1) if target_today > 0 else 0

    conn.close()

    return jsonify({
        "machines": {
            "total": total_machines, "active": active_machines,
            "repair": repair_machines, "online_now": online_now
        },
        "personnel": {"total": total_personnel, "present_today": present_today},
        "services": {
            "today": services_today, "target": target_today,
            "achievement_percent": achievement
        },
        "distance_today": distance_today,
        "active_alerts": active_alerts,
    })


@app.route("/api/dashboard/production_trend")
@login_required
def api_dashboard_production_trend():
    """روند تولید ۳۰ روز گذشته"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    today = datetime.date.today()
    start_date = (today - datetime.timedelta(days=29)).strftime("%Y-%m-%d")

    cur.execute("""
        SELECT work_date, COUNT(*) as service_count,
               SUM(distance_km) as total_distance
        FROM truck_services
        WHERE project_id = ? AND work_date >= ?
        GROUP BY work_date ORDER BY work_date
    """, (pid, start_date))
    services_by_day = {r["work_date"]: dict(r) for r in cur.fetchall()}

    # لیست همه روزها با مقادیر صفر برای روزهای بدون داده
    labels = []
    services = []
    distances = []
    for i in range(30):
        d = (today - datetime.timedelta(days=29 - i))
        d_str = d.strftime("%Y-%m-%d")
        try:
            jd = jdatetime.date.fromgregorian(date=d)
            labels.append(f"{jd.month}/{jd.day}")
        except:
            labels.append(d_str[5:])
        if d_str in services_by_day:
            services.append(services_by_day[d_str]["service_count"] or 0)
            distances.append(round(services_by_day[d_str]["total_distance"] or 0, 1))
        else:
            services.append(0)
            distances.append(0)

    conn.close()
    return jsonify({"labels": labels, "services": services, "distances": distances})


@app.route("/api/dashboard/machines_comparison")
@login_required
def api_dashboard_machines_comparison():
    """مقایسه ماشین‌ها — تعداد سرویس ۷ روز گذشته"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    start_date = (datetime.date.today() - datetime.timedelta(days=6)).strftime("%Y-%m-%d")

    cur.execute("""
        SELECT ts.machine_code, m.name, COUNT(*) as total,
               AVG(ts.total_cycle_minutes) as avg_cycle
        FROM truck_services ts
        LEFT JOIN machines m ON ts.machine_code = m.code
        WHERE ts.project_id = ? AND ts.work_date >= ?
        GROUP BY ts.machine_code
        ORDER BY total DESC LIMIT 10
    """, (pid, start_date))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    return jsonify({
        "labels": [r["name"] or r["machine_code"] for r in rows],
        "services": [r["total"] for r in rows],
        "avg_cycles": [round(r["avg_cycle"] or 0) for r in rows],
    })


@app.route("/api/dashboard/machine_status")
@login_required
def api_dashboard_machine_status():
    """توزیع وضعیت ماشین‌ها — دایره‌ای"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT active_status, COUNT(*) as c
        FROM machines WHERE project_id = ?
        GROUP BY active_status
    """, (pid,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    return jsonify({
        "labels": [r["active_status"] or "نامشخص" for r in rows],
        "values": [r["c"] for r in rows],
    })


@app.route("/api/dashboard/hourly_heatmap")
@login_required
def api_dashboard_hourly_heatmap():
    """Heat map — ساعت‌های پرکار (میانگین ۷ روز گذشته)"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    start_date = (datetime.date.today() - datetime.timedelta(days=6)).strftime("%Y-%m-%d")

    cur.execute("""
        SELECT CAST(strftime('%H', recorded_at) AS INTEGER) as hour, COUNT(*) as c
        FROM gps_points
        WHERE project_id = ? AND date(recorded_at) >= ?
        GROUP BY hour ORDER BY hour
    """, (pid, start_date))
    data = {r["hour"]: r["c"] for r in cur.fetchall()}
    conn.close()

    hours = list(range(24))
    values = [data.get(h, 0) for h in hours]
    labels = [f"{h:02d}" for h in hours]

    return jsonify({"labels": labels, "values": values})


@app.route("/api/dashboard/recent_alerts")
@login_required
def api_dashboard_recent_alerts():
    """آخرین هشدارها — 10 مورد"""
    pid = current_project_id()
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT id, title, severity, created_at, is_read
        FROM notifications WHERE project_id = ?
        ORDER BY id DESC LIMIT 10
    """, (pid,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return jsonify(rows)


@app.route("/api/dashboard/machines_live")
@login_required
def api_dashboard_machines_live():
    """ماشین‌های آنلاین + وضعیت"""
    return jsonify(get_trackers_live_status()[:8])
if __name__ == "__main__":
    if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        try:
            start_scheduler(app)
        except Exception as e:
            print(f"[scheduler startup error] {e}")
    app.run(debug=True, port=5050, use_reloader=False)
# -*- coding: utf-8 -*-
"""تشخیص مشکل اصلاح دستی"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

print("=" * 70)
print("تشخیص اصلاحات دستی")
print("=" * 70)

# ۱. آیا جدول وجود دارد؟
cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='attendance_adjustments'")
if not cur.fetchone():
    print("\n❌ جدول attendance_adjustments وجود ندارد!")
    print("   باید ابتدا python migrate_v3.py را اجرا کنید.")
    exit()

print("\n✅ جدول attendance_adjustments وجود دارد")

# ۲. ساختار جدول
cur.execute("PRAGMA table_info(attendance_adjustments)")
print("\n📋 ستون‌های جدول:")
for c in cur.fetchall():
    print(f"   - {c['name']} ({c['type']})")

# ۳. تعداد رکوردها
cur.execute("SELECT COUNT(*) as c FROM attendance_adjustments")
count = cur.fetchone()["c"]
print(f"\n📊 تعداد رکورد اصلاح دستی: {count}")

if count == 0:
    print("\n⚠️ هیچ رکورد اصلاحی در دیتابیس نیست!")
    print("   یعنی وقتی از فرم اصلاح دستی ذخیره می‌کنید، رکورد ثبت نمی‌شود.")
    print("   احتمال: مشکل در Route /monthly_report/adjust")
    exit()

# ۴. نمایش رکوردها
print("\n📝 آخرین ۱۰ اصلاح دستی:")
cur.execute("""
    SELECT aa.*, p.full_name, p.personnel_code
    FROM attendance_adjustments aa
    LEFT JOIN personnel p ON aa.personnel_id = p.id
    ORDER BY aa.id DESC LIMIT 10
""")

for r in cur.fetchall():
    print(f"\n   🔹 ID: {r['id']}")
    print(f"      پرسنل: {r['full_name']} ({r['personnel_code']})")
    print(f"      تاریخ: {r['work_date']}")
    print(f"      ورود اصلاح شده: '{r['adjusted_start']}'")
    print(f"      خروج اصلاح شده: '{r['adjusted_end']}'")
    print(f"      توضیح: {r['note']}")
    print(f"      توسط: {r['adjusted_by']} در {r['adjusted_at']}")

# ۵. بررسی یک روز اصلاح شده
print("\n" + "=" * 70)
print("تست: یک روز اصلاح شده را چک می‌کنیم")
print("=" * 70)

cur.execute("""
    SELECT aa.*, p.full_name, p.personnel_code, p.project_id
    FROM attendance_adjustments aa
    LEFT JOIN personnel p ON aa.personnel_id = p.id
    ORDER BY aa.id DESC LIMIT 1
""")
adj = cur.fetchone()

if adj:
    print(f"\n👤 پرسنل: {adj['full_name']} (id={adj['personnel_id']})")
    print(f"📅 تاریخ اصلاح: {adj['work_date']}")
    print(f"   ورود اصلاح: '{adj['adjusted_start']}'")
    print(f"   خروج اصلاح: '{adj['adjusted_end']}'")
    
    # آیا این تاریخ در personnel_attendance هم هست؟
    # تبدیل تاریخ شمسی به میلادی
    import jdatetime
    try:
        parts = adj['work_date'].split('/')
        greg = jdatetime.date(int(parts[0]), int(parts[1]), int(parts[2])).togregorian()
        greg_str = greg.strftime("%Y-%m-%d")
        print(f"\n🔍 معادل میلادی: {greg_str}")
        
        cur.execute("""
            SELECT * FROM personnel_attendance
            WHERE project_id = ? AND personnel_code = ? AND work_date = ?
        """, (adj['project_id'], adj['personnel_code'], greg_str))
        att = cur.fetchone()
        
        if att:
            print(f"\n📋 تردد اصلی در همان روز:")
            print(f"   ورود: {att['start_time']}")
            print(f"   خروج: {att['end_time']}")
        else:
            print(f"\n📋 تردد اصلی: ندارد (غیبت بوده)")
    except Exception as e:
        print(f"\n⚠️ خطا در تبدیل تاریخ: {e}")

conn.close()
print("\n" + "=" * 70)
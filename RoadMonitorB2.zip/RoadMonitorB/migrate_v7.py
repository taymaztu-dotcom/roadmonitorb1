# -*- coding: utf-8 -*-
"""Migration v7 — فاز D: اعلانات، پیامک، تلگرام، سرویس هدف"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v7 — فاز D")
    print("=" * 60)

    # ── جدول سرویس هدف بر اساس فاصله ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS service_targets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            distance_from_km REAL NOT NULL,
            distance_to_km REAL NOT NULL,
            target_services_per_day INTEGER NOT NULL,
            standard_cycle_minutes INTEGER DEFAULT 15,
            tolerance_services INTEGER DEFAULT 2,
            note TEXT,
            created_at TEXT
        )
    """)
    print("  [+] service_targets")

    # درج بازه‌های پیش‌فرض
    cur.execute("SELECT COUNT(*) FROM service_targets WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        defaults = [
            (1, 0.0,  1.0,  50, 12, 2, "فاصله کم — سیکل کوتاه"),
            (1, 1.0,  3.0,  40, 15, 2, "فاصله متوسط"),
            (1, 3.0,  5.0,  30, 20, 2, ""),
            (1, 5.0,  10.0, 20, 30, 2, ""),
            (1, 10.0, 20.0, 10, 50, 1, "فاصله زیاد"),
            (1, 20.0, 999.0, 5, 90, 1, "فاصله خیلی زیاد"),
        ]
        for d in defaults:
            cur.execute("""
                INSERT INTO service_targets
                (project_id, distance_from_km, distance_to_km, target_services_per_day,
                 standard_cycle_minutes, tolerance_services, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
            """, d)
        print(f"  [+] {len(defaults)} بازه پیش‌فرض درج شد")

    # ── اضافه کردن فاصله به truck_services ──
    cur.execute("PRAGMA table_info(truck_services)")
    cols = [r[1] for r in cur.fetchall()]
    if "distance_km" not in cols:
        cur.execute("ALTER TABLE truck_services ADD COLUMN distance_km REAL DEFAULT 0")
        print("  [+] ستون distance_km به truck_services")
    if "target_services" not in cols:
        cur.execute("ALTER TABLE truck_services ADD COLUMN target_services INTEGER DEFAULT 0")
        print("  [+] ستون target_services به truck_services")

    # ── جدول اعلانات ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            notification_type TEXT NOT NULL,
            severity TEXT DEFAULT 'info',
            title TEXT NOT NULL,
            message TEXT,
            related_type TEXT,
            related_id INTEGER,
            is_read INTEGER DEFAULT 0,
            read_by TEXT,
            read_at TEXT,
            channels_sent TEXT,
            created_at TEXT
        )
    """)
    print("  [+] notifications")

    # ── تنظیمات تلگرام ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS telegram_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER UNIQUE,
            bot_token TEXT,
            channel_chat_id TEXT,
            proxy_url TEXT,
            is_enabled INTEGER DEFAULT 0,
            send_daily_report INTEGER DEFAULT 1,
            daily_report_time TEXT DEFAULT '09:00',
            send_alerts INTEGER DEFAULT 1,
            last_test_at TEXT,
            last_test_result TEXT,
            updated_at TEXT
        )
    """)
    print("  [+] telegram_settings")

    # ── تنظیمات پیامک ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sms_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER UNIQUE,
            provider TEXT DEFAULT 'gsm_modem',
            gsm_port TEXT,
            gsm_baudrate INTEGER DEFAULT 115200,
            gsm_pin TEXT,
            is_enabled INTEGER DEFAULT 0,
            send_alerts INTEGER DEFAULT 1,
            updated_at TEXT
        )
    """)
    print("  [+] sms_settings")

    # ── گیرندگان گزارش ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS notification_recipients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            full_name TEXT NOT NULL,
            phone TEXT,
            role TEXT,
            receive_urgent_alert INTEGER DEFAULT 0,
            receive_daily_summary INTEGER DEFAULT 0,
            receive_weekly_summary INTEGER DEFAULT 0,
            receive_monthly_summary INTEGER DEFAULT 0,
            channel_sms INTEGER DEFAULT 0,
            channel_telegram INTEGER DEFAULT 0,
            channel_panel INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1,
            note TEXT,
            created_at TEXT
        )
    """)
    print("  [+] notification_recipients")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v7 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
    
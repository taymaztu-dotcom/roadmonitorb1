# -*- coding: utf-8 -*-
"""Migration v6 — فاز C: تحلیل هوشمند"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    print("=" * 60)
    print("Migration v6 — فاز C: تحلیل هوشمند")
    print("=" * 60)

    # ─── جدول توقف‌های تحلیل شده ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS analyzed_stops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT NOT NULL,
            imei TEXT,
            work_date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            duration_minutes INTEGER,
            lat REAL,
            lng REAL,
            zone_id INTEGER,
            zone_type TEXT,
            stop_category TEXT DEFAULT 'عادی',
            trust_level TEXT DEFAULT 'بالا',
            note TEXT,
            reviewed INTEGER DEFAULT 0,
            reviewed_by TEXT,
            reviewed_at TEXT,
            exception_id INTEGER,
            created_at TEXT
        )
    """)
    print("  [+] analyzed_stops")

    # ─── جدول رویدادهای Zone (ورود/خروج) ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS zone_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT,
            imei TEXT,
            zone_id INTEGER,
            zone_type TEXT,
            zone_name TEXT,
            event_type TEXT,
            event_time TEXT,
            duration_minutes INTEGER,
            related_gps_id INTEGER,
            trust_level TEXT DEFAULT 'بالا',
            created_at TEXT
        )
    """)
    print("  [+] zone_events")

    # ─── جدول کاندید جبهه کار پویا ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS work_front_candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT,
            work_date TEXT,
            center_lat REAL,
            center_lng REAL,
            radius_meters REAL,
            first_seen TEXT,
            last_seen TEXT,
            duration_minutes INTEGER,
            point_count INTEGER,
            movement_pattern TEXT,
            trust_level TEXT DEFAULT 'متوسط',
            confirmed_zone_id INTEGER,
            confirmed INTEGER DEFAULT 0,
            note TEXT,
            created_at TEXT
        )
    """)
    print("  [+] work_front_candidates")

    # ─── جدول سرویس‌های تحلیل شده کامیون ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS truck_services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT,
            work_date TEXT,
            service_number INTEGER,
            loading_zone_id INTEGER,
            dumping_zone_id INTEGER,
            loading_enter_time TEXT,
            loading_exit_time TEXT,
            loading_duration_minutes INTEGER,
            dumping_enter_time TEXT,
            dumping_exit_time TEXT,
            dumping_duration_minutes INTEGER,
            travel_out_minutes INTEGER,
            travel_back_minutes INTEGER,
            total_cycle_minutes INTEGER,
            trust_level TEXT DEFAULT 'بالا',
            note TEXT,
            created_at TEXT
        )
    """)
    print("  [+] truck_services")

    # ─── جدول خلاصه روزانه تحلیل ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS daily_machine_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            machine_code TEXT,
            work_date TEXT UNIQUE,
            first_gps_time TEXT,
            last_gps_time TEXT,
            total_points INTEGER,
            distance_km REAL,
            max_speed INTEGER,
            avg_moving_speed INTEGER,
            moving_minutes INTEGER,
            idle_running_minutes INTEGER,
            engine_off_minutes INTEGER,
            stops_count INTEGER,
            long_stops_count INTEGER,
            suspicious_stops_count INTEGER,
            effective_work_minutes INTEGER,
            services_count INTEGER,
            gate_enter_time TEXT,
            gate_exit_time TEXT,
            night_park_lat REAL,
            night_park_lng REAL,
            data_quality TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    print("  [+] daily_machine_summary")

    # ─── تنظیمات تحلیل ───
    cur.execute("""
        CREATE TABLE IF NOT EXISTS analysis_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER UNIQUE,
            stop_speed_threshold INTEGER DEFAULT 3,
            stop_min_duration_minutes INTEGER DEFAULT 3,
            long_stop_threshold_minutes INTEGER DEFAULT 15,
            suspicious_stop_threshold_minutes INTEGER DEFAULT 30,
            work_front_min_duration_minutes INTEGER DEFAULT 15,
            work_front_cluster_radius_meters INTEGER DEFAULT 100,
            service_min_loading_seconds INTEGER DEFAULT 60,
            gps_timeout_minutes INTEGER DEFAULT 10,
            updated_at TEXT
        )
    """)

    # مقدار پیش‌فرض
    cur.execute("SELECT COUNT(*) FROM analysis_settings WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        cur.execute("""
            INSERT INTO analysis_settings (project_id, updated_at)
            VALUES (1, datetime('now'))
        """)
    print("  [+] analysis_settings")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v6 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
tables = [r[0] for r in cur.fetchall()]
print("جدول‌های موجود:")
for t in tables:
    print(f"  - {t}")

needed = ["analyzed_stops", "zone_events", "truck_services",
          "work_front_candidates", "daily_machine_summary", "analysis_settings"]
missing = [n for n in needed if n not in tables]
if missing:
    print("\n❌ جدول‌های گم‌شده:")
    for m in missing:
        print(f"  - {m}")
    print("\n👉 python migrate_v6.py را اجرا کنید")
else:
    print("\n✅ همه جدول‌های فاز C موجود هستند")

conn.close()

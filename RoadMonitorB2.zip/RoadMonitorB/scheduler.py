# -*- coding: utf-8 -*-
"""زمان‌بند پایدار پروژه: هشدار، تحلیل، گزارش و پشتیبان‌گیری."""
import os
import sqlite3
import datetime
import jdatetime
from apscheduler.schedulers.background import BackgroundScheduler

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")
_scheduler = None


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def log_history(job_key, job_name, status, result_summary="", alerts_created=0, error=""):
    try:
        conn = get_db()
        conn.execute(
            """INSERT INTO scheduler_history
               (job_key, job_name, started_at, finished_at, status, result_summary, alerts_created, error_message)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (job_key, job_name, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), status,
             str(result_summary)[:500], int(alerts_created or 0), str(error)[:500]),
        )
        conn.commit(); conn.close()
    except Exception as exc:
        print(f"[scheduler log error] {exc}")


def job_check_alerts():
    try:
        from alert_engine import run_all_checks
        results = run_all_checks(project_id=1)
        total = int(results.get("total", 0) or 0) if isinstance(results, dict) else 0
        summary = ", ".join(f"{k}:{v}" for k, v in (results or {}).items() if isinstance(v, int)) if isinstance(results, dict) else ""
        log_history("check_alerts", "چک هشدارهای خودکار", "success", summary, total)
    except Exception as exc:
        log_history("check_alerts", "چک هشدارهای خودکار", "error", error=exc)


def job_run_analysis():
    try:
        yesterday = (datetime.date.today() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        from analysis_engine import run_analysis_for_all_machines
        results = run_analysis_for_all_machines(yesterday, project_id=1)
        log_history("auto_analysis", "تحلیل خودکار روزانه", "success", f"{len(results)} ماشین تحلیل شد")
    except Exception as exc:
        log_history("auto_analysis", "تحلیل خودکار روزانه", "error", error=exc)


def job_send_daily_report():
    try:
        conn = get_db(); row = conn.execute("SELECT * FROM telegram_settings WHERE project_id = 1 LIMIT 1").fetchone(); conn.close()
        if not row or not row["is_enabled"] or not row["send_daily_report"]:
            log_history("daily_report", "گزارش روزانه", "skipped", "تلگرام غیرفعال است")
            return
        yesterday = jdatetime.date.today() - jdatetime.timedelta(days=1)
        date_jalali = yesterday.strftime("%Y/%m/%d")
        from pdf_report import generate_daily_pdf
        from telegram_provider import send_document as tg_send_doc
        path = generate_daily_pdf(date_jalali, project_id=1)
        if not path or not os.path.exists(path):
            raise RuntimeError("PDF ساخته نشد")
        result = tg_send_doc(path, caption=f"گزارش روزانه {date_jalali}", project_id=1)
        if result.get("ok"):
            log_history("daily_report", "گزارش روزانه", "success", f"ارسال شد: {date_jalali}")
        else:
            log_history("daily_report", "گزارش روزانه", "error", error=result.get("error", ""))
    except Exception as exc:
        log_history("daily_report", "گزارش روزانه", "error", error=exc)


def job_backup_database():
    try:
        from backup_engine import create_backup
        result = create_backup(compress=True, keep_days=30)
        if result.get("ok"):
            log_history("backup", "Backup دیتابیس", "success", result.get("filename", ""))
        else:
            log_history("backup", "Backup دیتابیس", "error", error=result.get("error", ""))
    except Exception as exc:
        log_history("backup", "Backup دیتابیس", "error", error=exc)


def start_scheduler(app=None):
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = BackgroundScheduler(timezone="Asia/Tehran")
    _scheduler.add_job(job_check_alerts, "interval", minutes=5, id="check_alerts", replace_existing=True, max_instances=1, coalesce=True)
    _scheduler.add_job(job_run_analysis, "cron", hour=1, minute=0, id="auto_analysis", replace_existing=True, max_instances=1, coalesce=True)
    _scheduler.add_job(job_send_daily_report, "cron", hour=9, minute=0, id="daily_report", replace_existing=True, max_instances=1, coalesce=True)
    _scheduler.add_job(job_backup_database, "cron", hour=2, minute=0, id="backup_database", replace_existing=True, max_instances=1, coalesce=True)
    _scheduler.start()
    return _scheduler


def update_daily_report_time(hour, minute):
    if _scheduler is None:
        return
    _scheduler.reschedule_job("daily_report", trigger="cron", hour=int(hour), minute=int(minute))


def run_job_now(job_id):
    if _scheduler is None:
        return {"ok": False, "error": "Scheduler not started"}
    job = _scheduler.get_job(job_id)
    if not job:
        return {"ok": False, "error": "Job not found"}
    try:
        job.func(); return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def get_scheduler_status():
    if _scheduler is None:
        return {"running": False, "jobs": []}
    return {"running": _scheduler.running,
            "jobs": [{"id": j.id, "name": j.name, "next_run": str(j.next_run_time) if j.next_run_time else "-", "trigger": str(j.trigger)} for j in _scheduler.get_jobs()]}

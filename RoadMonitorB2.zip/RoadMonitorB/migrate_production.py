# -*- coding: utf-8 -*-
"""مهاجرت غیرمخرب دیتابیس عملیاتی به طرح داده پایلوت."""
import os, sqlite3, datetime
DB_PATH=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'roadmonitor.db')


def ensure_column(cur, table, column, ddl):
    cols={r[1] for r in cur.execute(f'PRAGMA table_info("{table}")')}
    if column not in cols:
        cur.execute(f'ALTER TABLE "{table}" ADD COLUMN {column} {ddl}')


def migrate(db_path=DB_PATH):
    con=sqlite3.connect(db_path, timeout=20)
    cur=con.cursor()
    # Raw/confirmed lineage for the pilot acceptance model.
    for c,d in [('source_event_id','TEXT'),('data_layer',"TEXT DEFAULT 'raw'"),('ingest_status',"TEXT DEFAULT 'accepted'")]:
        ensure_column(cur,'gps_points',c,d)
    for c,d in [('source_event_id','TEXT'),('raw_event','TEXT'),('data_layer',"TEXT DEFAULT 'raw'"),('ingest_status',"TEXT DEFAULT 'accepted'")]:
        ensure_column(cur,'zk_logs',c,d)
    for c,d in [('source_event_id','TEXT'),('data_layer',"TEXT DEFAULT 'raw'"),('ingest_status',"TEXT DEFAULT 'accepted'"),('correction_reason','TEXT')]:
        ensure_column(cur,'anpr_events',c,d)
    for t in ['analyzed_stops','zone_events','truck_services','work_front_candidates']:
        for c,d in [('source_event_id','TEXT'),('data_layer',"TEXT DEFAULT 'calculated'"),('confirmed_by','TEXT'),('confirmed_at','TEXT'),('correction_reason','TEXT')]:
            ensure_column(cur,t,c,d)
    cur.executescript('''
    CREATE TABLE IF NOT EXISTS data_corrections (
      id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, entity_type TEXT, entity_id INTEGER,
      field_name TEXT, old_value TEXT, new_value TEXT, reason TEXT, username TEXT, changed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS gate_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, camera_id INTEGER, plate_raw TEXT,
      plate_normalized TEXT, event_time TEXT, direction TEXT, direction_source TEXT, confidence REAL,
      image_path TEXT, raw_event TEXT, source_event_id TEXT, data_layer TEXT DEFAULT 'raw', ingest_status TEXT DEFAULT 'accepted'
    );
    CREATE TABLE IF NOT EXISTS pilot_quality_daily (
      id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, machine_code TEXT, work_date TEXT,
      gps_total INTEGER DEFAULT 0, gps_valid INTEGER DEFAULT 0, gps_gaps INTEGER DEFAULT 0,
      gps_duplicate INTEGER DEFAULT 0, gps_out_of_corridor INTEGER DEFAULT 0, gps_quality_percent REAL,
      attendance_total INTEGER DEFAULT 0, attendance_mapped INTEGER DEFAULT 0, attendance_duplicate INTEGER DEFAULT 0,
      created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_gps_source_event ON gps_points(source_event_id);
    CREATE INDEX IF NOT EXISTS idx_zk_source_event ON zk_logs(source_event_id);
    CREATE INDEX IF NOT EXISTS idx_anpr_source_event ON anpr_events(source_event_id);
    ''')
    # Retention configuration for structured data / ANPR evidence.
    cur.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('structured_retention_days','180')")
    cur.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('anpr_image_retention_days','180')")
    cur.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('pilot_scope','FMB920 truck; FMB122 loader/dozer')")
    con.commit(); con.close(); return True

if __name__=='__main__':
    migrate(); print('Migration completed without destructive operations.')

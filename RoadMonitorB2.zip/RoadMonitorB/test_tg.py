# -*- coding: utf-8 -*-
"""تست کامل تلگرام از خط فرمان"""
from telegram_provider import test_connection, send_message, send_document, get_settings

print("=" * 60)
print("تست کامل تلگرام")
print("=" * 60)

s = get_settings(1)
if not s:
    print("❌ تنظیمات موجود نیست")
    exit()

print(f"\nBot Token: {'✅ تنظیم شده' if s['bot_token'] else '❌ خالی'}")
print(f"Chat ID:   {s['channel_chat_id']}")
print(f"Proxy:     {s['proxy_url'] or '(بدون پروکسی)'}")
print(f"فعال:     {'✅' if s['is_enabled'] else '❌'}")

print("\n" + "-" * 60)
print("1️⃣ تست getMe")
r = test_connection(1)
print(f"   نتیجه: {r}")

print("\n" + "-" * 60)
print("2️⃣ تست ارسال پیام متنی")
r = send_message("تست از خط فرمان", 1)
print(f"   نتیجه: {r}")
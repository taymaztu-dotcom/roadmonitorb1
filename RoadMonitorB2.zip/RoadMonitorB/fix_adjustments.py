# -*- coding: utf-8 -*-
"""نرمال‌سازی ساعت‌های اصلاح دستی"""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

def normalize(t):
    if not t:
        return t
    text = str(t).strip()
    persian = "۰۱۲۳۴۵۶۷۸۹"
    for i, d in enumerate(persian):
        text = text.replace(d, str(i))
    text = text.replace("/", ":").replace(".", ":").replace("،", ":").replace(" ", "")
    if ":" not in text:
        return t
    try:
        parts = text.split(":")
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23 and 0 <= m <= 59:
            return f"{h:02d}:{m:02d}"
    except:
        pass
    return t

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

cur.execute("SELECT id, adjusted_start, adjusted_end FROM attendance_adjustments")
rows = cur.fetchall()

print("=" * 60)
print("اصلاح ساعت‌های اصلاح دستی")
print("=" * 60)

fixed = 0
for r in rows:
    new_start = normalize(r["adjusted_start"])
    new_end = normalize(r["adjusted_end"])
    if new_start != r["adjusted_start"] or new_end != r["adjusted_end"]:
        print(f"ID {r['id']}: '{r['adjusted_start']}'→'{new_start}' | '{r['adjusted_end']}'→'{new_end}'")
        cur.execute("UPDATE attendance_adjustments SET adjusted_start=?, adjusted_end=? WHERE id=?",
                    (new_start, new_end, r["id"]))
        fixed += 1

conn.commit()
conn.close()
print(f"\n✅ {fixed} رکورد اصلاح شد")
# -*- coding: utf-8 -*-
"""
تحلیل اختصاصی هر نوع ماشین
هر تابع فقط برای نوع خاصی از ماشین کار می‌کند
"""
import sqlite3
import os
import math
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def haversine(lat1, lng1, lat2, lng2):
    R = 6371000
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
    return R * 2 * math.asin(math.sqrt(a))


def parse_time(t):
    try:
        return datetime.datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
    except:
        return None


def get_type_settings(project_id, category):
    """تنظیمات یک دسته ماشین"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM machine_type_settings WHERE project_id = ? AND machine_category = ? LIMIT 1",
                (project_id, category))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_machine_category(machine_code, project_id):
    """دسته ماشین"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT machine_category, operational_type FROM machines WHERE code = ? AND project_id = ? LIMIT 1",
                (machine_code, project_id))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_points_for_day(machine_code, date_greg, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM gps_points
        WHERE machine_code = ? AND project_id = ? AND date(recorded_at) = ?
        ORDER BY recorded_at ASC
    """, (machine_code, project_id, date_greg))
    points = [dict(r) for r in cur.fetchall()]
    conn.close()
    return points


# ═══════════ تحلیل لودر ═══════════

def analyze_loader_activity(machine_code, date_greg, project_id):
    """
    تحلیل اختصاصی لودر:
    - محل تجمع (جبهه کار احتمالی)
    - زمان توقف در جبهه (بارگیری احتمالی)
    - ارتباط با کامیون‌ها (نزدیک شدن کامیون به لودر)
    - زمان فعالیت مفید
    """
    settings = get_type_settings(project_id, "لودر")
    if not settings:
        return None

    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 5:
        return {"status": "بدون داده"}

    speed_th = settings["stop_speed_threshold"] or 3
    pairing_radius = settings["loader_pairing_radius"] or 100
    min_loading_sec = settings["loader_min_loading_seconds"] or 60

    # پیدا کردن کامیون‌های GPS دار
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT code, name FROM machines
        WHERE project_id = ? AND machine_category = 'کامیون' AND has_gps = 1
    """, (project_id,))
    trucks = [dict(r) for r in cur.fetchall()]

    # تعداد دفعاتی که کامیون نزدیک لودر بوده = بارگیری احتمالی
    loading_events = 0
    truck_close_count = {}

    for truck in trucks:
        cur.execute("""
            SELECT recorded_at, lat, lng, speed FROM gps_points
            WHERE machine_code = ? AND project_id = ? AND date(recorded_at) = ?
            ORDER BY recorded_at ASC
        """, (truck["code"], project_id, date_greg))
        truck_points = [dict(r) for r in cur.fetchall()]

        near_start = None
        for tp in truck_points:
            if not (tp["lat"] and tp["lng"]):
                continue
            # آیا این کامیون در این لحظه به لودر نزدیک است؟
            for lp in points:
                if not (lp["lat"] and lp["lng"]):
                    continue
                lp_time = parse_time(lp["recorded_at"])
                tp_time = parse_time(tp["recorded_at"])
                if not lp_time or not tp_time:
                    continue
                if abs((lp_time - tp_time).total_seconds()) < 60:
                    d = haversine(lp["lat"], lp["lng"], tp["lat"], tp["lng"])
                    if d <= pairing_radius:
                        if near_start is None:
                            near_start = tp_time
                        break
            else:
                if near_start:
                    # کامیون از لودر دور شد
                    duration = (tp_time - near_start).total_seconds() if tp_time else 0
                    if duration >= min_loading_sec:
                        loading_events += 1
                        truck_close_count[truck["name"]] = truck_close_count.get(truck["name"], 0) + 1
                    near_start = None
    conn.close()

    # آمار پایه
    moving_seconds = 0
    stopped_seconds = 0
    for i in range(1, len(points)):
        prev = points[i-1]
        cur_p = points[i]
        pt = parse_time(prev["recorded_at"])
        ct = parse_time(cur_p["recorded_at"])
        if not (pt and ct):
            continue
        diff = (ct - pt).total_seconds()
        if diff > 1800:
            continue
        if (cur_p.get("speed") or 0) > speed_th:
            moving_seconds += diff
        else:
            stopped_seconds += diff

    return {
        "status": "ok",
        "total_points": len(points),
        "moving_minutes": int(moving_seconds / 60),
        "stopped_minutes": int(stopped_seconds / 60),
        "estimated_loading_events": loading_events,
        "trucks_paired": truck_close_count,
        "first_point": points[0]["recorded_at"],
        "last_point": points[-1]["recorded_at"],
    }


# ═══════════ تحلیل بلدوزر ═══════════

def analyze_dozer_activity(machine_code, date_greg, project_id):
    """
    تحلیل اختصاصی بلدوزر:
    - محدوده کار (bounding box)
    - کیلومتراژ روزانه
    - الگوی رفت و برگشت (تخمین پاس)
    - محل پارک شبانه
    """
    settings = get_type_settings(project_id, "بلدوزر")
    if not settings:
        return None

    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 5:
        return {"status": "بدون داده"}

    speed_th = settings["stop_speed_threshold"] or 3
    max_pass_speed = settings["dozer_max_pass_speed"] or 15
    min_pass_length = settings["dozer_min_pass_length"] or 30

    # محدوده کار
    lats = [p["lat"] for p in points if p["lat"]]
    lngs = [p["lng"] for p in points if p["lng"]]
    if not lats:
        return {"status": "بدون مختصات"}

    # کیلومتراژ کل و پاس‌های احتمالی
    total_distance_m = 0
    pass_count = 0
    current_pass_length = 0
    current_direction = None

    for i in range(1, len(points)):
        prev = points[i-1]
        cur_p = points[i]
        if not (prev["lat"] and cur_p["lat"]):
            continue
        d = haversine(prev["lat"], prev["lng"], cur_p["lat"], cur_p["lng"])
        total_distance_m += d
        speed = cur_p.get("speed") or 0

        if speed_th < speed <= max_pass_speed:
            current_pass_length += d
        else:
            if current_pass_length >= min_pass_length:
                pass_count += 1
            current_pass_length = 0

    if current_pass_length >= min_pass_length:
        pass_count += 1

    # محل پارک شبانه (آخرین نقطه)
    last = points[-1]

    return {
        "status": "ok",
        "total_points": len(points),
        "total_distance_km": round(total_distance_m / 1000, 2),
        "estimated_passes": pass_count,
        "work_area_min_lat": min(lats),
        "work_area_max_lat": max(lats),
        "work_area_min_lng": min(lngs),
        "work_area_max_lng": max(lngs),
        "work_area_span_meters": round(haversine(min(lats), min(lngs), max(lats), max(lngs))),
        "night_park_lat": last["lat"] if last else None,
        "night_park_lng": last["lng"] if last else None,
        "first_point": points[0]["recorded_at"],
        "last_point": points[-1]["recorded_at"],
    }


# ═══════════ تحلیل گریدر ═══════════

def analyze_grader_activity(machine_code, date_greg, project_id):
    """گریدر مثل بلدوزر — با آستانه سرعت متفاوت"""
    return analyze_dozer_activity(machine_code, date_greg, project_id)


# ═══════════ تحلیل غلطک ═══════════

def analyze_roller_activity(machine_code, date_greg, project_id):
    """
    غلطک: تعداد پاس‌های تکراری در یک مسیر خطی
    """
    settings = get_type_settings(project_id, "غلطک")
    if not settings:
        return None

    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 5:
        return {"status": "بدون داده"}

    # محاسبه مسافت و توقف
    total_distance_m = 0
    for i in range(1, len(points)):
        if points[i-1]["lat"] and points[i]["lat"]:
            total_distance_m += haversine(
                points[i-1]["lat"], points[i-1]["lng"],
                points[i]["lat"], points[i]["lng"]
            )

    return {
        "status": "ok",
        "total_points": len(points),
        "total_distance_km": round(total_distance_m / 1000, 2),
        "note": "تعداد دقیق پاس نیازمند سنسور فشار است",
        "first_point": points[0]["recorded_at"],
        "last_point": points[-1]["recorded_at"],
    }


# ═══════════ تحلیل بیل مکانیکی ═══════════

def analyze_excavator_activity(machine_code, date_greg, project_id):
    """
    بیل مکانیکی:
    - محل استقرار
    - تعداد کامیون‌های نزدیک شده (سرویس‌گیری)
    - زمان فعالیت
    - سیکل احتمالی
    """
    settings = get_type_settings(project_id, "بیل مکانیکی")
    if not settings:
        return None

    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 5:
        return {"status": "بدون داده"}

    # مثل لودر — تعداد کامیون‌های نزدیک شده
    result = analyze_loader_activity(machine_code, date_greg, project_id)
    if result and result.get("status") == "ok":
        result["note"] = "شمارش دقیق سیکل نیاز به سنسور بازو/هیدرولیک دارد"
    return result


# ═══════════ توزیع‌کننده اصلی ═══════════

CATEGORY_ANALYZERS = {
    "کامیون": None,   # با analyze_truck_services قدیمی
    "لودر": analyze_loader_activity,
    "بلدوزر": analyze_dozer_activity,
    "گریدر": analyze_grader_activity,
    "غلطک": analyze_roller_activity,
    "بیل مکانیکی": analyze_excavator_activity,
}


def run_typed_analysis(machine_code, date_greg, project_id):
    """
    اجرای تحلیل مناسب بر اساس نوع ماشین
    """
    m = get_machine_category(machine_code, project_id)
    if not m:
        return {"status": "ماشین یافت نشد", "category": None}

    category = m.get("machine_category") or "سایر"
    analyzer = CATEGORY_ANALYZERS.get(category)

    if analyzer is None:
        # کامیون یا سایر → همان تحلیل قدیمی
        return {"status": "از تحلیل کامیون استفاده می‌شود", "category": category, "use_default": True}

    result = analyzer(machine_code, date_greg, project_id)
    if result:
        result["category"] = category
    return result


def save_typed_analysis(machine_code, date_greg, project_id, analysis_result):
    """ذخیره نتیجه تحلیل اختصاصی در گزارش روزانه"""
    if not analysis_result or analysis_result.get("status") != "ok":
        return
    # نگه‌داشتن در جدول daily_machine_summary (فیلد note)
    import json
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        UPDATE daily_machine_summary
        SET data_quality = ?
        WHERE machine_code = ? AND work_date = ? AND project_id = ?
    """, (json.dumps(analysis_result, ensure_ascii=False, default=str)[:2000],
          machine_code, date_greg, project_id))
    conn.commit()
    conn.close()
# -*- coding: utf-8 -*-
"""اضافه کردن خودکار |jalali_datetime به فیلدهای تاریخ در همه قالب‌ها"""
import os
import re
import shutil
import datetime

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
BACKUP_DIR = os.path.join(TEMPLATES_DIR, "_backup_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))

DATE_FIELDS = [
    "created_at", "updated_at", "recorded_at", "punch_time",
    "event_time", "last_seen", "adjusted_at", "reviewed_at",
    "sent_at", "read_at", "last_test_at", "last_event_at",
    "started_at", "finished_at", "server_received_at",
    "connected_at", "disconnected_at", "last_packet_at",
    "imported_at",
]

os.makedirs(BACKUP_DIR, exist_ok=True)
print(f"📁 Backup در: {BACKUP_DIR}")

total_fixes = 0

for filename in os.listdir(TEMPLATES_DIR):
    if not filename.endswith(".html"):
        continue
    filepath = os.path.join(TEMPLATES_DIR, filename)

    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    original = content
    file_fixes = [0]

    for field in DATE_FIELDS:
        # الگو: {{ variable.field }} یا {{ variable.field or 'x' }}
        # فقط اگر فیلتر jalali ندارد
        def repl(m):
            full = m.group(0)
            if "|jalali" in full or "|shamsi" in full:
                return full
            file_fixes[0] += 1
            # جدا کردن قسمت‌های داخل
            inner = m.group(1)
            # اگر or داخلش هست
            if " or " in inner:
                parts = inner.split(" or ", 1)
                return "{{ (" + parts[0].strip() + ")|jalali_datetime or " + parts[1].strip() + " }}"
            else:
                return "{{ " + inner.strip() + "|jalali_datetime }}"

        pattern = r"\{\{\s*(\w+\.?" + field + r"(?:\s+or\s+[^}]+)?)\s*\}\}"
        content = re.sub(pattern, repl, content)

    if content != original:
        # backup
        shutil.copy2(filepath, os.path.join(BACKUP_DIR, filename))
        # ذخیره جدید
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"✏️ {filename}: {file_fixes[0]} تغییر")
        total_fixes += file_fixes[0]

print("\n" + "=" * 60)
print(f"✅ کل {total_fixes} فیلد اصلاح شد")
print(f"📁 نسخه پشتیبان در: {BACKUP_DIR}")
print("اگر مشکلی بود، فایل‌های backup را برگردانید")
print("=" * 60)
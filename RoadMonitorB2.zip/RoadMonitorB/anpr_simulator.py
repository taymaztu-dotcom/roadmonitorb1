# -*- coding: utf-8 -*-
"""شبیه‌ساز پلاک‌خوان — یک رویداد فرضی به Webhook می‌فرستد"""
import requests
import json
import sys
import random
import datetime

WEBHOOK_URL = "http://127.0.0.1:5050/api/anpr/webhook"

TEST_PLATES = [
    "12ب34567",
    "45ج89123",
    "78د45678",
    "22الف11223",
    "99ن88776",
]


def simulate():
    plate = sys.argv[1] if len(sys.argv) > 1 else random.choice(TEST_PLATES)
    camera_code = sys.argv[2] if len(sys.argv) > 2 else "CAM-01"

    data = {
        "plate": plate,
        "camera_code": camera_code,
        "event_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "confidence": random.randint(75, 99),
        # direction اختیاری — سیستم خودکار تشخیص می‌دهد
    }

    print(f"🚀 شبیه‌ساز پلاک‌خوان")
    print(f"📸 پلاک: {plate}")
    print(f"📷 دوربین: {camera_code}")
    print(f"🎯 URL: {WEBHOOK_URL}")
    print("-" * 50)

    try:
        r = requests.post(WEBHOOK_URL, json=data, timeout=10)
        print(f"HTTP {r.status_code}")
        try:
            result = r.json()
            print("✅ پاسخ سرور:")
            print(json.dumps(result, indent=2, ensure_ascii=False))
        except:
            print(r.text[:500])
    except requests.exceptions.ConnectionError:
        print("❌ سرور در دسترس نیست. اول `python main.py` را اجرا کنید")
    except Exception as e:
        print(f"❌ خطا: {e}")


if __name__ == "__main__":
    simulate()
# -*- coding: utf-8 -*-
"""Blueprint برای مدیریت نقش‌ها، مجوزها، گیرندگان — فاز E"""
import sqlite3
from werkzeug.security import check_password_hash, generate_password_hash
import datetime
import os
import functools
from flask import Blueprint, render_template, request, redirect, session, jsonify
from permissions import PERMISSIONS, get_all_permission_keys, get_permission_label

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

phase_e_bp = Blueprint("phase_e", __name__)


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _admin_only(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect("/login")
        if session.get("role") != "مدیر" and session.get("username") != "admin":
            return redirect("/")
        return view_func(*args, **kwargs)
    return wrapper


def _login_only(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect("/login")
        return view_func(*args, **kwargs)
    return wrapper


def _pid():
    return session.get("project_id") or 1


def _log(entity_type, entity_id, action, old_value="", new_value=""):
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO audit_log (project_id, entity_type, entity_id, action,
                old_value, new_value, user_username, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (_pid(), entity_type, entity_id, action,
              str(old_value)[:500], str(new_value)[:500],
              session.get("username", ""),
              request.remote_addr if request else "",
              datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[audit] {e}")


# ═══════════ نقش‌ها ═══════════

@phase_e_bp.route("/roles")
@_admin_only
def roles_list():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT r.*, (SELECT COUNT(*) FROM users WHERE role_id = r.id) AS users_count,
               (SELECT COUNT(*) FROM role_permissions WHERE role_id = r.id) AS perms_count
        FROM roles r WHERE project_id = ? ORDER BY display_order, id
    """, (_pid(),))
    roles = [dict(r) for r in cur.fetchall()]
    conn.close()
    return render_template("roles.html", roles=roles)


@phase_e_bp.route("/roles/add", methods=["POST"])
@_admin_only
def add_role():
    name = request.form.get("role_name", "").strip()
    desc = request.form.get("description", "").strip()
    if not name:
        return redirect("/roles")
    conn = get_db()
    cur = conn.cursor()
    # حداکثر ۱۰ نقش
    cur.execute("SELECT COUNT(*) FROM roles WHERE project_id = ?", (_pid(),))
    if cur.fetchone()[0] >= 10:
        conn.close()
        return redirect("/roles?error=max")
    try:
        cur.execute("""
            INSERT INTO roles (project_id, role_name, description, is_system, display_order, created_at)
            VALUES (?, ?, ?, 0, 99, ?)
        """, (_pid(), name, desc, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        rid = cur.lastrowid
        _log("role", rid, "افزودن نقش", new_value=name)
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return redirect("/roles")


@phase_e_bp.route("/roles/edit/<int:rid>", methods=["POST"])
@_admin_only
def edit_role(rid):
    name = request.form.get("role_name", "").strip()
    desc = request.form.get("description", "").strip()
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE roles SET role_name=?, description=? WHERE id=? AND project_id=?",
                (name, desc, rid, _pid()))
    conn.commit()
    conn.close()
    _log("role", rid, "ویرایش نقش", new_value=name)
    return redirect("/roles")


@phase_e_bp.route("/roles/delete/<int:rid>")
@_admin_only
def delete_role(rid):
    conn = get_db()
    cur = conn.cursor()
    # نقش‌های سیستمی حذف نشوند
    cur.execute("SELECT is_system, role_name FROM roles WHERE id=? AND project_id=?", (rid, _pid()))
    r = cur.fetchone()
    if not r or r["is_system"]:
        conn.close()
        return redirect("/roles")
    # جدا کردن کاربران از این نقش
    cur.execute("UPDATE users SET role_id = NULL WHERE role_id = ?", (rid,))
    cur.execute("DELETE FROM role_permissions WHERE role_id = ?", (rid,))
    cur.execute("DELETE FROM roles WHERE id = ? AND project_id = ?", (rid, _pid()))
    conn.commit()
    conn.close()
    _log("role", rid, "حذف نقش", old_value=r["role_name"])
    return redirect("/roles")


@phase_e_bp.route("/roles/<int:rid>/permissions", methods=["GET", "POST"])
@_admin_only
def role_permissions(rid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM roles WHERE id=? AND project_id=?", (rid, _pid()))
    role = cur.fetchone()
    if not role:
        conn.close()
        return redirect("/roles")

    if request.method == "POST":
        selected = set(request.form.getlist("perms"))
        # حذف قبلی
        cur.execute("DELETE FROM role_permissions WHERE role_id = ?", (rid,))
        # درج جدید
        for p in selected:
            if p in get_all_permission_keys():
                cur.execute("INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)", (rid, p))
        conn.commit()
        _log("role", rid, "به‌روزرسانی مجوزها", new_value=f"{len(selected)} مجوز")
        conn.close()
        return redirect(f"/roles/{rid}/permissions?saved=1")

    cur.execute("SELECT permission_key FROM role_permissions WHERE role_id = ?", (rid,))
    current = {r["permission_key"] for r in cur.fetchall()}
    conn.close()
    return render_template("role_permissions.html", role=dict(role),
                           permissions=PERMISSIONS, current=current)


# ═══════════ کاربران ═══════════

@phase_e_bp.route("/users_advanced")
@_admin_only
def users_advanced():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT u.*, r.role_name FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        ORDER BY u.id DESC
    """)
    users = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT id, role_name FROM roles WHERE project_id = ? ORDER BY display_order", (_pid(),))
    roles = [dict(r) for r in cur.fetchall()]
    conn.close()
    return render_template("users_advanced.html", users=users, roles=roles)


@phase_e_bp.route("/users/edit/<int:uid>", methods=["GET", "POST"])
@_admin_only
def edit_user_advanced(uid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (uid,))
    user = cur.fetchone()
    if not user:
        conn.close()
        return redirect("/users_advanced")

    if request.method == "POST":
        role_id = request.form.get("role_id") or None
        if role_id:
            role_id = int(role_id)
        channels_list = request.form.getlist("alert_channels")
        channels = ",".join(channels_list) if channels_list else "panel"

        cur.execute("""
            UPDATE users SET
                full_name = ?, phone = ?, role_id = ?,
                can_login = ?, is_recipient = ?,
                telegram_chat_id = ?,
                receive_urgent_alert = ?, receive_daily_summary = ?,
                receive_weekly_summary = ?, receive_monthly_summary = ?,
                alert_channels = ?, is_active = ?
            WHERE id = ?
        """, (
            request.form.get("full_name", "").strip(),
            request.form.get("phone", "").strip(),
            role_id,
            1 if request.form.get("can_login") == "1" else 0,
            1 if request.form.get("is_recipient") == "1" else 0,
            request.form.get("telegram_chat_id", "").strip(),
            1 if request.form.get("receive_urgent_alert") == "1" else 0,
            1 if request.form.get("receive_daily_summary") == "1" else 0,
            1 if request.form.get("receive_weekly_summary") == "1" else 0,
            1 if request.form.get("receive_monthly_summary") == "1" else 0,
            channels,
            1 if request.form.get("is_active") == "1" else 0,
            uid
        ))
        # تغییر رمز اختیاری
        new_pass = request.form.get("new_password", "").strip()
        if new_pass and len(new_pass) >= 4:
            cur.execute("UPDATE users SET password = ? WHERE id = ?", (generate_password_hash(new_pass), uid))
        conn.commit()
        conn.close()
        _log("user", uid, "ویرایش پیشرفته", new_value=request.form.get("full_name", ""))
        return redirect("/users_advanced")

    cur.execute("SELECT id, role_name FROM roles WHERE project_id = ? ORDER BY display_order", (_pid(),))
    roles = [dict(r) for r in cur.fetchall()]
    conn.close()
    return render_template("edit_user_advanced.html", user=dict(user), roles=roles)


@phase_e_bp.route("/users/add_advanced", methods=["GET", "POST"])
@_admin_only
def add_user_advanced():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        full_name = request.form.get("full_name", "").strip()
        can_login = 1 if request.form.get("can_login") == "1" else 0
        is_recipient = 1 if request.form.get("is_recipient") == "1" else 0

        if not full_name:
            error = "نام کامل الزامی است"
        elif can_login and (not username or not password):
            error = "برای کاربر پنل، نام کاربری و رمز الزامی است"
        elif can_login and len(password) < 4:
            error = "رمز باید حداقل ۴ کاراکتر باشد"
        elif not can_login and not is_recipient:
            error = "کاربر باید حداقل یکی از دو حالت را داشته باشد"
        else:
            role_id = request.form.get("role_id") or None
            if role_id:
                role_id = int(role_id)
            channels_list = request.form.getlist("alert_channels")
            channels = ",".join(channels_list) if channels_list else "panel"
            conn = get_db()
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT INTO users (username, password, full_name, role, phone, role_id,
                        can_login, is_recipient, telegram_chat_id,
                        receive_urgent_alert, receive_daily_summary,
                        receive_weekly_summary, receive_monthly_summary,
                        alert_channels, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """, (
                    username or f"recipient_{datetime.datetime.now().microsecond}",
                    generate_password_hash(password) if password else "-",
                    full_name,
                    "کاربر",
                    request.form.get("phone", "").strip(),
                    role_id, can_login, is_recipient,
                    request.form.get("telegram_chat_id", "").strip(),
                    1 if request.form.get("receive_urgent_alert") == "1" else 0,
                    1 if request.form.get("receive_daily_summary") == "1" else 0,
                    1 if request.form.get("receive_weekly_summary") == "1" else 0,
                    1 if request.form.get("receive_monthly_summary") == "1" else 0,
                    channels,
                ))
                uid = cur.lastrowid
                conn.commit()
                conn.close()
                _log("user", uid, "افزودن کاربر پیشرفته", new_value=full_name)
                return redirect("/users_advanced")
            except sqlite3.IntegrityError:
                error = "این نام کاربری قبلاً ثبت شده است"
                conn.close()

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, role_name FROM roles WHERE project_id = ? ORDER BY display_order", (_pid(),))
    roles = [dict(r) for r in cur.fetchall()]
    conn.close()
    return render_template("add_user_advanced.html", roles=roles, error=error)


@phase_e_bp.route("/users/delete/<int:uid>")
@_admin_only
def delete_user_advanced(uid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT full_name, username FROM users WHERE id = ?", (uid,))
    u = cur.fetchone()
    if u and u["username"] != "admin":
        cur.execute("DELETE FROM users WHERE id = ?", (uid,))
        conn.commit()
        _log("user", uid, "حذف کاربر", old_value=u["full_name"])
    conn.close()
    return redirect("/users_advanced")


# ═══════════ گیرندگان گزارش ═══════════

@phase_e_bp.route("/recipients")
@_login_only
def recipients_list():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT u.*, r.role_name FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE u.is_recipient = 1
        ORDER BY u.receive_urgent_alert DESC, u.full_name
    """)
    recipients = [dict(r) for r in cur.fetchall()]
    conn.close()
    return render_template("recipients.html", recipients=recipients)


# ═══════════ پروفایل شخصی ═══════════

@phase_e_bp.route("/my_profile", methods=["GET", "POST"])
@_login_only
def my_profile():
    uid = session.get("user_id")
    conn = get_db()
    cur = conn.cursor()
    message = None
    error = None

    if request.method == "POST":
        cur.execute("SELECT password FROM users WHERE id = ?", (uid,))
        cur_pass = cur.fetchone()["password"]
        old = request.form.get("old_password", "").strip()
        new = request.form.get("new_password", "").strip()
        confirm = request.form.get("confirm_password", "").strip()
        phone = request.form.get("phone", "").strip()
        tg_id = request.form.get("telegram_chat_id", "").strip()

        if old and not ((str(cur_pass).startswith(("pbkdf2:", "scrypt:", "argon2:")) and check_password_hash(cur_pass, old)) or cur_pass == old):
            error = "رمز فعلی اشتباه است"
        elif new and new != confirm:
            error = "رمز جدید و تکرار یکسان نیست"
        elif new and len(new) < 4:
            error = "رمز حداقل ۴ کاراکتر"
        else:
            if new:
                cur.execute("UPDATE users SET password = ? WHERE id = ?", (generate_password_hash(new), uid))
            cur.execute("UPDATE users SET phone = ?, telegram_chat_id = ? WHERE id = ?",
                        (phone, tg_id, uid))
            conn.commit()
            message = "ذخیره شد"

    cur.execute("""
        SELECT u.*, r.role_name FROM users u
        LEFT JOIN roles r ON u.role_id = r.id WHERE u.id = ?
    """, (uid,))
    user = dict(cur.fetchone())
    # مجوزهای کاربر
    from permissions import get_user_permissions
    perms = get_user_permissions(uid, get_db)
    conn.close()
    return render_template("my_profile.html", user=user, permissions=PERMISSIONS,
                           my_perms=perms, message=message, error=error)


def register_phase_e(app):
    """این تابع را در main.py صدا بزنید"""
    app.register_blueprint(phase_e_bp)
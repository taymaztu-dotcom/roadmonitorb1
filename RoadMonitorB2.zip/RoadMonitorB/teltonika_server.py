# -*- coding: utf-8 -*-
"""
سرور TCP دریافت داده از ردیاب‌های Teltonika
اجرا: python teltonika_server.py
"""
import socket
import threading
import sqlite3
import os
import datetime
from teltonika_parser import parse_imei, parse_avl_data, build_response, build_imei_ack

DB_PATH = os.environ.get("ROADMONITOR_DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db"))
HOST = "0.0.0.0"
PORT = 5027


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def log(msg):
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")


def find_machine_by_imei(imei):
    """پیدا کردن ماشین از روی IMEI"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, code, name, project_id FROM machines WHERE imei = ? LIMIT 1", (imei,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def save_point(machine, record, imei, raw_hex=""):
    """ذخیره یک نقطه GPS در دیتابیس"""
    conn = get_db()
    cur = conn.cursor()

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if machine:
        pid = machine["project_id"]
        code = machine["code"]
    else:
        pid = 1  # پروژه پیش‌فرض
        code = f"UNKNOWN_{imei}"

    source_event_id = f"teltonika:{imei}:{record.get('timestamp_str','')}"
    dup = cur.execute("SELECT id FROM gps_points WHERE source_event_id = ? LIMIT 1", (source_event_id,)).fetchone()
    if dup:
        conn.close(); return
    cur.execute("""
        INSERT INTO gps_points (
            project_id, machine_code, imei, lat, lng, speed, altitude, angle,
            satellites, ignition, movement, gsm_signal, external_voltage,
            battery_voltage, odometer, priority, raw_data, recorded_at, server_received_at,
            source_event_id, data_layer, ingest_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        pid, code, imei,
        record["lat"], record["lng"], record["speed"],
        record["altitude"], record["angle"], record["satellites"],
        record.get("ignition", 0), record.get("movement", 0), record.get("gsm_signal", 0),
        record.get("external_voltage", 0), record.get("battery_voltage", 0),
        record.get("odometer", 0), record.get("priority", 0),
        raw_hex[:200], record["timestamp_str"], now, source_event_id, "raw", "accepted"
    ))

    # به‌روزرسانی آخرین موقعیت ماشین
    if machine:
        cur.execute("UPDATE machines SET lat = ?, lng = ? WHERE id = ?",
                    (record["lat"], record["lng"], machine["id"]))

    conn.commit()
    conn.close()


def log_connection(imei, ip, packets, event="connect"):
    conn = get_db()
    cur = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if event == "connect":
        cur.execute("""
            INSERT INTO tracker_connections (imei, ip_address, connected_at, packets_received, status)
            VALUES (?, ?, ?, ?, 'connected')
        """, (imei, ip, now, 0))
    elif event == "update":
        cur.execute("""
            UPDATE tracker_connections
            SET packets_received = packets_received + ?, last_packet_at = ?
            WHERE imei = ? AND status = 'connected'
        """, (packets, now, imei))
    elif event == "disconnect":
        cur.execute("""
            UPDATE tracker_connections SET disconnected_at = ?, status = 'disconnected'
            WHERE imei = ? AND status = 'connected'
        """, (now, imei))
    conn.commit()
    conn.close()


def handle_client(sock, addr):
    ip = addr[0]
    imei = None
    machine = None
    total_packets = 0
    try:
        log(f"🔌 اتصال جدید از {ip}:{addr[1]}")
        sock.settimeout(120)

        # ── مرحله ۱: دریافت IMEI ──
        imei_data = sock.recv(1024)
        if not imei_data:
            log(f"❌ ارتباط بدون داده از {ip}")
            return

        imei = parse_imei(imei_data)
        if not imei or len(imei) < 10:
            log(f"❌ IMEI نامعتبر از {ip}")
            sock.sendall(build_imei_ack(False))
            return

        log(f"📱 IMEI دریافت شد: {imei}")

        machine = find_machine_by_imei(imei)
        if machine:
            log(f"✅ ماشین شناسایی شد: {machine['name']} ({machine['code']})")
        else:
            log(f"⚠️  IMEI ناشناخته — داده با کد UNKNOWN ذخیره می‌شود")

        sock.sendall(build_imei_ack(True))
        log_connection(imei, ip, 0, "connect")

        # ── مرحله ۲: دریافت داده AVL ──
        while True:
            header = sock.recv(8)
            if not header or len(header) < 8:
                break

            data_length = int.from_bytes(header[4:8], "big")
            payload = b""
            while len(payload) < data_length + 4:  # + CRC
                chunk = sock.recv(4096)
                if not chunk:
                    break
                payload += chunk

            if not payload:
                break

            full_packet = header + payload
            parsed = parse_avl_data(full_packet)

            if parsed["count"] > 0:
                log(f"📦 {parsed['count']} رکورد از {imei} (Codec {hex(parsed['codec_id'])})")
                for rec in parsed["records"]:
                    try:
                        save_point(machine, rec, imei, full_packet.hex()[:200])
                    except Exception as e:
                        log(f"⚠️ خطای ذخیره: {e}")

                total_packets += parsed["count"]
                log_connection(imei, ip, parsed["count"], "update")

                # تأیید به ردیاب
                sock.sendall(build_response(parsed["count"]))
            else:
                sock.sendall(build_response(0))

    except socket.timeout:
        log(f"⏱️ Timeout برای {imei or ip}")
    except ConnectionResetError:
        log(f"🔌 اتصال قطع شد: {imei or ip}")
    except Exception as e:
        log(f"❌ خطا در {imei or ip}: {e}")
    finally:
        if imei:
            log_connection(imei, ip, 0, "disconnect")
            log(f"👋 قطع ارتباط با {imei} — مجموع {total_packets} رکورد")
        try:
            sock.close()
        except:
            pass


def start_server():
    print("=" * 60)
    print("🚀 Teltonika TCP Server")
    print("=" * 60)
    print(f"📡 گوش دادن روی {HOST}:{PORT}")
    print(f"💾 دیتابیس: {DB_PATH}")
    print("⏸  برای توقف Ctrl+C بزنید")
    print("=" * 60)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(50)

    try:
        while True:
            client_sock, addr = server.accept()
            t = threading.Thread(target=handle_client, args=(client_sock, addr), daemon=True)
            t.start()
    except KeyboardInterrupt:
        print("\n🛑 خاموش شدن سرور...")
    finally:
        server.close()
        print("✅ سرور بسته شد")


if __name__ == "__main__":
    start_server()
# -*- coding: utf-8 -*-
"""Migration v11 — فاز H: پلاک‌خوان دوربین"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col}")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("=" * 60)
    print("Migration v11 — فاز H: پلاک‌خوان دوربین")
    print("=" * 60)

    # ── جدول دوربین‌ها ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS anpr_cameras (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            camera_name TEXT NOT NULL,
            camera_code TEXT,
            location TEXT,
            camera_type TEXT DEFAULT 'ANPR',
            direction TEXT DEFAULT 'دو طرفه',
            api_url TEXT,
            webhook_secret TEXT,
            zone_id INTEGER,
            is_active INTEGER DEFAULT 1,
            last_event_at TEXT,
            events_count INTEGER DEFAULT 0,
            note TEXT,
            created_at TEXT
        )
    """)
    print("\n📌 anpr_cameras")

    # ── جدول رویدادها ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS anpr_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            camera_id INTEGER,
            camera_name TEXT,
            plate_raw TEXT NOT NULL,
            plate_normalized TEXT,
            event_time TEXT NOT NULL,
            direction TEXT,
            direction_source TEXT,
            confidence REAL,
            image_url TEXT,
            image_path TEXT,
            image_base64 TEXT,
            machine_id INTEGER,
            machine_code TEXT,
            is_known INTEGER DEFAULT 0,
            trust_level TEXT DEFAULT 'بالا',
            raw_data TEXT,
            received_at TEXT,
            reviewed INTEGER DEFAULT 0,
            reviewed_by TEXT,
            reviewed_at TEXT,
            note TEXT
        )
    """)
    print("📌 anpr_events")

    # ── جدول Whitelist پلاک‌ها ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS plate_whitelist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            plate_normalized TEXT NOT NULL,
            plate_display TEXT,
            machine_id INTEGER,
            owner_name TEXT,
            is_active INTEGER DEFAULT 1,
            note TEXT,
            created_at TEXT,
            UNIQUE(project_id, plate_normalized)
        )
    """)
    print("📌 plate_whitelist")

    # ── تنظیمات پلاک‌خوان ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS anpr_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER UNIQUE,
            direction_mode TEXT DEFAULT 'auto_sequence',
            store_images INTEGER DEFAULT 1,
            image_retention_days INTEGER DEFAULT 60,
            unknown_plate_alert INTEGER DEFAULT 1,
            min_confidence REAL DEFAULT 70,
            webhook_secret_global TEXT,
            updated_at TEXT
        )
    """)
    print("📌 anpr_settings")

    # اضافه به machines
    print("\n📌 machines:")
    add_col(cur, "machines", "plate_normalized", "TEXT")

    # پوشه تصاویر
    img_dir = os.path.join(os.path.dirname(DB_PATH), "static", "anpr_images")
    os.makedirs(img_dir, exist_ok=True)
    print(f"\n📁 پوشه تصاویر: {img_dir}")

    # درج تنظیمات پیش‌فرض
    cur.execute("SELECT COUNT(*) FROM anpr_settings WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        cur.execute("""
            INSERT INTO anpr_settings (project_id, updated_at) VALUES (1, datetime('now'))
        """)
        print("  [+] تنظیمات پیش‌فرض")

    conn.commit()
    conn.close()
    print("\n" + "=" * 60)
    print("✅ Migration v11 با موفقیت انجام شد!")
    print("=" * 60)


if __name__ == "__main__":
    migrate()
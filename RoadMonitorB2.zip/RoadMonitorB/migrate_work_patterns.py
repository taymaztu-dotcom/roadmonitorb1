# -*- coding: utf-8 -*-
"""
مرحله ۱: ساخت جداول الگوی کاری، تعطیلات، تقویم و مرخصی
فایل: H:\RoadMonitorB\migrate_work_patterns.py
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def migrate():
    conn = get_connection()
    cur = conn.cursor()

    print("=" * 60)
    print("ساخت جداول جدید سیستم الگوی کاری")
    print("=" * 60)
    print("")

    # ───────────────────────────────────────────
    # جدول ۱: الگوهای کاری
    # ───────────────────────────────────────────
    cur.execute("""
        CREATE TABLE IF NOT EXISTS work_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            pattern_name TEXT NOT NULL,
            pattern_type TEXT DEFAULT 'عادی',
            work_start TEXT DEFAULT '07:30',
            work_end TEXT DEFAULT '17:30',
            lunch_start TEXT DEFAULT '13:00',
            lunch_end TEXT DEFAULT '14:00',
            lunch_duration_minutes INTEGER DEFAULT 60,
            daily_work_minutes INTEGER DEFAULT 480,
            overtime_after_minutes INTEGER DEFAULT 480,
            late_tolerance_minutes INTEGER DEFAULT 10,
            early_tolerance_minutes INTEGER DEFAULT 10,
            attendance_range_start TEXT DEFAULT '06:00',
            attendance_range_end TEXT DEFAULT '22:00',
            single_punch_behavior TEXT DEFAULT 'ناقص',
            rotation_weeks INTEGER DEFAULT 1,
            rotation_start_date TEXT,
            is_default INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1
        )
    """)
    print("  [+] جدول work_patterns ساخته شد")

    # ───────────────────────────────────────────
    # جدول ۲: روزهای هفته هر الگو
    # ───────────────────────────────────────────
    cur.execute("""
        CREATE TABLE IF NOT EXISTS work_pattern_days (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_id INTEGER NOT NULL,
            week_number INTEGER DEFAULT 1,
            day_of_week INTEGER NOT NULL,
            day_type TEXT DEFAULT 'کاری',
            custom_work_start TEXT,
            custom_work_end TEXT,
            custom_work_minutes INTEGER,
            FOREIGN KEY (pattern_id) REFERENCES work_patterns(id)
        )
    """)
    print("  [+] جدول work_pattern_days ساخته شد")

    # ───────────────────────────────────────────
    # جدول ۳: تعطیلات رسمی
    # ───────────────────────────────────────────
    cur.execute("""
        CREATE TABLE IF NOT EXISTS holidays (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            holiday_date TEXT NOT NULL,
            holiday_name TEXT,
            source TEXT DEFAULT 'دستی',
            year INTEGER
        )
    """)
    print("  [+] جدول holidays ساخته شد")

    # ───────────────────────────────────────────
    # جدول ۴: تغییرات دستی تقویم پروژه
    # ───────────────────────────────────────────
    cur.execute("""
        CREATE TABLE IF NOT EXISTS calendar_overrides (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            override_date TEXT NOT NULL,
            original_type TEXT,
            new_type TEXT NOT NULL,
            reason TEXT,
            created_by TEXT,
            created_at TEXT
        )
    """)
    print("  [+] جدول calendar_overrides ساخته شد")

    # ───────────────────────────────────────────
    # جدول ۵: مرخصی و مأموریت
    # ───────────────────────────────────────────
    cur.execute("""
        CREATE TABLE IF NOT EXISTS leaves (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            personnel_id INTEGER NOT NULL,
            leave_type TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            start_time TEXT,
            end_time TEXT,
            is_hourly INTEGER DEFAULT 0,
            duration_days REAL DEFAULT 1,
            duration_minutes INTEGER,
            reason TEXT,
            status TEXT DEFAULT 'تایید شده',
            created_by TEXT,
            created_at TEXT,
            FOREIGN KEY (personnel_id) REFERENCES personnel(id)
        )
    """)
    print("  [+] جدول leaves ساخته شد")

    # ───────────────────────────────────────────
    # درج الگوی پیش‌فرض پایلوت
    # ───────────────────────────────────────────
    cur.execute("SELECT COUNT(*) as c FROM work_patterns WHERE project_id = 1")
    count = cur.fetchone()["c"]

    if count == 0:
        print("")
        print("  ساخت الگوی پیش‌فرض پایلوت...")

        cur.execute("""
            INSERT INTO work_patterns (
                project_id, pattern_name, pattern_type,
                work_start, work_end,
                lunch_start, lunch_end, lunch_duration_minutes,
                daily_work_minutes, overtime_after_minutes,
                late_tolerance_minutes, early_tolerance_minutes,
                attendance_range_start, attendance_range_end,
                single_punch_behavior,
                rotation_weeks, rotation_start_date,
                is_default, is_active
            ) VALUES (
                1, 'الگوی راهسازی کوهستانی — دو هفته‌ای', 'عادی',
                '07:30', '17:30',
                '13:00', '14:00', 60,
                480, 480,
                10, 10,
                '06:00', '22:00',
                'ناقص',
                2, '1405/05/24',
                1, 1
            )
        """)

        pattern_id = cur.lastrowid

        # هفته ۱: همه ۷ روز کاری (حتی جمعه)
        day_names = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه']
        for day in range(7):
            cur.execute("""
                INSERT INTO work_pattern_days (
                    pattern_id, week_number, day_of_week, day_type
                ) VALUES (?, 1, ?, 'کاری')
            """, (pattern_id, day))
        print("    هفته ۱: همه روزها کاری (شنبه تا جمعه)")

        # هفته ۲: شنبه تا چهارشنبه کاری، پنجشنبه و جمعه تعطیل
        for day in range(5):
            cur.execute("""
                INSERT INTO work_pattern_days (
                    pattern_id, week_number, day_of_week, day_type
                ) VALUES (?, 2, ?, 'کاری')
            """, (pattern_id, day))

        for day in [5, 6]:
            cur.execute("""
                INSERT INTO work_pattern_days (
                    pattern_id, week_number, day_of_week, day_type
                ) VALUES (?, 2, ?, 'تعطیل')
            """, (pattern_id, day))
        print("    هفته ۲: شنبه تا چهارشنبه کاری | پنجشنبه و جمعه تعطیل")

    else:
        print("")
        print("  الگوی پیش‌فرض قبلاً وجود دارد. رد شد.")

    # ───────────────────────────────────────────
    # درج تعطیلات رسمی پایه ۱۴۰۵
    # ───────────────────────────────────────────
    cur.execute("SELECT COUNT(*) as c FROM holidays WHERE year = 1405")
    h_count = cur.fetchone()["c"]

    if h_count == 0:
        print("")
        print("  درج تعطیلات رسمی سال ۱۴۰۵...")

        holidays_1405 = [
            ("1405/01/01", "عید نوروز"),
            ("1405/01/02", "عید نوروز"),
            ("1405/01/03", "عید نوروز"),
            ("1405/01/04", "عید نوروز"),
            ("1405/01/12", "روز جمهوری اسلامی"),
            ("1405/01/13", "سیزده بدر"),
            ("1405/03/14", "رحلت امام خمینی"),
            ("1405/03/15", "قیام ۱۵ خرداد"),
            ("1405/11/22", "پیروزی انقلاب اسلامی"),
            ("1405/12/29", "روز ملی شدن صنعت نفت"),
        ]

        for h_date, h_name in holidays_1405:
            cur.execute("""
                INSERT INTO holidays (holiday_date, holiday_name, source, year)
                VALUES (?, ?, 'رسمی', 1405)
            """, (h_date, h_name))

        print("    {} تعطیل رسمی ثبت شد".format(len(holidays_1405)))
        print("    توجه: تعطیلات مذهبی (قمری) بعداً باید دستی اضافه شوند")

    else:
        print("  تعطیلات ۱۴۰۵ قبلاً وجود دارد. رد شد.")

    conn.commit()
    conn.close()

    print("")
    print("=" * 60)
    print("✅ همه جداول با موفقیت ساخته شدند!")
    print("")
    print("جداول جدید:")
    print("  • work_patterns      الگوهای کاری")
    print("  • work_pattern_days  روزهای هفته هر الگو")
    print("  • holidays           تعطیلات رسمی")
    print("  • calendar_overrides تغییرات دستی تقویم")
    print("  • leaves             مرخصی و مأموریت")
    print("=" * 60)
    print("")
    print("قدم بعد: اجرای python main.py و رفتن به صفحات جدید")


if __name__ == "__main__":
    migrate()
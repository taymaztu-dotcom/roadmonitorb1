# -*- coding: utf-8 -*-
"""
شبیه‌ساز ردیاب Teltonika
یک بسته IMEI + چند نقطه GPS ارسال می‌کند
اجرا: python teltonika_simulator.py [IMEI]
"""
import socket
import struct
import time
import sys
import random
from datetime import datetime

HOST = "127.0.0.1"
PORT = 5027

# IMEI پیش‌فرض — می‌توانید در آرگومان بدهید
DEFAULT_IMEI = "353976010937197"


def build_imei_packet(imei):
    """ساخت بسته IMEI"""
    imei_bytes = imei.encode("ascii")
    length = struct.pack("!H", len(imei_bytes))
    return length + imei_bytes


def build_avl_packet(records):
    """ساخت بسته AVL Data Codec 8"""
    body = b""
    body += bytes([0x08])  # Codec ID
    body += bytes([len(records)])  # تعداد رکورد

    for r in records:
        # Timestamp (ms)
        ts_ms = int(r["timestamp"].timestamp() * 1000)
        body += struct.pack("!Q", ts_ms)
        # Priority
        body += bytes([r.get("priority", 1)])
        # Longitude
        body += struct.pack("!i", int(r["lng"] * 10000000))
        # Latitude
        body += struct.pack("!i", int(r["lat"] * 10000000))
        # Altitude
        body += struct.pack("!h", r.get("altitude", 0))
        # Angle
        body += struct.pack("!H", r.get("angle", 0))
        # Satellites
        body += bytes([r.get("satellites", 8)])
        # Speed
        body += struct.pack("!H", r.get("speed", 0))
        # Event IO ID
        body += bytes([0])
        # Total IO count
        io_count = 3
        body += bytes([io_count])
        # N1: 1-byte
        body += bytes([2])  # 2 items
        body += bytes([239, r.get("ignition", 1)])  # IO 239 = Ignition
        body += bytes([240, r.get("movement", 1)])  # IO 240 = Movement
        # N2: 2-byte
        body += bytes([1])
        body += bytes([21]) + struct.pack("!H", r.get("gsm_signal", 4))  # GSM
        # N4: 4-byte
        body += bytes([0])
        # N8: 8-byte
        body += bytes([0])

    # تعداد رکورد در انتها
    body += bytes([len(records)])

    # ساخت هدر
    preamble = b"\x00\x00\x00\x00"
    data_length = struct.pack("!I", len(body))
    # CRC ساده (Teltonika در بسیاری موارد CRC چک نمی‌کند)
    crc = b"\x00\x00\x00\x00"

    return preamble + data_length + body + crc


def simulate():
    imei = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_IMEI

    print(f"🚀 شبیه‌ساز Teltonika")
    print(f"📱 IMEI: {imei}")
    print(f"🎯 هدف: {HOST}:{PORT}")
    print("-" * 50)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(30)
    sock.connect((HOST, PORT))
    print("✅ اتصال برقرار شد")

    # ارسال IMEI
    sock.sendall(build_imei_packet(imei))
    ack = sock.recv(1)
    if ack == b"\x01":
        print("✅ IMEI پذیرفته شد")
    else:
        print("❌ IMEI رد شد")
        sock.close()
        return

    # ارسال ۵ نقطه پیرامون مختصات کارگاه پایلوت
    base_lat = 36.5
    base_lng = 49.5

    for i in range(5):
        # کمی جابجایی برای شبیه‌سازی حرکت
        lat = base_lat + random.uniform(-0.005, 0.005)
        lng = base_lng + random.uniform(-0.005, 0.005)
        speed = random.randint(0, 60)

        record = {
            "timestamp": datetime.now(),
            "lat": lat,
            "lng": lng,
            "speed": speed,
            "altitude": random.randint(1000, 1500),
            "angle": random.randint(0, 359),
            "satellites": random.randint(7, 12),
            "ignition": 1 if speed > 0 else 0,
            "movement": 1 if speed > 5 else 0,
            "gsm_signal": random.randint(3, 5),
            "priority": 0,
        }

        packet = build_avl_packet([record])
        sock.sendall(packet)

        response = sock.recv(4)
        count = int.from_bytes(response, "big")
        print(f"📦 نقطه {i+1}: lat={lat:.4f} lng={lng:.4f} speed={speed} → تأیید: {count}")

        time.sleep(2)

    print("-" * 50)
    print("✅ شبیه‌سازی تمام شد")
    sock.close()


if __name__ == "__main__":
    try:
        simulate()
    except ConnectionRefusedError:
        print("❌ سرور در دسترس نیست. اول `python teltonika_server.py` را اجرا کنید")
    except Exception as e:
        print(f"❌ خطا: {e}")
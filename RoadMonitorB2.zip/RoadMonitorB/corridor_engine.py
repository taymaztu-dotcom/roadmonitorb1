# -*- coding: utf-8 -*-
"""موتور محاسبه کیلومتراژ و موقعیت روی محور پروژه"""
import sqlite3
import os
import math
import json

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def haversine(lat1, lng1, lat2, lng2):
    """فاصله دو نقطه بر حسب متر"""
    R = 6371000
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
    return R * 2 * math.asin(math.sqrt(a))


def point_to_line_segment_distance(px, py, x1, y1, x2, y2):
    """
    فاصله نقطه (px, py) به قطعه خط (x1,y1)-(x2,y2)
    برگرداندن: (distance_meters, t) که t نسبت مسیر [0,1] است
    """
    # با تقریب: چون فاصله‌ها کمه، از فاصله اقلیدسی lat/lng استفاده می‌کنیم
    # ولی برای دقت، همه چیز را به متر تبدیل می‌کنیم
    A = px - x1
    B = py - y1
    C = x2 - x1
    D = y2 - y1
    dot = A * C + B * D
    len_sq = C * C + D * D
    if len_sq == 0:
        # نقطه شروع = پایان
        return haversine(py, px, y1, x1), 0
    t = max(0, min(1, dot / len_sq))
    # نزدیک‌ترین نقطه روی خط
    proj_x = x1 + t * C
    proj_y = y1 + t * D
    dist_m = haversine(py, px, proj_y, proj_x)
    return dist_m, t


def get_active_corridor(project_id):
    """محور فعال پروژه (اولین محور active)"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM project_corridors
        WHERE project_id = ? AND is_active = 1
        ORDER BY id LIMIT 1
    """, (project_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_corridor_waypoints(corridor_id):
    """نقاط محور به ترتیب"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM corridor_waypoints
        WHERE corridor_id = ? ORDER BY sequence ASC
    """, (corridor_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def calculate_corridor_length(waypoints):
    """طول کل محور بر حسب کیلومتر + کیلومتر شمار هر waypoint"""
    if len(waypoints) < 2:
        return 0, []
    total_km = 0
    km_markers = [0]
    for i in range(1, len(waypoints)):
        d = haversine(waypoints[i-1]["lat"], waypoints[i-1]["lng"],
                      waypoints[i]["lat"], waypoints[i]["lng"]) / 1000
        total_km += d
        km_markers.append(round(total_km, 3))
    return round(total_km, 3), km_markers


def locate_point_on_corridor(lat, lng, corridor_id):
    """
    برای یک نقطه GPS، پیدا کن:
    - km_position (کیلومتر روی محور)
    - distance_from_corridor (فاصله عمود از محور به متر)
    - in_corridor (آیا داخل محدوده هست؟)
    """
    waypoints = get_corridor_waypoints(corridor_id)
    if len(waypoints) < 2:
        return None, None, False

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT width_meters FROM project_corridors WHERE id = ?", (corridor_id,))
    row = cur.fetchone()
    width_m = row["width_meters"] if row else 200
    conn.close()

    best_dist = float('inf')
    best_km = 0
    cumulative_km = 0

    for i in range(1, len(waypoints)):
        p1 = waypoints[i-1]
        p2 = waypoints[i]
        segment_len_m = haversine(p1["lat"], p1["lng"], p2["lat"], p2["lng"])

        dist_m, t = point_to_line_segment_distance(
            lng, lat, p1["lng"], p1["lat"], p2["lng"], p2["lat"]
        )

        if dist_m < best_dist:
            best_dist = dist_m
            best_km = (cumulative_km + t * segment_len_m) / 1000

        cumulative_km += segment_len_m

    in_corridor = best_dist <= width_m
    return round(best_km, 3), round(best_dist, 1), in_corridor


def format_km(km_value):
    """تبدیل 4.523 به '4+523'"""
    if km_value is None:
        return "-"
    km_int = int(km_value)
    meters = round((km_value - km_int) * 1000)
    return f"{km_int}+{meters:03d}"


def save_corridor(project_id, corridor_name, description, waypoints_list,
                   width_meters=200, color="#e74c3c", created_by="", corridor_id=None):
    """
    ذخیره محور جدید یا به‌روزرسانی محور موجود
    waypoints_list = [{"lat": ..., "lng": ...}, ...]
    """
    conn = get_db()
    cur = conn.cursor()
    now = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    total_km, km_markers = calculate_corridor_length(waypoints_list)
    path_json = json.dumps([{"lat": w["lat"], "lng": w["lng"]} for w in waypoints_list])

    if corridor_id:
        cur.execute("""
            UPDATE project_corridors
            SET corridor_name=?, description=?, path_json=?,
                total_length_km=?, width_meters=?, color=?,
                start_km=0, end_km=?, updated_at=?
            WHERE id=? AND project_id=?
        """, (corridor_name, description, path_json, total_km, width_meters, color,
              total_km, now, corridor_id, project_id))
        # پاک کردن waypoints قبلی
        cur.execute("DELETE FROM corridor_waypoints WHERE corridor_id = ?", (corridor_id,))
    else:
        cur.execute("""
            INSERT INTO project_corridors (project_id, corridor_name, description,
                path_json, total_length_km, width_meters, color,
                start_km, end_km, is_active, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 1, ?, ?, ?)
        """, (project_id, corridor_name, description, path_json,
              total_km, width_meters, color, total_km, created_by, now, now))
        corridor_id = cur.lastrowid

    # درج waypoints
    for i, w in enumerate(waypoints_list):
        km = km_markers[i] if i < len(km_markers) else 0
        cur.execute("""
            INSERT INTO corridor_waypoints (corridor_id, sequence, lat, lng, km_marker)
            VALUES (?, ?, ?, ?, ?)
        """, (corridor_id, i, w["lat"], w["lng"], km))

    conn.commit()
    conn.close()
    return {"corridor_id": corridor_id, "total_km": total_km}


def update_gps_corridor_data(project_id, batch_size=500):
    """
    برای نقاط GPS که هنوز کیلومترشان محاسبه نشده، محاسبه و ذخیره کن
    """
    corridor = get_active_corridor(project_id)
    if not corridor:
        return {"updated": 0, "message": "محور فعال یافت نشد"}

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT id, lat, lng FROM gps_points
        WHERE project_id = ? AND corridor_km IS NULL AND lat IS NOT NULL AND lng IS NOT NULL
        LIMIT ?
    """, (project_id, batch_size))
    points = cur.fetchall()

    updated = 0
    for p in points:
        km, dist, in_c = locate_point_on_corridor(p["lat"], p["lng"], corridor["id"])
        if km is not None:
            cur.execute("""
                UPDATE gps_points
                SET corridor_km = ?, distance_from_corridor = ?, in_corridor = ?
                WHERE id = ?
            """, (km, dist, 1 if in_c else 0, p["id"]))
            updated += 1

    conn.commit()
    conn.close()
    return {"updated": updated, "corridor_name": corridor["corridor_name"]}


def get_machines_km_status(project_id):
    """وضعیت کیلومتر همه ماشین‌ها (آخرین موقعیت)"""
    corridor = get_active_corridor(project_id)
    if not corridor:
        return []

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT m.id, m.code, m.name, m.operational_type,
               (SELECT lat FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS lat,
               (SELECT lng FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS lng,
               (SELECT corridor_km FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS last_km,
               (SELECT distance_from_corridor FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS distance,
               (SELECT in_corridor FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS in_corridor,
               (SELECT recorded_at FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS last_seen
        FROM machines m WHERE m.project_id = ? AND m.has_gps = 1
    """, (project_id,))
    rows = cur.fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        # اگر km محاسبه نشده، الان محاسبه کن
        if d["last_km"] is None and d["lat"] and d["lng"]:
            km, dist, in_c = locate_point_on_corridor(d["lat"], d["lng"], corridor["id"])
            d["last_km"] = km
            d["distance"] = dist
            d["in_corridor"] = 1 if in_c else 0
        d["km_formatted"] = format_km(d["last_km"]) if d["last_km"] is not None else "-"
        result.append(d)
    return result


def get_daily_km_range(machine_code, date_greg, project_id):
    """کمترین و بیشترین کیلومتر یک ماشین در یک روز"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT MIN(corridor_km) as min_km, MAX(corridor_km) as max_km,
               AVG(corridor_km) as avg_km,
               COUNT(*) as total, SUM(in_corridor) as in_corridor_count
        FROM gps_points
        WHERE machine_code = ? AND project_id = ? AND date(recorded_at) = ?
          AND corridor_km IS NOT NULL
    """, (machine_code, project_id, date_greg))
    row = cur.fetchone()
    conn.close()
    if not row or row["total"] == 0:
        return None
    return {
        "min_km": row["min_km"], "max_km": row["max_km"], "avg_km": row["avg_km"],
        "total_points": row["total"], "in_corridor_count": row["in_corridor_count"] or 0,
        "in_corridor_percent": round((row["in_corridor_count"] or 0) * 100 / row["total"], 1) if row["total"] else 0,
        "min_km_formatted": format_km(row["min_km"]),
        "max_km_formatted": format_km(row["max_km"]),
    }
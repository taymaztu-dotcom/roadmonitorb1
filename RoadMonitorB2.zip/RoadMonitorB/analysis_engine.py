# -*- coding: utf-8 -*-
"""موتور تحلیل هوشمند GPS — نسخه v2 (با محاسبه فاصله سرویس)"""
import sqlite3
import os
import math
import datetime
import jdatetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

DAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]
PERSIAN_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def get_settings(project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM analysis_settings WHERE project_id = ? LIMIT 1", (project_id,))
    s = cur.fetchone()
    conn.close()
    if s:
        return dict(s)
    return {"stop_speed_threshold": 3, "stop_min_duration_minutes": 3,
            "long_stop_threshold_minutes": 15, "suspicious_stop_threshold_minutes": 30,
            "work_front_min_duration_minutes": 15, "work_front_cluster_radius_meters": 100,
            "service_min_loading_seconds": 60, "gps_timeout_minutes": 10}


def haversine(lat1, lng1, lat2, lng2):
    R = 6371000
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
    return R * 2 * math.asin(math.sqrt(a))


def is_point_in_zone(lat, lng, zone):
    if not zone["center_lat"] or not zone["center_lng"]:
        return False
    return haversine(lat, lng, zone["center_lat"], zone["center_lng"]) <= (zone["radius_meters"] or 50)


def get_target_for_distance(distance_km, project_id):
    """پیدا کردن سرویس هدف بر اساس فاصله"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM service_targets
        WHERE project_id = ? AND distance_from_km <= ? AND distance_to_km > ?
        ORDER BY distance_from_km DESC LIMIT 1
    """, (project_id, distance_km, distance_km))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_points_for_day(machine_code, date_greg, project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM gps_points
        WHERE machine_code = ? AND project_id = ? AND date(recorded_at) = ?
        ORDER BY recorded_at ASC
    """, (machine_code, project_id, date_greg))
    points = [dict(r) for r in cur.fetchall()]
    conn.close()
    return points


def get_zones(project_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM zones WHERE project_id = ? AND is_active = 1", (project_id,))
    zones = [dict(r) for r in cur.fetchall()]
    conn.close()
    return zones


def parse_time(t):
    try:
        return datetime.datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
    except:
        return None


def analyze_stops(machine_code, date_greg, project_id):
    settings = get_settings(project_id)
    speed_th = settings["stop_speed_threshold"]
    min_dur = settings["stop_min_duration_minutes"]
    long_th = settings["long_stop_threshold_minutes"]
    susp_th = settings["suspicious_stop_threshold_minutes"]
    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 2:
        return []
    zones = get_zones(project_id)
    stops = []
    current_stop = None
    for p in points:
        speed = p.get("speed", 0) or 0
        t = parse_time(p["recorded_at"])
        if not t:
            continue
        if speed <= speed_th:
            if current_stop is None:
                current_stop = {"start_time": p["recorded_at"], "start_dt": t,
                                "lat": p["lat"], "lng": p["lng"], "points": 1,
                                "end_time": p["recorded_at"], "end_dt": t}
            else:
                current_stop["end_time"] = p["recorded_at"]
                current_stop["end_dt"] = t
                current_stop["points"] += 1
        else:
            if current_stop:
                dur = (current_stop["end_dt"] - current_stop["start_dt"]).total_seconds() / 60
                if dur >= min_dur:
                    stops.append(finalize_stop(current_stop, dur, long_th, susp_th, zones))
                current_stop = None
    if current_stop:
        dur = (current_stop["end_dt"] - current_stop["start_dt"]).total_seconds() / 60
        if dur >= min_dur:
            stops.append(finalize_stop(current_stop, dur, long_th, susp_th, zones))
    return stops


def finalize_stop(stop, duration, long_th, susp_th, zones):
    zone_id = None
    zone_type = None
    for z in zones:
        if stop["lat"] and stop["lng"] and is_point_in_zone(stop["lat"], stop["lng"], z):
            zone_id = z["id"]
            zone_type = z["zone_type"]
            break
    if zone_type in ("بارگیری", "تخلیه", "سوخت‌گیری"):
        category = "عادی — " + zone_type; trust = "بالا"
    elif zone_type == "کارگاه":
        category = "کارگاه"; trust = "بالا"
    elif zone_type == "پارک شبانه":
        category = "پارک شبانه"; trust = "بالا"
    elif duration >= susp_th:
        category = "مشکوک — طولانی"; trust = "نیازمند بررسی"
    elif duration >= long_th:
        category = "طولانی"; trust = "متوسط"
    else:
        category = "عادی"; trust = "بالا"
    return {"start_time": stop["start_time"], "end_time": stop["end_time"],
            "duration_minutes": int(duration), "lat": stop["lat"], "lng": stop["lng"],
            "zone_id": zone_id, "zone_type": zone_type,
            "stop_category": category, "trust_level": trust, "points": stop["points"]}


def save_analyzed_stops(machine_code, date_greg, project_id, stops, imei=""):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM analyzed_stops WHERE machine_code = ? AND work_date = ? AND project_id = ?",
                (machine_code, date_greg, project_id))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for s in stops:
        cur.execute("""
            INSERT INTO analyzed_stops (project_id, machine_code, imei, work_date,
                start_time, end_time, duration_minutes, lat, lng, zone_id, zone_type,
                stop_category, trust_level, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (project_id, machine_code, imei, date_greg,
              s["start_time"], s["end_time"], s["duration_minutes"],
              s["lat"], s["lng"], s["zone_id"], s["zone_type"],
              s["stop_category"], s["trust_level"], now))
    conn.commit()
    conn.close()


def analyze_zone_events(machine_code, date_greg, project_id):
    points = get_points_for_day(machine_code, date_greg, project_id)
    zones = get_zones(project_id)
    if not points or not zones:
        return []
    events = []
    prev_in = {z["id"]: False for z in zones}
    zone_enter_time = {}
    for p in points:
        for z in zones:
            if not (p["lat"] and p["lng"]):
                continue
            now_in = is_point_in_zone(p["lat"], p["lng"], z)
            was_in = prev_in[z["id"]]
            if now_in and not was_in:
                zone_enter_time[z["id"]] = p["recorded_at"]
                events.append({"zone_id": z["id"], "zone_type": z["zone_type"],
                               "zone_name": z["zone_name"], "event_type": "ورود",
                               "event_time": p["recorded_at"], "duration_minutes": None})
            elif was_in and not now_in:
                entry = zone_enter_time.get(z["id"])
                dur = None
                if entry:
                    e_dt = parse_time(entry)
                    x_dt = parse_time(p["recorded_at"])
                    if e_dt and x_dt:
                        dur = int((x_dt - e_dt).total_seconds() / 60)
                events.append({"zone_id": z["id"], "zone_type": z["zone_type"],
                               "zone_name": z["zone_name"], "event_type": "خروج",
                               "event_time": p["recorded_at"], "duration_minutes": dur})
            prev_in[z["id"]] = now_in
    return events


def save_zone_events(machine_code, date_greg, project_id, events, imei=""):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM zone_events WHERE machine_code = ? AND date(event_time) = ? AND project_id = ?",
                (machine_code, date_greg, project_id))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for e in events:
        cur.execute("""
            INSERT INTO zone_events (project_id, machine_code, imei, zone_id, zone_type,
                zone_name, event_type, event_time, duration_minutes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (project_id, machine_code, imei, e["zone_id"], e["zone_type"],
              e["zone_name"], e["event_type"], e["event_time"], e["duration_minutes"], now))
    conn.commit()
    conn.close()


def analyze_truck_services(machine_code, date_greg, project_id):
    """تشخیص سرویس + محاسبه فاصله + سرویس هدف"""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM zone_events
        WHERE machine_code = ? AND date(event_time) = ? AND project_id = ?
          AND zone_type IN ('بارگیری', 'تخلیه')
        ORDER BY event_time ASC
    """, (machine_code, date_greg, project_id))
    events = [dict(r) for r in cur.fetchall()]

    # مختصات مرکزی هر Zone
    zone_coords = {}
    cur.execute("SELECT id, center_lat, center_lng FROM zones WHERE project_id = ?", (project_id,))
    for z in cur.fetchall():
        zone_coords[z["id"]] = (z["center_lat"], z["center_lng"])
    conn.close()

    services = []
    i = 0
    service_num = 0
    while i < len(events):
        while i < len(events) and not (events[i]["event_type"] == "ورود" and events[i]["zone_type"] == "بارگیری"):
            i += 1
        if i >= len(events):
            break
        load_enter = events[i]; i += 1
        while i < len(events) and not (events[i]["event_type"] == "خروج" and events[i]["zone_id"] == load_enter["zone_id"]):
            i += 1
        if i >= len(events):
            break
        load_exit = events[i]; i += 1
        while i < len(events) and not (events[i]["event_type"] == "ورود" and events[i]["zone_type"] == "تخلیه"):
            i += 1
        if i >= len(events):
            break
        dump_enter = events[i]; i += 1
        while i < len(events) and not (events[i]["event_type"] == "خروج" and events[i]["zone_id"] == dump_enter["zone_id"]):
            i += 1
        if i >= len(events):
            break
        dump_exit = events[i]; i += 1

        service_num += 1
        le = parse_time(load_enter["event_time"])
        lx = parse_time(load_exit["event_time"])
        de = parse_time(dump_enter["event_time"])
        dx = parse_time(dump_exit["event_time"])

        # محاسبه فاصله بارگیری تا تخلیه
        distance_km = 0
        lc = zone_coords.get(load_enter["zone_id"])
        dc = zone_coords.get(dump_enter["zone_id"])
        if lc and dc and lc[0] and dc[0]:
            distance_km = round(haversine(lc[0], lc[1], dc[0], dc[1]) / 1000, 2)

        # پیدا کردن هدف
        target = get_target_for_distance(distance_km, project_id)
        target_services = target["target_services_per_day"] if target else 0

        services.append({
            "service_number": service_num,
            "loading_zone_id": load_enter["zone_id"], "dumping_zone_id": dump_enter["zone_id"],
            "loading_enter_time": load_enter["event_time"], "loading_exit_time": load_exit["event_time"],
            "loading_duration_minutes": int((lx - le).total_seconds() / 60) if le and lx else 0,
            "dumping_enter_time": dump_enter["event_time"], "dumping_exit_time": dump_exit["event_time"],
            "dumping_duration_minutes": int((dx - de).total_seconds() / 60) if de and dx else 0,
            "travel_out_minutes": int((de - lx).total_seconds() / 60) if lx and de else 0,
            "travel_back_minutes": 0,
            "total_cycle_minutes": int((dx - le).total_seconds() / 60) if le and dx else 0,
            "trust_level": "بالا",
            "distance_km": distance_km,
            "target_services": target_services,
        })

    for k in range(len(services) - 1):
        cur_dx = parse_time(services[k]["dumping_exit_time"])
        next_le = parse_time(services[k+1]["loading_enter_time"])
        if cur_dx and next_le:
            services[k]["travel_back_minutes"] = int((next_le - cur_dx).total_seconds() / 60)

    return services


def save_truck_services(machine_code, date_greg, project_id, services):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM truck_services WHERE machine_code = ? AND work_date = ? AND project_id = ?",
                (machine_code, date_greg, project_id))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for s in services:
        cur.execute("""
            INSERT INTO truck_services (project_id, machine_code, work_date, service_number,
                loading_zone_id, dumping_zone_id,
                loading_enter_time, loading_exit_time, loading_duration_minutes,
                dumping_enter_time, dumping_exit_time, dumping_duration_minutes,
                travel_out_minutes, travel_back_minutes, total_cycle_minutes,
                trust_level, distance_km, target_services, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (project_id, machine_code, date_greg, s["service_number"],
              s["loading_zone_id"], s["dumping_zone_id"],
              s["loading_enter_time"], s["loading_exit_time"], s["loading_duration_minutes"],
              s["dumping_enter_time"], s["dumping_exit_time"], s["dumping_duration_minutes"],
              s["travel_out_minutes"], s["travel_back_minutes"], s["total_cycle_minutes"],
              s["trust_level"], s["distance_km"], s["target_services"], now))
    conn.commit()
    conn.close()


def analyze_work_fronts(machine_code, date_greg, project_id):
    settings = get_settings(project_id)
    cluster_radius = settings["work_front_cluster_radius_meters"]
    min_dur = settings["work_front_min_duration_minutes"]
    points = get_points_for_day(machine_code, date_greg, project_id)
    if len(points) < 5:
        return []
    clusters = []
    for p in points:
        if not (p["lat"] and p["lng"]):
            continue
        added = False
        for c in clusters:
            if haversine(p["lat"], p["lng"], c["lat_sum"]/c["count"], c["lng_sum"]/c["count"]) <= cluster_radius:
                c["lat_sum"] += p["lat"]; c["lng_sum"] += p["lng"]; c["count"] += 1
                c["last_time"] = p["recorded_at"]; c["points"].append(p)
                added = True; break
        if not added:
            clusters.append({"lat_sum": p["lat"], "lng_sum": p["lng"], "count": 1,
                             "first_time": p["recorded_at"], "last_time": p["recorded_at"],
                             "points": [p]})
    candidates = []
    for c in clusters:
        first = parse_time(c["first_time"]); last = parse_time(c["last_time"])
        if not (first and last):
            continue
        dur = (last - first).total_seconds() / 60
        if dur < min_dur:
            continue
        moving = sum(1 for p in c["points"] if (p.get("speed") or 0) > 3)
        candidates.append({
            "center_lat": c["lat_sum"]/c["count"], "center_lng": c["lng_sum"]/c["count"],
            "radius_meters": cluster_radius, "first_seen": c["first_time"],
            "last_seen": c["last_time"], "duration_minutes": int(dur),
            "point_count": c["count"], "movement_pattern": f"{moving} / {c['count']} نقطه در حرکت",
            "trust_level": "متوسط" if moving >= 5 else "نیازمند بررسی",
        })
    return candidates


def save_work_fronts(machine_code, date_greg, project_id, candidates):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM work_front_candidates WHERE machine_code = ? AND work_date = ? AND project_id = ?",
                (machine_code, date_greg, project_id))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for c in candidates:
        cur.execute("""
            INSERT INTO work_front_candidates (project_id, machine_code, work_date,
                center_lat, center_lng, radius_meters, first_seen, last_seen,
                duration_minutes, point_count, movement_pattern, trust_level, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (project_id, machine_code, date_greg, c["center_lat"], c["center_lng"],
              c["radius_meters"], c["first_seen"], c["last_seen"], c["duration_minutes"],
              c["point_count"], c["movement_pattern"], c["trust_level"], now))
    conn.commit()
    conn.close()


def build_daily_summary(machine_code, date_greg, project_id):
    points = get_points_for_day(machine_code, date_greg, project_id)
    if not points:
        return None
    settings = get_settings(project_id)
    speed_th = settings["stop_speed_threshold"]
    total_distance = 0; max_speed = 0
    moving_speeds = []; moving_minutes = 0; idle_running_minutes = 0; engine_off_minutes = 0
    for i, p in enumerate(points):
        sp = p.get("speed", 0) or 0
        max_speed = max(max_speed, sp)
        if sp > speed_th:
            moving_speeds.append(sp)
        if i > 0:
            prev = points[i-1]
            if prev["lat"] and prev["lng"] and p["lat"] and p["lng"]:
                d = haversine(prev["lat"], prev["lng"], p["lat"], p["lng"]) / 1000
                total_distance += d
                pt = parse_time(prev["recorded_at"]); ct = parse_time(p["recorded_at"])
                if pt and ct:
                    diff_min = (ct - pt).total_seconds() / 60
                    if diff_min > 30:
                        continue
                    if sp > speed_th:
                        moving_minutes += diff_min
                    elif p.get("ignition"):
                        idle_running_minutes += diff_min
                    else:
                        engine_off_minutes += diff_min

    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as c FROM analyzed_stops WHERE machine_code=? AND work_date=? AND project_id=?",
                (machine_code, date_greg, project_id))
    stops_count = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM analyzed_stops WHERE machine_code=? AND work_date=? AND project_id=? AND duration_minutes>=15",
                (machine_code, date_greg, project_id))
    long_stops = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM analyzed_stops WHERE machine_code=? AND work_date=? AND project_id=? AND stop_category LIKE 'مشکوک%'",
                (machine_code, date_greg, project_id))
    susp_stops = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM truck_services WHERE machine_code=? AND work_date=? AND project_id=?",
                (machine_code, date_greg, project_id))
    services_count = cur.fetchone()["c"]
    cur.execute("SELECT event_time, event_type FROM zone_events WHERE machine_code=? AND date(event_time)=? AND zone_type='کارگاه' ORDER BY event_time ASC",
                (machine_code, date_greg))
    gate_events = cur.fetchall()
    gate_exit = None; gate_enter = None
    for g in gate_events:
        if g["event_type"] == "خروج" and not gate_exit:
            gate_exit = g["event_time"]
        if g["event_type"] == "ورود":
            gate_enter = g["event_time"]
    conn.close()

    return {"machine_code": machine_code, "work_date": date_greg,
            "first_gps_time": points[0]["recorded_at"], "last_gps_time": points[-1]["recorded_at"],
            "total_points": len(points), "distance_km": round(total_distance, 2),
            "max_speed": int(max_speed),
            "avg_moving_speed": int(sum(moving_speeds)/len(moving_speeds)) if moving_speeds else 0,
            "moving_minutes": int(moving_minutes), "idle_running_minutes": int(idle_running_minutes),
            "engine_off_minutes": int(engine_off_minutes), "stops_count": stops_count,
            "long_stops_count": long_stops, "suspicious_stops_count": susp_stops,
            "effective_work_minutes": int(moving_minutes), "services_count": services_count,
            "gate_enter_time": gate_enter, "gate_exit_time": gate_exit,
            "data_quality": "خوب" if len(points) >= 100 else "متوسط" if len(points) >= 30 else "کم"}


def save_daily_summary(summary, project_id):
    conn = get_db(); cur = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("SELECT id FROM daily_machine_summary WHERE machine_code=? AND work_date=? AND project_id=?",
                (summary["machine_code"], summary["work_date"], project_id))
    existing = cur.fetchone()
    if existing:
        cur.execute("""
            UPDATE daily_machine_summary SET
                first_gps_time=?, last_gps_time=?, total_points=?, distance_km=?,
                max_speed=?, avg_moving_speed=?, moving_minutes=?, idle_running_minutes=?,
                engine_off_minutes=?, stops_count=?, long_stops_count=?, suspicious_stops_count=?,
                effective_work_minutes=?, services_count=?, gate_enter_time=?, gate_exit_time=?,
                data_quality=?, updated_at=?
            WHERE id=?
        """, (summary["first_gps_time"], summary["last_gps_time"], summary["total_points"],
              summary["distance_km"], summary["max_speed"], summary["avg_moving_speed"],
              summary["moving_minutes"], summary["idle_running_minutes"], summary["engine_off_minutes"],
              summary["stops_count"], summary["long_stops_count"], summary["suspicious_stops_count"],
              summary["effective_work_minutes"], summary["services_count"],
              summary["gate_enter_time"], summary["gate_exit_time"], summary["data_quality"], now,
              existing["id"]))
    else:
        cur.execute("""
            INSERT INTO daily_machine_summary (project_id, machine_code, work_date,
                first_gps_time, last_gps_time, total_points, distance_km,
                max_speed, avg_moving_speed, moving_minutes, idle_running_minutes,
                engine_off_minutes, stops_count, long_stops_count, suspicious_stops_count,
                effective_work_minutes, services_count, gate_enter_time, gate_exit_time,
                data_quality, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (project_id, summary["machine_code"], summary["work_date"],
              summary["first_gps_time"], summary["last_gps_time"], summary["total_points"],
              summary["distance_km"], summary["max_speed"], summary["avg_moving_speed"],
              summary["moving_minutes"], summary["idle_running_minutes"], summary["engine_off_minutes"],
              summary["stops_count"], summary["long_stops_count"], summary["suspicious_stops_count"],
              summary["effective_work_minutes"], summary["services_count"],
              summary["gate_enter_time"], summary["gate_exit_time"], summary["data_quality"], now, now))
    conn.commit()
    conn.close()


def run_full_analysis(machine_code, date_greg, project_id, imei=""):
    result = {"success": True, "steps": {}}
    try:
        stops = analyze_stops(machine_code, date_greg, project_id)
        save_analyzed_stops(machine_code, date_greg, project_id, stops, imei)
        result["steps"]["stops"] = len(stops)
        events = analyze_zone_events(machine_code, date_greg, project_id)
        save_zone_events(machine_code, date_greg, project_id, events, imei)
        result["steps"]["zone_events"] = len(events)
        services = analyze_truck_services(machine_code, date_greg, project_id)
        save_truck_services(machine_code, date_greg, project_id, services)
        result["steps"]["truck_services"] = len(services)
        fronts = analyze_work_fronts(machine_code, date_greg, project_id)
        save_work_fronts(machine_code, date_greg, project_id, fronts)
        result["steps"]["work_fronts"] = len(fronts)
        summary = build_daily_summary(machine_code, date_greg, project_id)
        if summary:
            save_daily_summary(summary, project_id)
        result["steps"]["summary"] = "ok" if summary else "بدون داده"
    except Exception as e:
        result["success"] = False
        result["error"] = str(e)
    return result


def run_analysis_for_all_machines(date_greg, project_id):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT code, imei FROM machines WHERE project_id = ? AND has_gps = 1", (project_id,))
    machines = cur.fetchall()
    conn.close()
    results = []
    for m in machines:
        r = run_full_analysis(m["code"], date_greg, project_id, m["imei"] or "")
        r["machine_code"] = m["code"]
        results.append(r)
    return results
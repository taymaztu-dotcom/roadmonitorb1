# -*- coding: utf-8 -*-
"""تولید PDF گزارش روزانه — نسخه پایدار"""
import os
import sqlite3
import datetime
import jdatetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "roadmonitor.db")
FONTS_DIR = os.path.join(BASE_DIR, "static", "fonts")
OUTPUT_DIR = os.path.join(BASE_DIR, "static", "reports")
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ─── ثبت فونت‌ها — انعطاف‌پذیر ───
FONT_NAME = "Helvetica"  # پیش‌فرض
FONT_BOLD = "Helvetica-Bold"

def _register_fonts():
    """ثبت فونت‌های موجود و برگرداندن نام فونت اصلی و بولد"""
    global FONT_NAME, FONT_BOLD
    candidates = [
        ("BNazanin", "BNazanin.ttf"),
        ("BZar", "BZar.ttf"),
        ("BNasim", "BNasim.ttf"),
        ("BTitr", "BTitr.ttf"),
    ]
    registered = []
    for name, filename in candidates:
        path = os.path.join(FONTS_DIR, filename)
        if os.path.exists(path):
            try:
                pdfmetrics.registerFont(TTFont(name, path))
                registered.append(name)
            except Exception as e:
                print(f"[pdf font error] {name}: {e}")

    if registered:
        # فونت اصلی = اولین فونت ثبت شده
        FONT_NAME = registered[0]
        # فونت بولد = BTitr اگر باشد، وگرنه همان فونت اصلی
        FONT_BOLD = "BTitr" if "BTitr" in registered else FONT_NAME
        # register family به‌درستی
        try:
            registerFontFamily(FONT_NAME,
                               normal=FONT_NAME,
                               bold=FONT_BOLD,
                               italic=FONT_NAME,
                               boldItalic=FONT_BOLD)
        except Exception:
            pass


_register_fonts()


def rtl(text):
    """تبدیل متن فارسی برای reportlab"""
    try:
        from bidi.algorithm import get_display
        import arabic_reshaper
        reshaped = arabic_reshaper.reshape(str(text))
        return get_display(reshaped)
    except Exception:
        return str(text)


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def generate_daily_pdf(date_jalali, project_id=1):
    try:
        parts = date_jalali.split("/")
        date_greg = jdatetime.date(int(parts[0]), int(parts[1]), int(parts[2])).togregorian().strftime("%Y-%m-%d")
    except:
        return None

    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT name FROM projects WHERE id = ?", (project_id,))
    proj = cur.fetchone()
    project_name = proj["name"] if proj else "-"

    cur.execute("SELECT value FROM settings WHERE key = 'company_name'")
    cn = cur.fetchone()
    company_name = cn["value"] if cn else "-"

    cur.execute("""
        SELECT dms.*, m.name AS machine_name, m.operational_type
        FROM daily_machine_summary dms
        LEFT JOIN machines m ON dms.machine_code = m.code
        WHERE dms.work_date = ? AND dms.project_id = ?
    """, (date_greg, project_id))
    summaries = [dict(r) for r in cur.fetchall()]

    cur.execute("""
        SELECT machine_code,
               COUNT(*) as total,
               AVG(total_cycle_minutes) as avg_cycle,
               AVG(distance_km) as avg_dist,
               MAX(target_services) as target
        FROM truck_services WHERE work_date = ? AND project_id = ?
        GROUP BY machine_code
    """, (date_greg, project_id))
    service_stats = []
    for r in cur.fetchall():
        d = dict(r)
        cur.execute("SELECT name FROM machines WHERE code = ?", (d["machine_code"],))
        m = cur.fetchone()
        d["machine_name"] = m["name"] if m else d["machine_code"]
        service_stats.append(d)

    cur.execute("""
        SELECT s.*, m.name AS machine_name
        FROM analyzed_stops s
        LEFT JOIN machines m ON s.machine_code = m.code
        WHERE s.work_date = ? AND s.project_id = ? AND s.stop_category LIKE 'مشکوک%'
        ORDER BY s.duration_minutes DESC
    """, (date_greg, project_id))
    suspicious_stops = [dict(r) for r in cur.fetchall()]

    conn.close()

    # ─── ساخت PDF ───
    filename = f"daily_report_{date_greg}.pdf"
    output_path = os.path.join(OUTPUT_DIR, filename)

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            rightMargin=15*mm, leftMargin=15*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    story = []

    title_style = ParagraphStyle("MyTitle",
                                  fontName=FONT_BOLD, fontSize=18,
                                  alignment=TA_CENTER, textColor=HexColor("#1a2942"),
                                  spaceAfter=6, leading=22)
    subtitle_style = ParagraphStyle("MySub",
                                     fontName=FONT_NAME, fontSize=11,
                                     alignment=TA_CENTER, textColor=HexColor("#64748b"),
                                     spaceAfter=12, leading=16)
    header_style = ParagraphStyle("MyH2",
                                   fontName=FONT_BOLD, fontSize=13,
                                   alignment=TA_RIGHT, textColor=HexColor("#0369a1"),
                                   spaceAfter=6, spaceBefore=10, leading=18)
    normal_style = ParagraphStyle("MyN",
                                   fontName=FONT_NAME, fontSize=10,
                                   alignment=TA_RIGHT, leading=14)
    footer_style = ParagraphStyle("MyF",
                                   fontName=FONT_NAME, fontSize=8,
                                   alignment=TA_CENTER, textColor=HexColor("#94a3b8"),
                                   leading=12)

    # سربرگ
    story.append(Paragraph(rtl(company_name), title_style))
    story.append(Paragraph(rtl(f"گزارش روزانه — {date_jalali}"), subtitle_style))
    story.append(Paragraph(rtl(f"پروژه: {project_name}"), subtitle_style))
    story.append(Spacer(1, 8))

    def make_table(header_row, data_rows, header_color="#2c3e50"):
        data = [[rtl(h) for h in header_row]]
        for row in data_rows:
            data.append([rtl(str(c)) for c in row])
        t = Table(data, repeatRows=1)
        t.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), FONT_NAME),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BACKGROUND", (0, 0), (-1, 0), HexColor(header_color)),
            ("TEXTCOLOR", (0, 0), (-1, 0), HexColor("#ffffff")),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.3, HexColor("#cbd5e1")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
        ]))
        return t

    # جدول ۱: خلاصه ماشین‌ها
    story.append(Paragraph(rtl("خلاصه فعالیت ماشین‌آلات"), header_style))
    if summaries:
        rows = []
        for s in summaries:
            rows.append([
                s.get("machine_name") or s.get("machine_code"),
                s.get("operational_type") or "-",
                s.get("distance_km") or 0,
                s.get("moving_minutes") or 0,
                s.get("suspicious_stops_count") or 0,
                s.get("services_count") or 0,
            ])
        story.append(make_table(
            ["ماشین", "نوع", "مسافت (km)", "حرکت (دقیقه)", "توقف مشکوک", "سرویس"],
            rows
        ))
    else:
        story.append(Paragraph(rtl("داده‌ای موجود نیست"), normal_style))

    # جدول ۲: آمار سرویس
    story.append(Paragraph(rtl("آمار سرویس کامیون‌ها"), header_style))
    if service_stats:
        rows = []
        for s in service_stats:
            target = s.get("target") or 0
            realization = f"{round(s['total'] / target * 100)}%" if target > 0 else "-"
            rows.append([
                s["machine_name"],
                s["total"],
                target if target else "-",
                realization,
                round(s.get("avg_cycle") or 0),
                round(s.get("avg_dist") or 0, 1),
            ])
        story.append(make_table(
            ["کامیون", "سرویس واقعی", "هدف", "درصد تحقق", "میانگین سیکل (د)", "میانگین فاصله (km)"],
            rows,
            header_color="#0f766e"
        ))
    else:
        story.append(Paragraph(rtl("سرویسی برای این روز ثبت نشده"), normal_style))

    # جدول ۳: توقف‌های مشکوک
    if suspicious_stops:
        story.append(Paragraph(rtl("توقف‌های مشکوک"), header_style))
        rows = []
        for s in suspicious_stops:
            rows.append([
                s.get("machine_name") or s["machine_code"],
                str(s["start_time"])[11:16],
                str(s["end_time"])[11:16] if s.get("end_time") else "-",
                s.get("duration_minutes") or 0,
                s.get("stop_category") or "-",
            ])
        story.append(make_table(
            ["ماشین", "شروع", "پایان", "مدت (دقیقه)", "نوع"],
            rows,
            header_color="#b91c1c"
        ))

    # فوتر
    story.append(Spacer(1, 20))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    story.append(Paragraph(rtl(f"تولید شده در: {now} | سامانه پایش عملکرد — دکتر سعید داداشی"), footer_style))

    try:
        doc.build(story)
        return output_path
    except Exception as e:
        print(f"[pdf build error] {e}")
        return None
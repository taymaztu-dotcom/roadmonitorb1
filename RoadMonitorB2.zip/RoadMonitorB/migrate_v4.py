# -*- coding: utf-8 -*-
"""Migration v4 — فاز A"""
import sqlite3
import os
import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def col_exists(cur, table, col):
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def add_col(cur, table, col, definition):
    if not col_exists(cur, table, col):
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
        print(f"  [+] {col} به {table} اضافه شد")
    else:
        print(f"  [=] {col} از قبل وجود دارد")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    print("=" * 65)
    print("Migration v4 — فاز A")
    print("=" * 65)

    print("\n📌 machines:")
    add_col(cur, "machines", "operational_type", "TEXT DEFAULT 'برگشتی'")
    add_col(cur, "machines", "imei", "TEXT")
    add_col(cur, "machines", "has_gps", "INTEGER DEFAULT 1")
    add_col(cur, "machines", "night_park_zone_id", "INTEGER")
    add_col(cur, "machines", "sim_card_number", "TEXT")
    add_col(cur, "machines", "sim_operator", "TEXT")
    add_col(cur, "machines", "installation_notes", "TEXT")

    print("\n📌 exceptions:")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS exceptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            exception_type TEXT NOT NULL,
            subject_type TEXT NOT NULL,
            subject_id INTEGER,
            subject_code TEXT,
            start_datetime TEXT NOT NULL,
            end_datetime TEXT,
            description TEXT,
            approved_by TEXT,
            created_by TEXT,
            created_at TEXT,
            status TEXT DEFAULT 'تایید شده'
        )
    """)
    print("  [+] exceptions آماده شد")

    print("\n📌 audit_log:")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            action TEXT NOT NULL,
            field_name TEXT,
            old_value TEXT,
            new_value TEXT,
            reason TEXT,
            user_username TEXT,
            ip_address TEXT,
            created_at TEXT
        )
    """)
    print("  [+] audit_log آماده شد")

    print("\n📌 zones:")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS zones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            zone_name TEXT NOT NULL,
            zone_type TEXT NOT NULL,
            center_lat REAL,
            center_lng REAL,
            radius_meters REAL DEFAULT 50,
            polygon_json TEXT,
            color TEXT DEFAULT '#3498db',
            is_active INTEGER DEFAULT 1,
            description TEXT,
            created_at TEXT
        )
    """)
    print("  [+] zones آماده شد")

    print("\n📌 trust_level:")
    add_col(cur, "personnel_attendance", "trust_level", "TEXT DEFAULT 'بالا'")
    add_col(cur, "work_logs", "trust_level", "TEXT DEFAULT 'بالا'")

    cur.execute("SELECT COUNT(*) FROM zones WHERE project_id = 1")
    if cur.fetchone()[0] == 0:
        cur.execute("""
            INSERT INTO zones (project_id, zone_name, zone_type,
                center_lat, center_lng, radius_meters, color, description, created_at)
            VALUES (1, 'کارگاه اصلی', 'کارگاه', 35.7000, 51.4000, 100, '#e74c3c',
                'محدوده اصلی کارگاه — قابل ویرایش', ?)
        """, (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        print("  [+] Zone نمونه «کارگاه اصلی» درج شد")

    conn.commit()
    conn.close()
    print("\n" + "=" * 65)
    print("✅ Migration v4 با موفقیت انجام شد!")
    print("=" * 65)


if __name__ == "__main__":
    migrate()
# -*- coding: utf-8 -*-
"""موتور تشخیص و ارسال هشدارها — فاز F"""
import sqlite3
import os
import datetime
import jdatetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def get_active_rules(project_id=1):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM alert_rules WHERE project_id = ? AND is_enabled = 1", (project_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_rule(rule_key, project_id=1):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM alert_rules WHERE project_id = ? AND rule_key = ? LIMIT 1", (project_id, rule_key))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def already_alerted_recently(rule_key, related_type, related_id, hours=2, project_id=1):
    """جلوگیری از ارسال مکرر همان هشدار در بازه کوتاه"""
    conn = get_db()
    cur = conn.cursor()
    cutoff = (datetime.datetime.now() - datetime.timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("""
        SELECT COUNT(*) as c FROM notifications
        WHERE project_id = ? AND rule_key = ? AND related_type = ? AND related_id = ?
          AND created_at >= ?
    """, (project_id, rule_key, related_type, related_id or 0, cutoff))
    c = cur.fetchone()["c"]
    conn.close()
    return c > 0


def create_alert(rule, title, message, related_type="", related_id=None, project_id=1):
    """ثبت اعلان + ارسال تلگرام (در صورت فعال)"""
    conn = get_db()
    cur = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    channels = []
    if rule.get("send_panel"):
        channels.append("panel")
    if rule.get("send_telegram"):
        channels.append("telegram")
    if rule.get("send_sms"):
        channels.append("sms")

    cur.execute("""
        INSERT INTO notifications (project_id, notification_type, severity, title, message,
            related_type, related_id, channels_sent, rule_key, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (project_id, rule["rule_name"], rule.get("severity", "warning"),
          title, message, related_type, related_id,
          ",".join(channels), rule["rule_key"], now))
    conn.commit()

    # ارسال به گیرندگان تلگرام
    if rule.get("send_telegram"):
        try:
            from telegram_provider import send_message as tg_send
            cur.execute("""
                SELECT full_name, telegram_chat_id FROM users
                WHERE receive_urgent_alert = 1 AND is_active = 1
                  AND telegram_chat_id IS NOT NULL AND telegram_chat_id != ''
                  AND alert_channels LIKE '%telegram%'
            """)
            recipients = cur.fetchall()

            severity_icon = {"critical": "🚨", "warning": "⚠️", "info": "ℹ️"}.get(rule.get("severity"), "🔔")
            full_msg = f"{severity_icon} <b>{title}</b>\n\n{message}\n\n<i>{now}</i>"

            # ارسال به کانال اصلی
            tg_send(full_msg, project_id=project_id, parse_mode="HTML")

            # ارسال به گیرندگان شخصی — نیاز به تنظیم Bot و Chat ID شخصی
            # (فعلاً فقط به کانال — گیرندگان شخصی نیاز به شروع chat با Bot دارند)
        except Exception as e:
            print(f"[alert telegram error] {e}")

    conn.close()


# ═══════════ چک‌های خودکار ═══════════

def check_suspicious_stops(project_id=1):
    """توقف‌های مشکوک اخیر"""
    rule = get_rule("suspicious_stop", project_id)
    if not rule or not rule["is_enabled"]:
        return 0
    threshold = rule["threshold_minutes"] or 30

    conn = get_db()
    cur = conn.cursor()
    # توقف‌های مشکوک ثبت شده اخیر
    cur.execute("""
        SELECT s.*, m.name as machine_name, m.id as machine_id
        FROM analyzed_stops s
        LEFT JOIN machines m ON s.machine_code = m.code
        WHERE s.project_id = ? AND s.duration_minutes >= ?
          AND s.stop_category LIKE 'مشکوک%'
          AND date(s.created_at) = date('now')
    """, (project_id, threshold))
    stops = cur.fetchall()
    conn.close()

    created = 0
    for s in stops:
        if already_alerted_recently("suspicious_stop", "stop", s["id"], hours=6, project_id=project_id):
            continue
        title = f"توقف مشکوک: {s['machine_name'] or s['machine_code']}"
        msg = f"مدت: {s['duration_minutes']} دقیقه\nشروع: {s['start_time'][11:16] if s['start_time'] else '-'}\nپایان: {s['end_time'][11:16] if s['end_time'] else '-'}\nمحل: {s['zone_type'] or 'خارج از محدوده'}"
        create_alert(rule, title, msg, "stop", s["id"], project_id)
        created += 1
    return created


def check_gps_offline(project_id=1):
    """ماشین‌هایی که ردیاب‌شان قطع شده"""
    rule = get_rule("gps_offline", project_id)
    if not rule or not rule["is_enabled"]:
        return 0
    threshold = rule["threshold_minutes"] or 15
    cutoff = (datetime.datetime.now() - datetime.timedelta(minutes=threshold)).strftime("%Y-%m-%d %H:%M:%S")

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT m.id, m.code, m.name, m.imei,
               (SELECT MAX(recorded_at) FROM gps_points WHERE machine_code = m.code) AS last_seen
        FROM machines m
        WHERE m.project_id = ? AND m.has_gps = 1 AND m.active_status = 'فعال'
          AND m.imei IS NOT NULL AND m.imei != ''
    """, (project_id,))
    machines = cur.fetchall()
    conn.close()

    created = 0
    for m in machines:
        if not m["last_seen"] or m["last_seen"] < cutoff:
            if already_alerted_recently("gps_offline", "machine", m["id"], hours=1, project_id=project_id):
                continue
            title = f"قطع GPS: {m['name']}"
            if m["last_seen"]:
                try:
                    last_dt = datetime.datetime.strptime(m["last_seen"], "%Y-%m-%d %H:%M:%S")
                    diff = int((datetime.datetime.now() - last_dt).total_seconds() / 60)
                    msg = f"آخرین ارتباط: {m['last_seen']}\nقطع از: {diff} دقیقه پیش\nIMEI: {m['imei']}"
                except:
                    msg = f"آخرین ارتباط: {m['last_seen']}"
            else:
                msg = f"هیچ داده‌ای دریافت نشده\nIMEI: {m['imei']}"
            create_alert(rule, title, msg, "machine", m["id"], project_id)
            created += 1
    return created


def check_low_voltage(project_id=1):
    """ولتاژ کم ردیاب"""
    rule = get_rule("low_voltage", project_id)
    if not rule or not rule["is_enabled"]:
        return 0
    threshold = rule["threshold_value"] or 22.0

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT m.id, m.code, m.name,
               (SELECT external_voltage FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS voltage,
               (SELECT recorded_at FROM gps_points WHERE machine_code = m.code ORDER BY id DESC LIMIT 1) AS last_seen
        FROM machines m
        WHERE m.project_id = ? AND m.has_gps = 1 AND m.active_status = 'فعال'
    """, (project_id,))
    machines = cur.fetchall()
    conn.close()

    created = 0
    for m in machines:
        if not m["voltage"] or m["voltage"] >= threshold or m["voltage"] < 5:
            continue
        if already_alerted_recently("low_voltage", "machine", m["id"], hours=12, project_id=project_id):
            continue
        title = f"ولتاژ کم: {m['name']}"
        msg = f"ولتاژ فعلی: {m['voltage']:.2f} V\nحد مجاز: {threshold} V\nآخرین گزارش: {m['last_seen']}"
        create_alert(rule, title, msg, "machine", m["id"], project_id)
        created += 1
    return created


def check_late_start(project_id=1):
    """تأخیر در شروع کار — بر اساس اولین GPS point امروز"""
    rule = get_rule("late_start", project_id)
    if not rule or not rule["is_enabled"]:
        return 0
    threshold = rule["threshold_minutes"] or 30

    conn = get_db()
    cur = conn.cursor()
    # الگوی پیش‌فرض پروژه
    cur.execute("SELECT work_start FROM work_patterns WHERE project_id = ? AND is_default = 1 LIMIT 1", (project_id,))
    pattern = cur.fetchone()
    if not pattern or not pattern["work_start"]:
        conn.close()
        return 0

    try:
        h, mm = map(int, pattern["work_start"].split(":"))
        official_min = h * 60 + mm
    except:
        conn.close()
        return 0

    now = datetime.datetime.now()
    now_min = now.hour * 60 + now.minute
    # فقط بین شروع رسمی + آستانه تا ۲ ساعت بعدش چک شود
    if now_min < official_min + threshold or now_min > official_min + threshold + 120:
        conn.close()
        return 0

    today = now.strftime("%Y-%m-%d")
    cur.execute("""
        SELECT m.id, m.code, m.name,
               (SELECT MIN(recorded_at) FROM gps_points
                WHERE machine_code = m.code AND date(recorded_at) = ?) AS first_gps
        FROM machines m
        WHERE m.project_id = ? AND m.has_gps = 1
          AND m.operational_type = 'برگشتی'
          AND m.active_status = 'فعال'
    """, (today, project_id))
    machines = cur.fetchall()
    conn.close()

    created = 0
    for m in machines:
        # اگر تا الان هیچ داده‌ای امروز نداشت
        if not m["first_gps"]:
            if already_alerted_recently("late_start", "machine", m["id"], hours=4, project_id=project_id):
                continue
            title = f"تأخیر شروع: {m['name']}"
            msg = f"ماشین {m['name']} تا الان امروز داده‌ای نفرستاده.\nساعت شروع رسمی: {pattern['work_start']}"
            create_alert(rule, title, msg, "machine", m["id"], project_id)
            created += 1
    return created


def run_all_checks(project_id=1):
    """اجرای همه چک‌ها — فراخوانی توسط Scheduler"""
    results = {}
    try:
        results["suspicious_stop"] = check_suspicious_stops(project_id)
    except Exception as e:
        results["suspicious_stop_error"] = str(e)
    try:
        results["gps_offline"] = check_gps_offline(project_id)
    except Exception as e:
        results["gps_offline_error"] = str(e)
    try:
        results["low_voltage"] = check_low_voltage(project_id)
    except Exception as e:
        results["low_voltage_error"] = str(e)
    try:
        results["late_start"] = check_late_start(project_id)
    except Exception as e:
        results["late_start_error"] = str(e)

    total = sum(v for k, v in results.items() if not k.endswith("_error") and isinstance(v, int))
    results["total"] = total
    return results
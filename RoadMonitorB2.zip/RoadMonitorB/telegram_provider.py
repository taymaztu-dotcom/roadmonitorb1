# -*- coding: utf-8 -*-
"""درگاه ارسال به تلگرام Bot API — با لاگ کامل"""
import requests
import sqlite3
import os
import json as _json

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")
TELEGRAM_API = "https://api.telegram.org/bot{token}/{method}"


def get_settings(project_id=1):
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM telegram_settings WHERE project_id = ? LIMIT 1", (project_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def build_proxies(proxy_url):
    if not proxy_url or not proxy_url.strip():
        return None
    p = proxy_url.strip()
    return {"http": p, "https": p}


def _extract_error(response_data, exc=None):
    """استخراج خطای دقیق از پاسخ Telegram"""
    if exc:
        return str(exc)
    if isinstance(response_data, dict):
        if response_data.get("description"):
            return f"Telegram: {response_data['description']} (code {response_data.get('error_code', '?')})"
    return "خطای ناشناخته"


def send_message(text, project_id=1, parse_mode=None):
    """ارسال پیام متنی"""
    s = get_settings(project_id)
    if not s:
        return {"ok": False, "error": "تنظیمات تلگرام در دیتابیس نیست"}
    if not s["is_enabled"]:
        return {"ok": False, "error": "ارسال تلگرام غیرفعال است"}
    if not s["bot_token"] or not s["channel_chat_id"]:
        return {"ok": False, "error": "توکن یا Chat ID خالی است"}

    url = TELEGRAM_API.format(token=s["bot_token"].strip(), method="sendMessage")
    proxies = build_proxies(s["proxy_url"])
    payload = {
        "chat_id": s["channel_chat_id"].strip(),
        "text": text,
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode

    try:
        r = requests.post(url, data=payload, proxies=proxies, timeout=60)
        try:
            data = r.json()
        except Exception:
            return {"ok": False, "error": f"پاسخ نامعتبر — HTTP {r.status_code} — {r.text[:200]}"}
        if data.get("ok"):
            return {"ok": True, "response": data}
        return {"ok": False, "error": _extract_error(data)}
    except requests.exceptions.ProxyError as e:
        return {"ok": False, "error": f"خطای پروکسی — pip install requests[socks] pysocks — {e}"}
    except requests.exceptions.ConnectTimeout:
        return {"ok": False, "error": "Timeout — تلگرام در دسترس نیست (فیلترشکن روشن است؟)"}
    except requests.exceptions.ConnectionError as e:
        return {"ok": False, "error": f"اتصال ناموفق — {e}"}
    except Exception as e:
        return {"ok": False, "error": f"خطای ناشناخته: {type(e).__name__} — {e}"}


def send_document(file_path, caption="", project_id=1):
    """ارسال فایل (PDF)"""
    s = get_settings(project_id)
    if not s:
        return {"ok": False, "error": "تنظیمات تلگرام در دیتابیس نیست"}
    if not s["is_enabled"]:
        return {"ok": False, "error": "ارسال تلگرام غیرفعال است"}
    if not s["bot_token"] or not s["channel_chat_id"]:
        return {"ok": False, "error": "توکن یا Chat ID خالی است"}
    if not os.path.exists(file_path):
        return {"ok": False, "error": f"فایل یافت نشد: {file_path}"}

    url = TELEGRAM_API.format(token=s["bot_token"].strip(), method="sendDocument")
    proxies = build_proxies(s["proxy_url"])

    try:
        with open(file_path, "rb") as f:
            r = requests.post(url,
                              data={
                                  "chat_id": s["channel_chat_id"].strip(),
                                  "caption": caption or "",
                              },
                              files={"document": (os.path.basename(file_path), f, "application/pdf")},
                              proxies=proxies, timeout=180)
        try:
            data = r.json()
        except Exception:
            return {"ok": False, "error": f"پاسخ نامعتبر — HTTP {r.status_code} — {r.text[:200]}"}
        if data.get("ok"):
            return {"ok": True, "response": data}
        return {"ok": False, "error": _extract_error(data)}
    except requests.exceptions.ProxyError as e:
        return {"ok": False, "error": f"خطای پروکسی — pip install requests[socks] pysocks — {e}"}
    except requests.exceptions.ConnectTimeout:
        return {"ok": False, "error": "Timeout — تلگرام در دسترس نیست"}
    except requests.exceptions.ConnectionError as e:
        return {"ok": False, "error": f"اتصال ناموفق — {e}"}
    except Exception as e:
        return {"ok": False, "error": f"خطای ناشناخته: {type(e).__name__} — {e}"}


def test_connection(project_id=1):
    """تست اتصال با getMe"""
    s = get_settings(project_id)
    if not s or not s["bot_token"]:
        return {"ok": False, "error": "توکن Bot ثبت نشده"}
    url = TELEGRAM_API.format(token=s["bot_token"].strip(), method="getMe")
    proxies = build_proxies(s["proxy_url"])
    try:
        r = requests.get(url, proxies=proxies, timeout=30)
        data = r.json()
        if data.get("ok"):
            bot = data["result"]
            return {"ok": True, "bot_username": bot.get("username"), "bot_name": bot.get("first_name")}
        return {"ok": False, "error": _extract_error(data)}
    except requests.exceptions.ProxyError as e:
        return {"ok": False, "error": f"خطای پروکسی — pip install requests[socks] pysocks — {e}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
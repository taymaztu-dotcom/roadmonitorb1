# -*- coding: utf-8 -*-
"""تشخیص مشکل محاسبه کارکرد"""
import sqlite3
import os
import sys

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "roadmonitor.db")

# اگر آرگومان دادید، برای همان پرسنل تست می‌شود، وگرنه اولین نفر
personnel_id = int(sys.argv[1]) if len(sys.argv) > 1 else 1

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

print("=" * 70)
print("گزارش تشخیصی محاسبه کارکرد")
print("=" * 70)

# ۱. اطلاعات پرسنل
cur.execute("SELECT * FROM personnel WHERE id = ?", (personnel_id,))
person = cur.fetchone()
if not person:
    print(f"❌ پرسنل با شناسه {personnel_id} یافت نشد")
    sys.exit()

print(f"\n👤 پرسنل: {person['full_name']}")
print(f"   کد: {person['personnel_code']}")
print(f"   project_id: {person['project_id']}")
print(f"   work_pattern_id: {person['work_pattern_id']}")

# ۲. الگوی کاری
if person["work_pattern_id"]:
    cur.execute("SELECT * FROM work_patterns WHERE id = ?", (person["work_pattern_id"],))
    pattern = cur.fetchone()
    print(f"\n📋 الگوی اختصاصی: {pattern['pattern_name']} (id={pattern['id']})")
else:
    cur.execute("SELECT * FROM work_patterns WHERE project_id = ? AND is_default = 1 LIMIT 1", (person["project_id"],))
    pattern = cur.fetchone()
    if pattern:
        print(f"\n📋 الگوی پیش‌فرض پروژه: {pattern['pattern_name']} (id={pattern['id']})")
    else:
        print(f"\n❌ هیچ الگوی کاری یافت نشد!")
        sys.exit()

# ۳. جزئیات الگو
print(f"\n📊 جزئیات الگو:")
print(f"   ساعت کار رسمی: {pattern['work_start']} تا {pattern['work_end']}")
print(f"   ناهار:    شروع={pattern['lunch_start']}  پایان={pattern['lunch_end']}  مدت={pattern['lunch_duration_minutes']} دقیقه")
try:
    print(f"   صبحانه:   شروع={pattern['breakfast_start']}  پایان={pattern['breakfast_end']}  مدت={pattern['breakfast_duration']} دقیقه")
    print(f"   شام:      شروع={pattern['dinner_start']}  پایان={pattern['dinner_end']}  مدت={pattern['dinner_duration']} دقیقه")
except (KeyError, IndexError):
    print(f"   ⚠️ ستون‌های صبحانه/شام موجود نیستند! migrate_v2.py را اجرا کنید")
print(f"   کارکرد استاندارد: {pattern['daily_work_minutes']} دقیقه")
print(f"   عبور از نصف شب: {pattern['crosses_midnight']}")

# ۴. چند رکورد تردد آخر
print(f"\n📅 آخرین ۵ تردد این پرسنل:")
cur.execute("""
    SELECT work_date, start_time, end_time
    FROM personnel_attendance
    WHERE project_id = ? AND personnel_code = ?
    ORDER BY work_date DESC
    LIMIT 5
""", (person["project_id"], person["personnel_code"]))
for r in cur.fetchall():
    print(f"   {r['work_date']}: ورود={r['start_time']} خروج={r['end_time']}")

# ۵. تست محاسبه یک روز نمونه
print(f"\n🧮 تست محاسبه با ورود=06:45 خروج=18:15 (فرضی):")

def time_to_minutes(t):
    if not t or ":" not in str(t):
        return None
    parts = str(t).strip().split(":")
    return int(parts[0]) * 60 + int(parts[1])

def hm(m):
    return f"{m // 60:02d}:{m % 60:02d}"

s_min = 6 * 60 + 45  # 06:45
e_min = 18 * 60 + 15  # 18:15
official_start = time_to_minutes(pattern["work_start"])
official_end = time_to_minutes(pattern["work_end"])

print(f"   شروع رسمی الگو: {hm(official_start)} = {official_start} دقیقه")
print(f"   پایان رسمی الگو: {hm(official_end)} = {official_end} دقیقه")
print(f"   ورود کارگر: 06:45 = {s_min} دقیقه")
print(f"   خروج کارگر: 18:15 = {e_min} دقیقه")

effective_start = max(s_min, official_start)
effective_end = min(e_min, official_end)
regular_raw = max(0, effective_end - effective_start)

print(f"\n   بازه مؤثر داخل ساعت رسمی: {hm(effective_start)} تا {hm(effective_end)}")
print(f"   کارکرد ناخالص در بازه رسمی: {regular_raw} دقیقه = {hm(regular_raw)}")

# اضافه‌کاری
overtime_extra = 0
if e_min > official_end:
    overtime_extra = e_min - official_end
print(f"   اضافه‌کاری بعد از ساعت رسمی: {overtime_extra} دقیقه = {hm(overtime_extra)}")

# کسر وعده‌ها
print(f"\n   بررسی وعده‌ها:")
breaks_total = 0
for start_key, end_key, dur_key, name in [
    ("lunch_start", "lunch_end", "lunch_duration_minutes", "ناهار"),
    ("breakfast_start", "breakfast_end", "breakfast_duration", "صبحانه"),
    ("dinner_start", "dinner_end", "dinner_duration", "شام"),
]:
    try:
        bs = time_to_minutes(pattern[start_key]) if pattern[start_key] else None
        be = time_to_minutes(pattern[end_key]) if pattern[end_key] else None
        dur = pattern[dur_key] or 0
    except (KeyError, IndexError, TypeError) as e:
        print(f"     {name}: خطا - {e}")
        continue

    if dur <= 0:
        print(f"     {name}: مدت = ۰ → کسر نمی‌شود")
        continue

    if bs is not None and be is not None:
        if effective_end > bs and effective_start < be:
            breaks_total += dur
            print(f"     {name}: کارگر در بازه {hm(bs)}-{hm(be)} حضور داشت → کسر {dur} دقیقه ✅")
        else:
            print(f"     {name}: کارگر در بازه {hm(bs)}-{hm(be)} حضور نداشت → کسر نشد")
    else:
        breaks_total += dur
        print(f"     {name}: ساعت مشخص نیست، مستقیم کسر شد {dur} دقیقه")

regular_net = regular_raw - breaks_total
print(f"\n   جمع کسر وعده‌ها: {breaks_total} دقیقه = {hm(breaks_total)}")
print(f"   ✅ کارکرد خالص نهایی: {regular_net} دقیقه = {hm(regular_net)}")

conn.close()
print("\n" + "=" * 70)
print("پایان گزارش")
print("=" * 70)
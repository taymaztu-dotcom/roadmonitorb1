# -*- coding: utf-8 -*-
"""پیدا کردن قالب‌های HTML که تاریخ میلادی نمایش می‌دهند"""
import os
import re

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")

# فیلدهای معمول تاریخ
DATE_FIELDS = [
    "created_at", "updated_at", "recorded_at", "punch_time",
    "start_time", "end_time", "event_time", "last_seen",
    "adjusted_at", "reviewed_at", "sent_at", "read_at",
    "last_test_at", "last_event_at", "started_at", "finished_at",
    "server_received_at", "connected_at", "disconnected_at",
    "last_packet_at", "report_date", "imported_at",
]

problems = []

for filename in os.listdir(TEMPLATES_DIR):
    if not filename.endswith(".html"):
        continue
    filepath = os.path.join(TEMPLATES_DIR, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    for field in DATE_FIELDS:
        # پیدا کردن {{ x.field }} یا {{ x.field or ... }} که فیلتر ندارد
        pattern = r"\{\{\s*\w+\.?" + field + r"\s*(?:or\s+[^}]*)?}}"
        matches = re.findall(pattern, content)
        for m in matches:
            if "|jalali" not in m and "|shamsi" not in m and "|persian" not in m:
                problems.append((filename, field, m))

print("=" * 60)
print(f"تعداد موارد بدون فیلتر: {len(problems)}")
print("=" * 60)

by_file = {}
for f, field, m in problems:
    by_file.setdefault(f, []).append((field, m))

for filename in sorted(by_file.keys()):
    print(f"\n📄 {filename}")
    for field, m in by_file[filename][:10]:
        print(f"   {field}: {m}")
    if len(by_file[filename]) > 10:
        print(f"   ... و {len(by_file[filename]) - 10} مورد دیگر")

print("\n" + "=" * 60)
print("راه‌حل: در هر مورد بالا، به {{ x.field }} فیلتر |jalali_datetime اضافه کنید")
print("مثال: {{ x.created_at }} → {{ x.created_at|jalali_datetime }}")
print("=" * 60)